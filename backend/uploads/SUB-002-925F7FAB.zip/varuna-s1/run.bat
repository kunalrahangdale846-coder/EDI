@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
  echo ==^> creating virtualenv
  python -m venv .venv
)
if not exist .venv\.installed (
  echo ==^> installing requirements ^(about a minute^)
  .venv\Scripts\python -m pip install -q --upgrade pip
  .venv\Scripts\python -m pip install -q -r requirements.txt
  type nul > .venv\.installed
)
if "%1"=="" (
  .venv\Scripts\python -m varuna.cli demo --seed 26161 --particles 1500
) else (
  .venv\Scripts\python -m varuna.cli %*
)
echo.
echo outputs in .\artifacts   scenes in .\work
