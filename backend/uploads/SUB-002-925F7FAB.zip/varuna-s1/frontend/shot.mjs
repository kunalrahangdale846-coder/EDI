import { chromium } from "playwright";
const views = ["overview", "run", "evaluation", "health", "integration"];
const labels = { overview: "Overview", run: "Run visualiser", evaluation: "Evaluation",
                 health: "System health", integration: "Integration" };
const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1194/chrome-linux/chrome" });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const errors = [];
page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
await page.goto("http://127.0.0.1:8581/", { waitUntil: "networkidle" });
await page.waitForTimeout(1200);
for (const v of views) {
  await page.getByRole("button", { name: new RegExp(labels[v], "i") }).first().click();
  await page.waitForTimeout(700);
  await page.screenshot({ path: `/tmp/dash-${v}.png`, fullPage: true });
}
console.log("badge:", await page.locator("text=/^(live|embedded)$/").first().innerText().catch(() => "?"));
console.log(errors.length ? "ERRORS:\n" + errors.join("\n") : "no console/page errors");
await browser.close();
