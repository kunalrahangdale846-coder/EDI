module.exports = {
  content: ["./VarunaDashboard.jsx", "./entry.jsx"],
  theme: { extend: {} },
  plugins: [],
};
