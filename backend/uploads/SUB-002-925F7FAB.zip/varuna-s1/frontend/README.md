# VARUNA-S1 dashboard

Single-page React dashboard over the pipeline's own artifacts.

## Use it without building anything

The bundle is already built into `varuna/static/`. Just:

```bash
.venv/bin/pip install -r requirements-web.txt
.venv/bin/python -m varuna.cli demo        # produce an artifact to display
.venv/bin/python -m varuna.cli serve       # http://127.0.0.1:8501
```

Or `./run.sh web`, which does all three.

## Use it as a React component

`VarunaDashboard.jsx` is a single self-contained component — paste it into a
React canvas or an Artifact. It imports only `react` and `lucide-react`.

On mount it tries `fetch("/api/state")`. If a VARUNA server answers, it renders
live pipeline output and the header badge reads **live**. If nothing answers, it
falls back to the artifact embedded at build time and the badge reads
**embedded**. Both paths show real measured numbers, never placeholders.

## Rebuilding

```bash
cd frontend
npm install
python ../frontend/embed_data.py   # refresh the embedded artifact from artifacts/
node build.mjs                     # -> varuna/static/{index.html,app.js,app.css}
```

`build.mjs` bundles with esbuild and generates the Tailwind CSS. Output is fully
self-contained — no CDN, works offline.

| file | role |
| --- | --- |
| `VarunaDashboard.jsx` | the whole dashboard, one component |
| `entry.jsx` | mounts it into `#root` |
| `embed_data.py` | splices `artifacts/*.json` into the component |
| `build.mjs` | esbuild + Tailwind → `varuna/static/` |
| `shot.mjs`, `overflow.mjs` | Playwright screenshot and layout checks |

## Where the numbers come from

Everything on screen is read from files the pipeline writes:

| panel | source |
| --- | --- |
| stat tiles, scene map, suspect ranking | `artifacts/demo_run.json` |
| metrics, PR/ROC curves, confusion matrix | `artifacts/varuna_evaluation.json` |
| feature importance, model provenance | `artifacts/oil_classifier_report.json` |
| runtime components, active config | `varuna.api.health()`, live |

The map geometry — slick outlines, release clouds, AIS tracks, radar targets — is
real output from `pipeline.Result._geometry()` in scene coordinates, not decoration.

## Palette

Validated against the dataviz six-checks on the `#0f172a` dark surface:

`#059669` slick · `#d97706` release cloud · `#0891b2` AIS vessel ·
`#8b5cf6` · `#e11d48` dark contact

Emerald and cyan are deliberately **not** adjacent in the categorical order —
they fail the normal-vision separation floor when neighbouring (ΔE 12.1 < 15).
