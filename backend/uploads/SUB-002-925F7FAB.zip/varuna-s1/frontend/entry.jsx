import React from "react";
import { createRoot } from "react-dom/client";
import VarunaDashboard from "./VarunaDashboard.jsx";

createRoot(document.getElementById("root")).render(<VarunaDashboard />);
