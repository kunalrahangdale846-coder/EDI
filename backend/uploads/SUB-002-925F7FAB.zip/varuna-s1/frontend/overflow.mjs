import { chromium } from "playwright";
const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1194/chrome-linux/chrome" });
const p = await b.newPage({ viewport: { width: 1440, height: 1000 } });
await p.goto("http://127.0.0.1:8579/", { waitUntil: "networkidle" });
const views = ["Overview","Run visualiser","Evaluation","System health","Integration"];
let bad = 0;
for (const v of views) {
  await p.getByRole("button", { name: new RegExp(v, "i") }).first().click();
  await p.waitForTimeout(500);
  const over = await p.evaluate(() => {
    const out = [];
    document.querySelectorAll("pre, table, .overflow-x-auto").forEach((el) => {
      if (el.scrollWidth > el.clientWidth + 2)
        out.push(`${el.tagName}.${el.className.split(" ")[0]} ${el.scrollWidth}>${el.clientWidth}`);
    });
    const body = document.body;
    if (body.scrollWidth > window.innerWidth + 2) out.push(`BODY h-scroll ${body.scrollWidth}`);
    return out;
  });
  if (over.length) { bad += over.length; console.log(`  ${v}:`); over.forEach(o => console.log("    " + o)); }
  else console.log(`  ${v}: no overflow`);
}
console.log(bad ? `\n${bad} overflow(s)` : "\nno horizontal overflow anywhere");
await b.close();
