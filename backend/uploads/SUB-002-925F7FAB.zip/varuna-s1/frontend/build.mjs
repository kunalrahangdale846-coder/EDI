import { build } from "esbuild";
import { execFileSync } from "node:child_process";
import { mkdirSync, writeFileSync, readFileSync, statSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const out = join(here, "..", "varuna", "static");
mkdirSync(out, { recursive: true });

await build({
  entryPoints: [join(here, "entry.jsx")],
  bundle: true,
  minify: true,
  format: "iife",
  target: ["es2019"],
  jsx: "automatic",
  loader: { ".jsx": "jsx" },
  define: { "process.env.NODE_ENV": '"production"' },
  outfile: join(out, "app.js"),
  logLevel: "error",
});

execFileSync(join(here, "node_modules", ".bin", "tailwindcss"), [
  "-c", join(here, "tailwind.config.js"),
  "-i", join(here, "tailwind.css"),
  "-o", join(out, "app.css"),
  "--minify",
], { stdio: ["ignore", "ignore", "inherit"] });

writeFileSync(join(out, "index.html"), `<!doctype html>
<html lang="en" class="dark">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>VARUNA-S1 — Sentinel-1 spill attribution</title>
<meta name="description" content="Oil-slick detection and vessel source attribution from Sentinel-1 SAR." />
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2334d399' stroke-width='2.5' stroke-linecap='round'%3E%3Cpath d='M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 1.3 0 1.9-.5 2.5-1'/%3E%3Cpath d='M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 1.3 0 1.9-.5 2.5-1'/%3E%3Cpath d='M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 1.3 0 1.9-.5 2.5-1'/%3E%3C/svg%3E" />
<link rel="stylesheet" href="./app.css" />
<style>html,body{background:#0f172a;margin:0}</style>
</head>
<body><div id="root"></div><script src="./app.js" defer></script></body>
</html>
`);

const kb = (f) => (statSync(join(out, f)).size / 1024).toFixed(1);
console.log(`built varuna/static  app.js ${kb("app.js")} KB  app.css ${kb("app.css")} KB  index.html ${kb("index.html")} KB`);
