#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

PY="${PYTHON:-python3}"
VENV=".venv"
REQ="requirements.txt"
MODE="${1:-demo}"

if [ "$MODE" = "--full" ]; then
    REQ="requirements-full.txt"
    MODE="${2:-demo}"
fi

command -v "$PY" >/dev/null 2>&1 || { echo "python3 not found; set PYTHON=/path/to/python3"; exit 1; }

if [ ! -d "$VENV" ]; then
    echo "==> creating virtualenv"
    "$PY" -m venv "$VENV"
fi

if [ ! -f "$VENV/.installed-$(basename "$REQ")" ]; then
    echo "==> installing $REQ (about a minute)"
    "$VENV/bin/pip" install -q --upgrade pip
    "$VENV/bin/pip" install -q -r "$REQ"
    touch "$VENV/.installed-$(basename "$REQ")"
fi

echo "==> $MODE"
case "$MODE" in
  demo)
    "$VENV/bin/python" -m varuna.cli demo --seed 26161 --particles 1500
    ;;
  evaluate)
    "$VENV/bin/python" -m varuna.cli evaluate --scenes 50
    ;;
  test)
    "$VENV/bin/pip" install -q pytest
    "$VENV/bin/python" -m pytest tests -q
    ;;
  web)
    "$VENV/bin/pip" install -q -r requirements-web.txt
    if [ ! -f artifacts/demo_run.json ]; then
        echo "==> no run artifact yet, producing one"
        "$VENV/bin/python" -m varuna.cli demo --seed 26161 --particles 1500 >/dev/null
    fi
    "$VENV/bin/python" -m varuna.cli serve --port "${PORT:-8501}"
    ;;
  *)
    "$VENV/bin/python" -m varuna.cli "$@"
    ;;
esac

echo ""
echo "outputs in ./artifacts   scenes in ./work"
