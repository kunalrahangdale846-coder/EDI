# Testing VARUNA on real Copernicus data

Six steps. Steps 1–4 need no AIS and no wind data, and they are the ones that
tell you whether the detector actually works.

---

## 0. What you need

- A free Copernicus Data Space account — https://dataspace.copernicus.eu
- ~2 GB of disk per scene
- The venv from the README

Nothing else. **SNAP is not required.**

---

## 1. Pick a scene with a known slick

Do not pick at random — you need ground truth or you learn nothing.

Use **Cerulean** (SkyTruth), which runs a U-Net over Sentinel-1 globally and
publishes every detection as a polygon keyed to the S1 scene ID:

- map: https://cerulean.skytruth.org
- API: https://api.cerulean.skytruth.org

Pan to the Arabian Sea / Gulf of Kutch / Bay of Bengal, find a detection, and
note three things: **the Sentinel-1 scene name**, the **slick polygon**, and the
**acquisition time**. Export the polygon as GeoJSON — you will use it in step 6.

If you would rather start easier, pick any scene with a large slick anywhere;
the physics does not care which EEZ it is in.

---

## 2. Download the product

Either through the CDSE browser, or with the bundled helper:

```bash
python scripts/fetch_cdse.py \
    --aoi 68.5,21.8,70.5,23.5 \
    --start 2026-03-01 --end 2026-03-31
# lists matching products, then:
python scripts/fetch_cdse.py --aoi ... --start ... --end ... --pick 3
```

**The helper is untested** — it has never been run against the live API, because
the machine it was written on has no route to Copernicus. If it fails, that is a
bug in the helper, not in the reader. Downloading through the web browser works
just as well; you only need the unzipped `.SAFE` directory.

You want **IW GRDH**, and **VV** polarisation (a `1SDV` product carries VV+VH;
the reader picks VV).

---

## 3. Run the doctor first

```bash
.venv/bin/python -m varuna.cli doctor /path/to/S1A_IW_GRDH_....SAFE
```

This parses the product without doing any heavy computation and tells you
whether the reader will succeed. It checks the measurement raster, whether it is
memory-mappable, every annotation field the reader depends on, the calibration
and noise LUTs, the geolocation grid, the no-data fraction, and the memory a
full-scene read would need. It ends with a suggested AOI.

**If anything says FAIL, stop and send me the output.** That is a five-minute
fix, and it is exactly the kind of mismatch I could not test for without a real
product.

---

## 4. Detection only

Start with the AOI the doctor suggested, and assert open water so the land
detector does not have to guess:

```bash
.venv/bin/python -m varuna.cli real /path/to/S1A_....SAFE \
    --aoi 69.04,22.41,69.76,22.89 \
    --assume-all-sea
```

You get a terminal report and `artifacts/varuna_real_overlay.png` — a geolocated
figure with dark regions outlined and CFAR targets marked.

**This is the test that matters.** Compare the outlined region against the
Cerulean polygon. If they overlap, the SAR half of the pipeline works on real
imagery.

Expect two messages:

- `p(oil) = 0.000` and a warning that the classifier is withheld. That is
  deliberate — the shipped model was trained on simulated slicks and its
  probabilities are meaningless on real data. Add `--allow-synthetic-model` to
  see them anyway, but do not believe them.
- `attribution disabled` — no wind or current supplied yet. Step 5.

### If it misbehaves

| symptom | try |
| --- | --- |
| no dark regions found | loosen **both** gates: `VARUNA_DARK_K=0.75 VARUNA_DARK_DAMPING_MAX=0.92`. The region-damping gate is usually the binding one, not `k`. Also check the wind was 3–10 m/s at acquisition |
| still nothing, and the slick is small | `VARUNA_DARK_MIN_AREA=0.5` (default 2 km²) |
| the slick is very large (tens of km) and only its edges are outlined | the background window sits inside it. Widen it: `VARUNA_DARK_BACKGROUND_PX=401` (default 81 px = 12 km at 150 m). The window must be comfortably larger than the slick |
| far too many regions | tighten: `VARUNA_DARK_DAMPING_MAX=0.70 VARUNA_DARK_SEED_FRAC=0.5` |
| everything is one huge region | the border was not masked — check the doctor's no-data line |
| zero CFAR targets | the ENL is being misread; check the `vessel grid ... ENL` line in the output |
| hundreds of CFAR targets at the edges | swath border noise; shrink the AOI away from the edge, or tighten `VARUNA_CFAR_PFA=1e-10` |
| memory blows up | you skipped `--aoi`; it should still fit in ~0.6 GB, so send me the traceback |

---

## 5. Add wind and current

```bash
.venv/bin/python -m varuna.cli env-template --out environment.json
```

Fill it in for the **scene centre at acquisition time**:

- 10 m wind — ERA5, via the Copernicus Climate Data Store
  (https://cds.climate.copernicus.eu)
- surface current — CMEMS (https://marine.copernicus.eu) or HYCOM

Both are spatially constant in this version. That is a real limitation: over a
250 km swath the current field is not uniform. Use the value nearest the slick.

```bash
.venv/bin/python -m varuna.cli real /path/to/....SAFE \
    --aoi ... --assume-all-sea --env environment.json
```

The back-cast now runs. Without AIS it will still rank dark radar contacts.

---

## 6. Retrain the classifier so p(oil) means something

This is what turns the demo into a result. Label real scenes against Cerulean
polygons:

```bash
.venv/bin/python -m varuna.cli label scene1.SAFE cerulean_slicks.geojson \
    --dataset artifacts/real_dataset.npz --assume-all-sea
# repeat over as many scenes as you can — aim for 30+ with both classes
.venv/bin/python -m varuna.cli train-real --dataset artifacts/real_dataset.npz
```

`train-real` stamps the model `provenance: real`, which lifts the withholding.
Re-run step 4 and the probabilities are now worth reading.

You need **negatives too** — scenes with look-alikes that Cerulean did *not*
flag. A dataset of only positives trains nothing.

---

## Adding AIS (the hard part)

Attribution needs per-vessel position history:
`mmsi,name,ship_type,flag,length_m,timestamp,lon,lat,sog,cog`, passed with
`--ais-csv`, plus `--shore-km` so the coverage envelope can be resolved.

For the **Indian EEZ** there is no free source of per-vessel tracks. Options:
commercial (Spire, MarineTraffic), or an ICG/IMAC data-sharing arrangement.

What *is* free and does cover the Indian EEZ: **Global Fishing Watch's
Sentinel-1 SAR vessel detections**, each labelled matched or unmatched to AIS.
That is a published ground truth for your CFAR recall and your dark-vessel
calls, from the same sensor — you can validate Branch B completely without
buying anything.

Free per-vessel AIS exists for Danish waters (Danish Maritime Authority) and US
waters (NOAA Marine Cadastre). Those are the places to prove the attribution
machinery end to end, even if the deployment story is the Indian EEZ.

---

## What a good first result looks like

1. `doctor` passes with no FAIL
2. `real` finds a dark region whose outline overlaps the Cerulean polygon
3. CFAR targets appear where ships plausibly are, not scattered at the edges
4. the reported ENL is in the hundreds on the slick grid and tens on the vessel grid

That is enough to say the chain works on real imagery. Everything after it —
calibrated probabilities, named suspects — is a data problem, not a code problem.
