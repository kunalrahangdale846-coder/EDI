"""Copernicus Data Space download helper.

UNTESTED. This script has never been run against the live CDSE API, because the
environment it was written in has no outbound access to dataspace.copernicus.eu.
Endpoint shapes were taken from CDSE documentation, not from a successful call.
Treat failures here as bugs in this script, not in the VARUNA reader, and check
the current API reference before debugging deeply:
https://documentation.dataspace.copernicus.eu/APIs/OData.html
"""

import argparse
import getpass
import json
import os
import sys
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

TOKEN_URL = ("https://identity.dataspace.copernicus.eu/auth/realms/CDSE/"
             "protocol/openid-connect/token")
ODATA = "https://catalogue.dataspace.copernicus.eu/odata/v1/Products"


def get_token(username, password, totp=None):
    fields = {"username": username, "password": password,
              "grant_type": "password", "client_id": "cdse-public"}
    if totp:
        fields["totp"] = totp
    data = urllib.parse.urlencode(fields).encode()
    req = urllib.request.Request(TOKEN_URL, data=data,
                                 headers={"Content-Type":
                                          "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=90) as resp:
        payload = json.loads(resp.read())
    if "access_token" not in payload:
        raise RuntimeError(f"no access_token in response: {payload}")
    return payload["access_token"]


def search(lon_min, lat_min, lon_max, lat_max, start, end, product="GRDH",
           mode="IW", limit=20):
    poly = (f"POLYGON(({lon_min} {lat_min},{lon_max} {lat_min},"
            f"{lon_max} {lat_max},{lon_min} {lat_max},{lon_min} {lat_min}))")
    filt = (f"Collection/Name eq 'SENTINEL-1' "
            f"and contains(Name,'{product}') and contains(Name,'{mode}') "
            f"and OData.CSC.Intersects(area=geography'SRID=4326;{poly}') "
            f"and ContentDate/Start gt {start}T00:00:00.000Z "
            f"and ContentDate/Start lt {end}T00:00:00.000Z")
    url = (f"{ODATA}?$filter={urllib.parse.quote(filt)}"
           f"&$orderby=ContentDate/Start desc&$top={limit}")
    with urllib.request.urlopen(url, timeout=120) as resp:
        return json.loads(resp.read()).get("value", [])


def download(product_id, token, out_dir, name=None):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / f"{name or product_id}.zip"
    url = f"{ODATA}({product_id})/$value"
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    opener = urllib.request.build_opener(urllib.request.HTTPRedirectHandler)
    total = 0
    with opener.open(req, timeout=1800) as resp, open(target, "wb") as fh:
        while True:
            chunk = resp.read(1 << 20)
            if not chunk:
                break
            fh.write(chunk)
            total += len(chunk)
            print(f"\r  {total/1e6:8.1f} MB", end="", file=sys.stderr)
    print(file=sys.stderr)
    return target


def unzip(path, out_dir):
    with zipfile.ZipFile(path) as z:
        z.extractall(out_dir)
    safes = sorted(Path(out_dir).glob("*.SAFE"))
    return safes[-1] if safes else None


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--aoi", required=True, help="lon_min,lat_min,lon_max,lat_max")
    p.add_argument("--start", required=True, help="YYYY-MM-DD")
    p.add_argument("--end", required=True, help="YYYY-MM-DD")
    p.add_argument("--out", default="products")
    p.add_argument("--limit", type=int, default=20)
    p.add_argument("--pick", type=int, help="index from the search listing to download")
    p.add_argument("--user", default=os.environ.get("CDSE_USER"))
    args = p.parse_args()

    lon_min, lat_min, lon_max, lat_max = (float(v) for v in args.aoi.split(","))
    hits = search(lon_min, lat_min, lon_max, lat_max, args.start, args.end,
                  limit=args.limit)
    if not hits:
        print("no products matched", file=sys.stderr)
        return 1
    for i, h in enumerate(hits):
        size = h.get("ContentLength", 0) or 0
        print(f"[{i:2d}] {h.get('ContentDate', {}).get('Start', '?')[:19]}  "
              f"{size/1e9:5.2f} GB  {h.get('Name')}")
    if args.pick is None:
        print("\nre-run with --pick N to download one", file=sys.stderr)
        return 0

    chosen = hits[args.pick]
    user = args.user or input("CDSE username: ")
    password = os.environ.get("CDSE_PASS") or getpass.getpass("CDSE password: ")
    token = get_token(user, password)
    print(f"downloading {chosen['Name']}", file=sys.stderr)
    zip_path = download(chosen["Id"], token, args.out, chosen["Name"])
    safe = unzip(zip_path, args.out)
    print(f"\n{safe}\n\nnext:\n  python -m varuna.cli doctor {safe}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
