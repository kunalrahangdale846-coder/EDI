import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
import tifffile

from varuna import s1_real


def _ok(msg):
    return ("ok", msg)


def _warn(msg):
    return ("warn", msg)


def _fail(msg):
    return ("fail", msg)


def inspect(safe_path, polarisation="vv"):
    safe = Path(safe_path)
    checks = []
    facts = {}

    if not safe.exists():
        return [_fail(f"{safe} does not exist")], facts
    if not (safe / "manifest.safe").exists():
        checks.append(_warn("no manifest.safe; is this the .SAFE directory itself?"))
    else:
        checks.append(_ok("manifest.safe present"))

    meas_dir = safe / "measurement"
    if not meas_dir.exists():
        return checks + [_fail("no measurement/ directory")], facts
    rasters = sorted(meas_dir.glob("*.tif*"))
    pols = sorted({p.name.split("-")[3] for p in rasters if len(p.name.split("-")) > 3})
    checks.append(_ok(f"{len(rasters)} measurement raster(s), polarisations {pols or 'unknown'}"))
    facts["polarisations"] = pols

    try:
        measurement = s1_real._measurement(safe, polarisation)
    except FileNotFoundError as exc:
        return checks + [_fail(str(exc))], facts
    checks.append(_ok(f"selected {measurement.name}"))

    try:
        with tifffile.TiffFile(str(measurement)) as tif:
            page = tif.pages[0]
            h, w = int(page.shape[0]), int(page.shape[1])
            dtype = str(page.dtype)
            compressed = page.compression != 1
        facts["shape"] = (h, w)
        checks.append(_ok(f"raster {h} x {w} px, dtype {dtype}, "
                          f"{'compressed' if compressed else 'uncompressed'}"))
    except Exception as exc:
        return checks + [_fail(f"cannot open measurement TIFF: {exc!r}")], facts

    try:
        tifffile.memmap(str(measurement), mode="r")
        checks.append(_ok("raster is memory-mappable (streaming read will be cheap)"))
    except Exception:
        checks.append(_warn(f"raster is not memory-mappable; it will be read whole "
                            f"(~{h*w*2/1e9:.2f} GB as uint16)"))

    ann_path = s1_real._companion(safe, measurement)
    if ann_path is None:
        return checks + [_fail("no product annotation XML")], facts
    ann = ET.parse(ann_path).getroot()
    checks.append(_ok(f"annotation {ann_path.name}"))

    pol = s1_real._scoped(ann, "adsHeader", "polarisation")
    n_lines = s1_real._scoped(ann, "imageInformation", "numberOfLines")
    n_samp = s1_real._scoped(ann, "imageInformation", "numberOfSamples")
    spacing = s1_real._scoped(ann, "imageInformation", "rangePixelSpacing")
    stamp = s1_real._scoped(ann, "imageInformation", "productFirstLineUtcTime")
    for name, val in (("polarisation", pol), ("numberOfLines", n_lines),
                      ("numberOfSamples", n_samp), ("rangePixelSpacing", spacing),
                      ("productFirstLineUtcTime", stamp)):
        checks.append(_ok(f"{name} = {val}") if val is not None
                      else _fail(f"{name} missing from its expected container"))
    facts["spacing_m"] = float(spacing) if spacing else None

    if spacing and n_lines and n_samp:
        if abs(int(float(n_lines)) - h) > 2 or abs(int(float(n_samp)) - w) > 2:
            checks.append(_warn(f"annotation says {n_lines} x {n_samp} but the raster "
                                f"is {h} x {w}"))
        else:
            checks.append(_ok("annotation dimensions match the raster"))

    cal_path = s1_real._companion(safe, measurement, "calibration", "calibration-")
    if cal_path is None:
        checks.append(_fail("no calibration-*.xml"))
    else:
        grid = s1_real._vector_grid(ET.parse(cal_path).getroot(),
                                    "calibrationVectorList", "calibrationVector",
                                    "sigmaNought")
        if grid is None:
            checks.append(_fail(f"{cal_path.name} has no usable calibrationVectorList"))
        else:
            lines, pixels, values = grid
            allv = np.concatenate(values)
            checks.append(_ok(f"calibration LUT: {len(lines)} vectors x "
                              f"{len(pixels[0])} pixels, sigmaNought "
                              f"{allv.min():.1f}..{allv.max():.1f}"))

    noise_path = s1_real._companion(safe, measurement, "calibration", "noise-")
    if noise_path is None or not noise_path.name.startswith("noise-"):
        checks.append(_warn("no noise-*.xml; thermal noise will not be removed"))
    else:
        ngrid = s1_real._vector_grid(ET.parse(noise_path).getroot(),
                                     "noiseRangeVectorList", "noiseRangeVector",
                                     "noiseRangeLut")
        if ngrid is None:
            checks.append(_warn(f"{noise_path.name} has no noiseRangeVectorList "
                                f"(older IPF?); thermal noise will not be removed"))
        else:
            checks.append(_ok(f"noise LUT: {len(ngrid[0])} range vectors"))

    geo = s1_real._geolocation(ann)
    if geo is None:
        checks.append(_fail("no geolocationGridPointList; cannot geolocate"))
    else:
        gl, gp, glon, glat = geo
        checks.append(_ok(f"geolocation grid: {gl.size} points, "
                          f"lon {glon.min():.3f}..{glon.max():.3f}, "
                          f"lat {glat.min():.3f}..{glat.max():.3f}"))
        facts["bounds"] = (float(glon.min()), float(glat.min()),
                           float(glon.max()), float(glat.max()))

    try:
        mm = tifffile.memmap(str(measurement), mode="r")
        step = max(1, h // 512)
        sample = np.asarray(mm[::step, ::step])
        zero = float((sample == 0).mean())
        checks.append(_ok(f"no-data (DN=0) is {zero*100:.1f}% of a subsample")
                      if zero < 0.5 else
                      _warn(f"no-data (DN=0) is {zero*100:.1f}% of a subsample; "
                            f"the usable area is small"))
        facts["nodata_fraction"] = zero
    except Exception:
        checks.append(_warn("could not subsample the raster for a no-data estimate"))

    if facts.get("shape"):
        h, w = facts["shape"]
        peak = (s1_real.BLOCK_TARGET_ROWS * w * 12) / 1e9
        checks.append(_ok(f"estimated peak memory for a full-scene read: {peak:.2f} GB"))

    return checks, facts


def report(safe_path, polarisation="vv"):
    checks, facts = inspect(safe_path, polarisation)
    width = 78
    lines = ["=" * width, f"VARUNA doctor  |  {Path(safe_path).name}", "=" * width]
    symbols = {"ok": "  OK  ", " warn": "", "warn": " WARN ", "fail": " FAIL "}
    for level, msg in checks:
        lines.append(f"[{symbols[level]}] {msg}")
    n_fail = sum(1 for l, _ in checks if l == "fail")
    n_warn = sum(1 for l, _ in checks if l == "warn")
    lines.append("-" * width)
    if n_fail:
        lines.append(f"{n_fail} blocking problem(s); the reader will not succeed as-is")
    elif n_warn:
        lines.append(f"no blocking problems, {n_warn} warning(s); the reader should work")
    else:
        lines.append("all checks passed; the reader should work")
    if facts.get("bounds"):
        lo, la, hi_lo, hi_la = facts["bounds"]
        pad_lo = lo + 0.35 * (hi_lo - lo)
        pad_la = la + 0.35 * (hi_la - la)
        lines.append("")
        lines.append("suggested first run (a small central AOI):")
        lines.append(f"  --aoi {pad_lo:.3f},{pad_la:.3f},"
                     f"{pad_lo + 0.3*(hi_lo-lo):.3f},{pad_la + 0.3*(hi_la-la):.3f}")
    lines.append("=" * width)
    return "\n".join(lines), n_fail
