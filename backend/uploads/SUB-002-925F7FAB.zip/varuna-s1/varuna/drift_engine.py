import logging
import os
import warnings
from dataclasses import dataclass
from datetime import timedelta

import numpy as np

from varuna.config import (DIFFUSIVITY, DRIFT_MAX_H, DRIFT_MIN_H, DRIFT_STEP_S,
                           PARTICLES, WIND_DRIFT_FACTOR)
LAST_ERROR = {}


@dataclass
class BackCast:
    hours: np.ndarray
    lon: np.ndarray
    lat: np.ndarray
    backend: str
    seed_lon: np.ndarray
    seed_lat: np.ndarray
    frame: object = None

    def cloud_at(self, hour):
        i = int(np.argmin(np.abs(self.hours - hour)))
        return self.lon[i], self.lat[i]

    def as_km(self):
        return self.frame.km_of_lonlat(self.lon, self.lat)


def _seed_points(region, n, rng, frame):
    rr, cc = np.nonzero(region.mask)
    if rr.size == 0:
        raise ValueError("empty region")
    pick = rng.integers(0, rr.size, size=n)
    rows = rr[pick] + rng.random(n) - 0.5
    cols = cc[pick] + rng.random(n) - 0.5
    return frame.lonlat_of_px(rows, cols)


def opendrift_available():
    try:
        import importlib
        importlib.import_module("opendrift")
        return True
    except Exception:
        return False


def _run_opendrift(lon, lat, t0, u_ms, v_ms, wind_u, wind_v, hours, step_s):
    from opendrift.models.oceandrift import OceanDrift

    logging.getLogger("opendrift").setLevel(logging.ERROR)
    logging.getLogger("opendrift.models.basemodel").setLevel(logging.ERROR)

    if getattr(t0, "tzinfo", None) is not None:
        t0 = t0.replace(tzinfo=None)
    o = OceanDrift(loglevel=50)
    o.set_config("environment:constant:x_sea_water_velocity", float(u_ms))
    o.set_config("environment:constant:y_sea_water_velocity", float(v_ms))
    o.set_config("environment:constant:x_wind", float(wind_u))
    o.set_config("environment:constant:y_wind", float(wind_v))
    o.set_config("environment:constant:land_binary_mask", 0)
    o.set_config("seed:wind_drift_factor", WIND_DRIFT_FACTOR)
    o.set_config("environment:constant:horizontal_diffusivity", DIFFUSIVITY)
    o.set_config("drift:vertical_mixing", False)
    o.set_config("drift:advection_scheme", "runge-kutta")
    o.set_config("general:use_auto_landmask", False)
    o.set_config("general:coastline_action", "none")
    o.seed_elements(lon=np.asarray(lon), lat=np.asarray(lat), time=t0,
                    wind_drift_factor=WIND_DRIFT_FACTOR)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        o.run(time_step=-step_s, time_step_output=-step_s,
              duration=timedelta(hours=float(hours)))
    hist = o.result
    out_lon = np.asarray(hist["lon"].values, dtype=np.float64)
    out_lat = np.asarray(hist["lat"].values, dtype=np.float64)
    if out_lon.shape[0] != len(lon):
        out_lon, out_lat = out_lon.T, out_lat.T
    return out_lon.T, out_lat.T


def _run_internal(lon, lat, u_ms, v_ms, wind_u, wind_v, hours, step_s, rng, frame):
    x, y = frame.km_of_lonlat(lon, lat)
    x = np.array(x, dtype=float)
    y = np.array(y, dtype=float)
    n_steps = int(round(hours * 3600.0 / step_s))
    u_km = (u_ms + WIND_DRIFT_FACTOR * wind_u) * step_s / 1000.0
    v_km = (v_ms + WIND_DRIFT_FACTOR * wind_v) * step_s / 1000.0
    sigma = np.sqrt(2.0 * DIFFUSIVITY * step_s) / 1000.0
    lons, lats = [], []
    lo, la = frame.lonlat_of_km(x, y)
    lons.append(lo)
    lats.append(la)
    for _ in range(n_steps):
        x -= u_km + rng.normal(0, sigma, x.shape)
        y -= v_km + rng.normal(0, sigma, y.shape)
        lo, la = frame.lonlat_of_km(x, y)
        lons.append(lo)
        lats.append(la)
    return np.vstack(lons), np.vstack(lats)


def backcast(scene, region, u_ms, v_ms, wind_speed, wind_dir_deg,
             hours=DRIFT_MAX_H, n=PARTICLES, force_internal=False, seed=0,
             frame=None):
    rng = np.random.default_rng(seed)
    frame = frame if frame is not None else scene.frame
    lon0, lat0 = _seed_points(region, n, rng, frame)
    rad = np.deg2rad(wind_dir_deg or 0.0)
    wind_u = float(np.sin(rad) * (wind_speed or 0.0))
    wind_v = float(np.cos(rad) * (wind_speed or 0.0))

    backend = "internal-lagrangian"
    lons = lats = None
    if not force_internal and opendrift_available():
        try:
            lons, lats = _run_opendrift(lon0, lat0, scene.acquired, u_ms, v_ms,
                                        wind_u, wind_v, hours, DRIFT_STEP_S)
            backend = "opendrift"
        except Exception as exc:
            if os.environ.get("VARUNA_DEBUG"):
                raise
            LAST_ERROR["opendrift"] = repr(exc)
            lons = None
    if lons is None:
        lons, lats = _run_internal(lon0, lat0, u_ms, v_ms, wind_u, wind_v,
                                   hours, DRIFT_STEP_S, rng, frame)

    steps = lons.shape[0]
    hrs = np.arange(steps) * DRIFT_STEP_S / 3600.0
    return BackCast(hours=hrs, lon=lons, lat=lats, backend=backend,
                    seed_lon=lon0, seed_lat=lat0, frame=frame)


def candidate_hours(step_h=0.5):
    return np.arange(DRIFT_MIN_H, DRIFT_MAX_H + 1e-9, step_h)
