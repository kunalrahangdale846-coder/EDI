def fmt(lon, lat):
    ns = "N" if lat >= 0 else "S"
    ew = "E" if lon >= 0 else "W"
    return f"{abs(lat):.4f}{ns} {abs(lon):.4f}{ew}"
