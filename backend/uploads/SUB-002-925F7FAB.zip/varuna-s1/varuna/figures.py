from pathlib import Path

import numpy as np

from varuna.config import ARTIFACTS


def available():
    try:
        import matplotlib  # noqa
        return True
    except Exception:
        return False


def _setup():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 8, "figure.dpi": 160,
                         "axes.titlesize": 9, "axes.labelsize": 8})
    return plt


def _db(sigma0):
    out = np.full(sigma0.shape, np.nan)
    pos = sigma0 > 0
    out[pos] = 10.0 * np.log10(sigma0[pos])
    return out


def real_overlay(result, path=None, title=None):
    plt = _setup()
    from scipy import ndimage

    real = result.coarse
    scene = result.scene
    db = _db(scene.sigma0)
    finite = db[np.isfinite(db)]
    vmin, vmax = np.percentile(finite, [2, 98])

    extent = [float(real.lon.min()), float(real.lon.max()),
              float(real.lat.min()), float(real.lat.max())]

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))

    ax = axes[0]
    ax.imshow(db, cmap="gray", vmin=vmin, vmax=vmax, extent=extent,
              origin="upper", aspect="auto")
    if scene.land_mask.any():
        land = np.ma.masked_where(~scene.land_mask, scene.land_mask.astype(float))
        ax.imshow(land, cmap="autumn", alpha=0.25, extent=extent,
                  origin="upper", aspect="auto")
    if result.located:
        ax.plot([rec["lon"] for rec in result.located],
                [rec["lat"] for rec in result.located],
                marker="+", color="#ff2d55", ms=5, mew=0.9, ls="none",
                label=f"CFAR targets @ {result.fine.pixel_spacing_m:.0f} m")
    for a in result.attributions:
        bc = a.backcast
        if bc is None:
            continue
        i = int(np.argmin(np.abs(bc.hours - (a.best_hour or bc.hours[-1]))))
        ax.plot(bc.lon[i], bc.lat[i], ".", color="#ffd60a", ms=0.6, alpha=0.5,
                ls="none")
    for r in result.regions:
        edge = r.mask & ~ndimage.binary_erosion(r.mask, np.ones((3, 3)))
        rr, cc = np.nonzero(edge)
        ax.plot(real.lon[rr, cc], real.lat[rr, cc], ".", color="#00e5ff",
                ms=0.5, ls="none")
    ax.set_title(f"{real.source.name}\n"
                 f"{real.acquired.strftime('%Y-%m-%d %H:%M UTC')}  {real.polarisation}  "
                 f"slicks @ {real.pixel_spacing_m:.0f} m (ENL {real.enl:.0f})  "
                 f"vessels @ {result.fine.pixel_spacing_m:.0f} m "
                 f"(ENL {result.fine.enl:.0f})")
    if result.located:
        ax.legend(loc="upper right", fontsize=6, framealpha=0.7)
    ax.set_xlabel("longitude")
    ax.set_ylabel("latitude")

    ax = axes[1]
    if result.regions:
        order = np.argsort(-result.oil_probability) if len(result.oil_probability) \
            else np.arange(len(result.regions))
        top = result.regions[int(order[0])]
        r0, r1, c0, c1 = top.bbox
        pad = 12
        r0 = max(0, r0 - pad); c0 = max(0, c0 - pad)
        r1 = min(db.shape[0], r1 + pad); c1 = min(db.shape[1], c1 + pad)
        sub = db[r0:r1, c0:c1]
        sub_extent = [float(real.lon[r0:r1, c0:c1].min()),
                      float(real.lon[r0:r1, c0:c1].max()),
                      float(real.lat[r0:r1, c0:c1].min()),
                      float(real.lat[r0:r1, c0:c1].max())]
        ax.imshow(sub, cmap="gray", vmin=vmin, vmax=vmax, extent=sub_extent,
                  origin="upper", aspect="auto")
        edge = top.mask[r0:r1, c0:c1] & ~ndimage.binary_erosion(
            top.mask[r0:r1, c0:c1], np.ones((3, 3)))
        rr, cc = np.nonzero(edge)
        if rr.size:
            ax.plot(real.lon[r0:r1, c0:c1][rr, cc], real.lat[r0:r1, c0:c1][rr, cc],
                    ".", color="#00e5ff", ms=1.2, ls="none")
        f = result.features[int(order[0])]
        p = float(result.oil_probability[int(order[0])]) if len(result.oil_probability) else float("nan")
        withheld = any("withheld" in w for w in result.warnings)
        ptxt = "withheld (simulated model)" if withheld else f"p(oil)={p:.2f}"
        ax.set_title(f"top candidate  {top.area_km2:.1f} km2\n"
                     f"damping {f[0]:.2f}  elongation {f[2]:.1f}  {ptxt}")
    else:
        ax.text(0.5, 0.5, "no dark region passed the contrast gate",
                ha="center", va="center", transform=ax.transAxes)
        ax.set_xticks([]); ax.set_yticks([])
    ax.set_xlabel("longitude")

    fig.suptitle(title or "VARUNA  |  Sentinel-1 dark-spot and vessel detection",
                 fontsize=10)
    fig.tight_layout()
    path = Path(path or ARTIFACTS / "varuna_real_overlay.png")
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path
