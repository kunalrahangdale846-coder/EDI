import json
import shutil
import tempfile
from pathlib import Path

import numpy as np
from sklearn.metrics import (average_precision_score, brier_score_loss,
                             confusion_matrix, precision_recall_curve,
                             roc_auc_score, roc_curve)

from varuna import (darkspots, patch_metrics, pipeline, safe_reader, simulate,
                    snap_preprocess)
from varuna.config import ARTIFACTS, OIL_PROB_MIN, PIXEL_M

OVERLAP_MIN = 0.30
VESSEL_MATCH_PX = 4.0
SLICK_MATCH_PX = 40.0
DARK_MATCH_KM = 3.0


def label_region(labels, region):
    if labels is None:
        return -1
    vals = labels[region.mask]
    oil = float((vals == 1).mean())
    fake = float((vals == 2).mean())
    if oil >= OVERLAP_MIN and oil >= fake:
        return 1
    return 0


def build_dataset(seeds, workdir=None, keep=False):
    tmp = Path(workdir or tempfile.mkdtemp(prefix="varuna-ds-"))
    tmp.mkdir(parents=True, exist_ok=True)
    X, y, groups = [], [], []
    for s in seeds:
        safe = simulate.write_product(tmp / f"scene_{s:04d}.SAFE", s)
        scene = snap_preprocess.preprocess(safe_reader.read(safe))
        regions = darkspots.detect(scene)
        if regions:
            feats = patch_metrics.extract_all(scene, regions)
            for r, f in zip(regions, feats):
                X.append(f)
                y.append(label_region(scene.labels, r))
                groups.append(s)
        if not keep:
            shutil.rmtree(safe, ignore_errors=True)
    if not keep:
        shutil.rmtree(tmp, ignore_errors=True)
    return np.array(X), np.array(y), np.array(groups)


def _nearest(items, key, limit):
    best, bd = None, 1e9
    for it in items:
        d = key(it)
        if d < bd:
            bd, best = d, it
    return (best, bd) if best is not None and bd <= limit else (None, bd)


def _score_vessels(res, truth, acc):
    sea = res.scene.sea_mask
    vessels = [v for v in truth.get("vessels", [])
               if v.get("row") is not None and sea[v["row"], v["col"]]]
    acc["v_masked"] += sum(1 for v in truth.get("vessels", [])
                           if v.get("row") is not None and not sea[v["row"], v["col"]])
    acc["v_total"] += len(vessels)
    matched = set()
    for det in res.detections:
        hit, d = _nearest(
            list(enumerate(vessels)),
            lambda iv: float(np.hypot(det.centroid_rc[0] - iv[1]["row"],
                                      det.centroid_rc[1] - iv[1]["col"])),
            VESSEL_MATCH_PX)
        if hit is not None:
            matched.add(hit[0])
        else:
            acc["v_false"] += 1
    acc["v_hit"] += len(matched)

    for rec in res.dark:
        hit, d = _nearest(
            vessels,
            lambda v: float(np.hypot(rec["detection"].centroid_rc[0] - v["row"],
                                     rec["detection"].centroid_rc[1] - v["col"])),
            VESSEL_MATCH_PX)
        if hit is None:
            continue
        acc["dark_total"] += 1
        if hit["broadcasting"]:
            acc["false_dark"] += 1
        else:
            acc["dark_correct"] += 1


def _score_attribution(res, truth, acc):
    oil_truth = [t for t in truth.get("slicks", []) if t["kind"] == "oil"]
    by_id = {v["id"]: v for v in truth.get("vessels", [])}
    for a in res.attributions:
        r = res.regions[a.region_index]
        best, _ = _nearest(
            oil_truth,
            lambda t: float(np.hypot(r.centroid_rc[0] - t["centroid_row"],
                                     r.centroid_rc[1] - t["centroid_col"])),
            SLICK_MATCH_PX)
        if best is None:
            continue
        acc["attrib_total"] += 1

        src = by_id.get(best["source_vessel"], {})
        cx = r.centroid_rc[1] * PIXEL_M / 1000.0
        cy = r.centroid_rc[0] * PIXEL_M / 1000.0
        in_cov = res.coverage.inside(cx, cy) if res.coverage.known else None
        findable = bool(best["broadcasting"]) or bool(
            best.get("source_in_scene") and in_cov is True)
        acc["findable" if findable else "unfindable"] += 1

        if not a.suspects:
            acc["attrib_none"] += 1
            if not res.coverage.known:
                acc["coverage_refusals"] += 1
            continue

        pos = None
        for i, sus in enumerate(a.suspects):
            if sus.mmsi is not None and sus.mmsi == best["source_mmsi"]:
                pos = i
                break
            if (sus.kind == "dark" and not best["broadcasting"]
                    and src.get("row") is not None and sus.x_km is not None
                    and float(np.hypot(sus.x_km - src["x_km"],
                                       sus.y_km - src["y_km"])) <= DARK_MATCH_KM):
                pos = i
                break

        if pos is not None:
            acc["ranks"].append(pos + 1)
            if pos == 0:
                acc["attrib_hit"] += 1
                if findable:
                    acc["findable_hit"] += 1
            top = a.suspects[pos]
        else:
            top = a.suspects[0]
        acc["time_err"].append(abs(top.release_hours_before - best["release_age_h"]))
        acc["dist_err"].append(top.distance_km)


def evaluate(classifier, seeds, particles=600, force_internal_drift=True,
             workdir=None, threshold=OIL_PROB_MIN):
    tmp = Path(workdir or tempfile.mkdtemp(prefix="varuna-ev-"))
    tmp.mkdir(parents=True, exist_ok=True)

    acc = dict(v_total=0, v_hit=0, v_false=0, v_masked=0, dark_total=0, dark_correct=0,
               false_dark=0, attrib_total=0, attrib_hit=0, attrib_none=0,
               findable=0, findable_hit=0, unfindable=0, coverage_refusals=0,
               ranks=[], time_err=[], dist_err=[])
    probs, labels = [], []

    for s in seeds:
        safe = simulate.write_product(tmp / f"eval_{s:04d}.SAFE", s)
        res = pipeline.run(safe, classifier=classifier, particles=particles,
                           force_internal_drift=force_internal_drift, seed=s)
        for r, p in zip(res.regions, res.oil_probability):
            probs.append(float(p))
            labels.append(label_region(res.scene.labels, r))
        _score_vessels(res, res.scene.truth, acc)
        _score_attribution(res, res.scene.truth, acc)
        shutil.rmtree(safe, ignore_errors=True)

    shutil.rmtree(tmp, ignore_errors=True)

    probs = np.array(probs)
    labels = np.array(labels)
    both = len(set(labels.tolist())) > 1
    pred = (probs >= threshold).astype(int)
    cm = (confusion_matrix(labels, pred, labels=[0, 1]).tolist()
          if probs.size else [[0, 0], [0, 0]])

    curves = {}
    if both:
        pr_p, pr_r, _ = precision_recall_curve(labels, probs)
        fpr, tpr, _ = roc_curve(labels, probs)
        step_pr = max(1, len(pr_p) // 60)
        step_roc = max(1, len(fpr) // 60)
        curves = {
            "precision_recall": [[round(float(r), 4), round(float(p), 4)]
                                 for r, p in zip(pr_r[::step_pr], pr_p[::step_pr])],
            "roc": [[round(float(a), 4), round(float(b), 4)]
                    for a, b in zip(fpr[::step_roc], tpr[::step_roc])],
        }

    return {
        "n_scenes": len(seeds),
        "classifier": {
            "n_regions": int(probs.size),
            "positive_rate": float(labels.mean()) if labels.size else None,
            "roc_auc": float(roc_auc_score(labels, probs)) if both else None,
            "pr_auc": float(average_precision_score(labels, probs)) if both else None,
            "brier": float(brier_score_loss(labels, probs)) if probs.size else None,
            "threshold": threshold,
            "confusion_rows_true_0_1": cm,
            "precision": float(cm[1][1] / max(cm[1][1] + cm[0][1], 1)),
            "recall": float(cm[1][1] / max(cm[1][1] + cm[1][0], 1)),
            "f1": float(2 * cm[1][1] / max(2 * cm[1][1] + cm[0][1] + cm[1][0], 1)),
            "curves": curves,
        },
        "cfar": {
            "true_vessels_in_analysable_sea": acc["v_total"],
            "vessels_excluded_by_land_mask": acc["v_masked"],
            "recall": float(acc["v_hit"] / max(acc["v_total"], 1)),
            "false_alarms_per_scene": float(acc["v_false"] / max(len(seeds), 1)),
        },
        "dark_vessel": {
            "uncorrelated_matched_to_truth": acc["dark_total"],
            "correctly_silent": acc["dark_correct"],
            "false_dark_rate": float(acc["false_dark"] / max(acc["dark_total"], 1)),
        },
        "attribution": {
            "confirmed_slicks_scored": acc["attrib_total"],
            "top1_accuracy": float(acc["attrib_hit"] / max(acc["attrib_total"], 1)),
            "source_findable": acc["findable"],
            "source_not_findable": acc["unfindable"],
            "top1_accuracy_findable_sources": float(
                acc["findable_hit"] / max(acc["findable"], 1)),
            "recall_at_any_rank": float(len(acc["ranks"]) / max(acc["attrib_total"], 1)),
            "mean_rank_of_true_source": (float(np.mean(acc["ranks"]))
                                         if acc["ranks"] else None),
            "no_suspect_returned": acc["attrib_none"],
            "declined_for_unknown_coverage": acc["coverage_refusals"],
            "median_release_distance_km": (float(np.median(acc["dist_err"]))
                                           if acc["dist_err"] else None),
            "median_release_time_error_h": (float(np.median(acc["time_err"]))
                                            if acc["time_err"] else None),
        },
    }


def save(report, path=None):
    path = Path(path or ARTIFACTS / "varuna_evaluation.json")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2))
    return path
