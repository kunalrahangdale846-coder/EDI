import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WORK = Path(os.environ.get("VARUNA_WORK", ROOT / "work"))
ARTIFACTS = Path(os.environ.get("VARUNA_ARTIFACTS", ROOT / "artifacts"))

GRID = int(os.environ.get("VARUNA_GRID", "512"))
PIXEL_M = float(os.environ.get("VARUNA_PIXEL_M", "150"))
LOOKS = float(os.environ.get("VARUNA_LOOKS", "4"))
SEED = int(os.environ.get("VARUNA_SEED", "26143"))

ORIGIN_LON = float(os.environ.get("VARUNA_LON", "68.50"))
ORIGIN_LAT = float(os.environ.get("VARUNA_LAT", "22.30"))

WIND_MIN = float(os.environ.get("VARUNA_WIND_MIN", "3.0"))
WIND_MAX = float(os.environ.get("VARUNA_WIND_MAX", "10.0"))
DAMPING_MAX = float(os.environ.get("VARUNA_DAMPING_MAX", "0.45"))
DARK_K = float(os.environ.get("VARUNA_DARK_K", "0.62"))
DARK_BACKGROUND_PX = int(os.environ.get("VARUNA_DARK_BACKGROUND_PX", "81"))
DARK_MIN_AREA_KM2 = float(os.environ.get("VARUNA_DARK_MIN_AREA", "2.0"))
DARK_MAX_AREA_KM2 = float(os.environ.get("VARUNA_DARK_MAX_AREA", "500.0"))
DARK_SEED_FRACTION = float(os.environ.get("VARUNA_DARK_SEED_FRAC", "0.35"))
DARK_REGION_DAMPING_MAX = float(os.environ.get("VARUNA_DARK_DAMPING_MAX", "0.82"))
CFAR_PFA = float(os.environ.get("VARUNA_CFAR_PFA", "1e-8"))
OIL_PROB_MIN = float(os.environ.get("VARUNA_OIL_PROB", "0.50"))

PARTICLES = int(os.environ.get("VARUNA_PARTICLES", "2000"))
DRIFT_MIN_H = float(os.environ.get("VARUNA_DRIFT_MIN_H", "1.5"))
DRIFT_MAX_H = float(os.environ.get("VARUNA_DRIFT_MAX_H", "8"))
DRIFT_STEP_S = 900.0
WIND_DRIFT_FACTOR = 0.03
DIFFUSIVITY = 12.0

ATTRIB_RADIUS_KM = float(os.environ.get("VARUNA_ATTRIB_KM", "8.0"))
ATTRIB_WINDOW_H = float(os.environ.get("VARUNA_ATTRIB_H", "2.0"))
MIN_PROB = float(os.environ.get("VARUNA_MIN_PROB", "0.15"))
AIS_MATCH_KM = float(os.environ.get("VARUNA_AIS_MATCH_KM", "3.0"))
AIS_COVERAGE_NM = float(os.environ.get("VARUNA_AIS_COVERAGE_NM", "50"))

SNAP_GPT = os.environ.get("VARUNA_SNAP_GPT", "gpt")
SCENE_KM = GRID * PIXEL_M / 1000.0

WORK.mkdir(parents=True, exist_ok=True)
ARTIFACTS.mkdir(parents=True, exist_ok=True)
