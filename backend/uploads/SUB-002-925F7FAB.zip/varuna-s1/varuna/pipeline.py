import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from varuna import ais, cfar, darkspots, drift_engine, environment, intersect
from varuna import oil_classifier
from varuna import patch_metrics, safe_reader, snap_preprocess
from varuna.config import (ARTIFACTS, ATTRIB_RADIUS_KM, DRIFT_MAX_H, OIL_PROB_MIN,
                           PARTICLES, PIXEL_M, WIND_MAX, WIND_MIN)


@dataclass
class Result:
    product: object
    scene: object
    regions: list
    features: np.ndarray
    oil_probability: np.ndarray
    detections: list
    correlated: list
    dark: list
    tracks: list
    coverage: object
    attributions: list
    environment: object = None
    stages: list = field(default_factory=list)

    def _geometry(self):
        frame = self.scene.frame
        h, w = self.scene.sigma0.shape
        corners_r = [0.0, 0.0, float(h - 1), float(h - 1)]
        corners_c = [0.0, float(w - 1), 0.0, float(w - 1)]
        lons, lats = frame.lonlat_of_px(np.array(corners_r), np.array(corners_c))
        bounds = [float(np.min(lons)), float(np.min(lats)),
                  float(np.max(lons)), float(np.max(lats))]

        correlated = {id(r["detection"]) for r in self.correlated}
        detections = []
        for rec in self.correlated + self.dark:
            d = rec["detection"]
            detections.append({
                "lon": round(rec["lon"], 5), "lat": round(rec["lat"], 5),
                "length_m": round(d.length_m), "snr_db": round(d.snr_db, 1),
                "ais_correlated": id(d) in correlated,
                "mmsi": rec["track"].mmsi if rec.get("track") and id(d) in correlated else None,
            })

        tracks = []
        for t in self.tracks:
            step = max(1, t.times_h.size // 24)
            lon, lat = frame.lonlat_of_km(t.x_km[::step], t.y_km[::step])
            tracks.append({
                "mmsi": t.mmsi, "name": t.name, "ship_type": t.ship_type,
                "flag": t.flag, "sog_kn": round(t.sog_kn, 1),
                "points": [[round(float(a), 5), round(float(b), 5), round(float(c), 2)]
                           for a, b, c in zip(lon, lat, t.times_h[::step])],
            })

        regions = []
        for r, p in zip(self.regions, self.oil_probability):
            rr, cc = np.nonzero(r.mask)
            step = max(1, rr.size // 160)
            lon, lat = frame.lonlat_of_px(rr[::step].astype(float), cc[::step].astype(float))
            regions.append({
                "index": r.index, "area_km2": round(float(r.area_km2), 2),
                "oil_probability": round(float(p), 4),
                "points": [[round(float(a), 5), round(float(b), 5)]
                           for a, b in zip(lon, lat)],
            })
        return bounds, detections, tracks, regions

    def to_dict(self):
        bounds, detections, tracks, regions = self._geometry()
        clouds = {}
        for a in self.attributions:
            bc = a.backcast
            if bc is None or a.best_hour is None:
                continue
            i = int(np.argmin(np.abs(bc.hours - a.best_hour)))
            step = max(1, bc.lon.shape[1] // 220)
            clouds[a.region_index] = [
                [round(float(x), 5), round(float(y), 5)]
                for x, y in zip(bc.lon[i][::step], bc.lat[i][::step])]
        return {
            "product": str(self.product.path),
            "acquired_utc": self.scene.acquired.isoformat(),
            "polarisation": self.scene.polarisation,
            "pixel_spacing_m": self.scene.pixel_spacing_m,
            "preprocessing_backend": self.scene.backend,
            "land_mask_source": self.scene.land_mask_source,
            "environment": self.environment.describe(),
            "wind_speed_ms": self.environment.wind_speed,
            "wind_in_detection_window": self.environment.wind_in_window,
            "drift_enabled": self.environment.usable_for_drift,
            "dark_regions": len(self.regions),
            "oil_probabilities": [round(float(p), 4) for p in self.oil_probability],
            "cfar_detections": len(self.detections),
            "ais_correlated": len(self.correlated),
            "dark_contacts": len(self.dark),
            "ais_tracks": len(self.tracks),
            "ais_coverage_known": bool(self.coverage.known),
            "ais_coverage_source": self.coverage.source,
            "stages": self.stages,
            "bounds_lon_lat": bounds,
            "detections": detections,
            "ais_tracks_geometry": tracks,
            "dark_region_geometry": regions,
            "attributions": [
                {
                    "region": a.region_index,
                    "oil_probability": round(a.oil_probability, 4),
                    "area_km2": round(a.area_km2, 2),
                    "centroid": {"lon": round(a.centroid_lonlat[0], 5),
                                 "lat": round(a.centroid_lonlat[1], 5)},
                    "drift_backend": a.drift_backend,
                    "coverage_note": a.coverage_note,
                    "release_cloud": clouds.get(a.region_index, []),
                    "suspects": [
                        {"rank": i + 1, "kind": s.kind, "label": s.label,
                         "mmsi": s.mmsi, "ship_type": s.ship_type, "flag": s.flag,
                         "score": round(s.score, 4),
                         "release_hours_before": round(s.release_hours_before, 2),
                         "cloud_fraction": round(s.cloud_fraction, 4),
                         "median_distance_km": round(s.distance_km, 2),
                         "required_speed_kn": (round(s.required_speed_kn, 1)
                                               if s.required_speed_kn else None),
                         "ais_gap": s.ais_gap,
                         "evidence": s.evidence}
                        for i, s in enumerate(a.suspects)
                    ],
                }
                for a in self.attributions
            ],
        }


def run(safe_path, classifier=None, ais_csv=None, shore_distance_km=None,
        particles=PARTICLES, force_internal_drift=False, force_internal_snap=False,
        oil_threshold=OIL_PROB_MIN, seed=0, env=None):
    stages = []
    product = safe_reader.read(safe_path)
    stages.append(f"read .SAFE: {Path(safe_path).name} [{product.polarisation}, "
                  f"{product.dn.shape[0]}x{product.dn.shape[1]} px @ "
                  f"{product.pixel_spacing_m:.0f} m]")

    scene = snap_preprocess.preprocess(product, force_internal=force_internal_snap)
    stages.append(f"preprocessing backend: {scene.backend} "
                  f"(calibration to sigma0, speckle filter, land mask via "
                  f"{scene.land_mask_source})")

    env = env if env is not None else environment.from_truth(scene.truth)
    stages.append(f"environment: {env.describe()}")
    if env.wind_in_window is False:
        stages.append(f"WIND GATE: {env.wind_speed:.1f} m/s is outside the "
                      f"{WIND_MIN:.0f}-{WIND_MAX:.0f} m/s window in which slick "
                      f"damping is detectable; results are not reliable")
    if not env.usable_for_drift:
        stages.append("DRIFT DISABLED: wind and current were not supplied, so the "
                      "reverse advection would be a diffusion-only no-op. Supply "
                      "them with --env to enable attribution.")

    regions = darkspots.detect(scene)
    stages.append(f"branch A: {len(regions)} dark regions above the contrast gate")

    features = patch_metrics.extract_all(scene, regions)
    stages.append(f"branch A: {features.shape[1] if features.size else 0} patch "
                  f"metrics per region ({', '.join(patch_metrics.NAMES)})")

    if classifier is None:
        classifier = oil_classifier.load()
    probs = classifier.predict_proba(features) if len(regions) else np.zeros(0)
    stages.append(f"branch A: {classifier.backend} classifier, "
                  f"{int((probs >= oil_threshold).sum())} regions above p={oil_threshold:.2f}")

    detections = cfar.detect(scene)
    stages.append(f"branch B: CA-CFAR (Pfa={cfar.PFA:.0e}, guard={cfar.GUARD}, "
                  f"train={cfar.TRAIN}) found {len(detections)} vessel targets")

    coverage = ais.coverage_from_scene(scene, shore_distance_km)
    if ais_csv:
        tracks = ais.load_csv(ais_csv, scene.acquired, scene.frame)
    else:
        tracks = ais.tracks_from_truth(scene.truth, coverage, seed=seed)
    stages.append(f"AIS: {len(tracks)} tracks, coverage {coverage.source}")

    located = intersect.locate(detections, scene.frame)
    correlated, dark = intersect.correlate_vessels(located, tracks)
    stages.append(f"branch B: {len(correlated)} CFAR targets correlate with AIS, "
                  f"{len(dark)} do not")

    u, v, wind_speed, wind_dir = env.drift_inputs()
    hours = drift_engine.candidate_hours()
    attributions = []
    for r, p in zip(regions, probs):
        if p < oil_threshold or not env.usable_for_drift:
            continue
        bc = drift_engine.backcast(scene, r, u, v, wind_speed, wind_dir,
                                   hours=DRIFT_MAX_H, n=particles,
                                   force_internal=force_internal_drift, seed=seed + r.index)
        attributions.append(intersect.attribute(r, float(p), bc, tracks, dark,
                                                hours, coverage, scene.frame,
                                                ATTRIB_RADIUS_KM))
    if attributions:
        stages.append(f"drift: {attributions[0].drift_backend} reverse advection, "
                      f"{particles} particles, {hours[0]:.1f}-{hours[-1]:.1f} h window")
    stages.append(f"intersection: {sum(len(a.suspects) for a in attributions)} "
                  f"suspects ranked across {len(attributions)} confirmed slicks")

    return Result(product=product, scene=scene, regions=regions, features=features,
                  oil_probability=probs, detections=detections, correlated=correlated,
                  dark=dark, tracks=tracks, coverage=coverage,
                  attributions=attributions, stages=stages, environment=env)


def save(result, path=None):
    path = Path(path or ARTIFACTS / "varuna_run.json")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result.to_dict(), indent=2))
    return path
