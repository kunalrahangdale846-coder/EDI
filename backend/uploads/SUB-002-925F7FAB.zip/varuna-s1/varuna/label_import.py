import json
from pathlib import Path

import numpy as np

MIN_OVERLAP = 0.30


def _rings(geometry):
    kind = geometry.get("type")
    coords = geometry.get("coordinates", [])
    if kind == "Polygon":
        return [coords[0]] if coords else []
    if kind == "MultiPolygon":
        return [poly[0] for poly in coords if poly]
    return []


def load_geojson(path):
    data = json.loads(Path(path).read_text())
    features = data.get("features", [data]) if isinstance(data, dict) else data
    out = []
    for feat in features:
        geom = feat.get("geometry", feat) if isinstance(feat, dict) else None
        if not geom:
            continue
        props = feat.get("properties", {}) if isinstance(feat, dict) else {}
        for ring in _rings(geom):
            arr = np.asarray(ring, dtype=np.float64)
            if arr.ndim == 2 and arr.shape[0] >= 3:
                out.append({"ring": arr[:, :2], "properties": props})
    return out


def _contains(ring, x, y):
    px = ring[:, 0]
    py = ring[:, 1]
    qx = np.roll(px, -1)
    qy = np.roll(py, -1)
    inside = np.zeros(x.shape, dtype=bool)
    for x0, y0, x1, y1 in zip(px, py, qx, qy):
        if y0 == y1:
            continue
        straddles = (y0 > y) != (y1 > y)
        if not straddles.any():
            continue
        xint = x0 + (y - y0) * (x1 - x0) / (y1 - y0)
        inside ^= straddles & (x < xint)
    return inside


def rasterise(polygons, frame, shape):
    h, w = shape
    rows, cols = np.mgrid[0:h, 0:w]
    lon, lat = frame.lonlat_of_px(rows.astype(np.float64), cols.astype(np.float64))
    x = np.asarray(lon).ravel()
    y = np.asarray(lat).ravel()
    mask = np.zeros(x.shape, dtype=bool)
    for poly in polygons:
        mask |= _contains(np.asarray(poly["ring"], dtype=np.float64), x, y)
    return mask.reshape(h, w)


def label_regions(regions, truth_mask, min_overlap=MIN_OVERLAP):
    labels = []
    for r in regions:
        overlap = float(truth_mask[r.mask].mean()) if r.mask.any() else 0.0
        labels.append(1 if overlap >= min_overlap else 0)
    return np.array(labels, dtype=int)


def append_dataset(path, X, y, groups):
    path = Path(path)
    X = np.atleast_2d(np.asarray(X, dtype=np.float64))
    y = np.asarray(y, dtype=int)
    groups = np.asarray(groups)
    if path.exists():
        prev = np.load(path, allow_pickle=True)
        X = np.vstack([prev["X"], X]) if prev["X"].size else X
        y = np.concatenate([prev["y"], y])
        groups = np.concatenate([prev["groups"].astype(str), groups.astype(str)])
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez(path, X=X, y=y, groups=groups.astype(str))
    return path, X.shape[0], int(y.sum())


def load_dataset(path):
    d = np.load(Path(path), allow_pickle=True)
    return d["X"], d["y"], d["groups"]
