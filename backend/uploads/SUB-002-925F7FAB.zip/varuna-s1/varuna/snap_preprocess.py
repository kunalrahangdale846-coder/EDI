import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from scipy import ndimage

from varuna.config import LOOKS, SNAP_GPT

SNAP_LOOKS = 15
SNAP_SPACING_M = 150.0
from varuna.safe_reader import Product

GRAPH = """<graph id="varuna-preprocess">
  <version>1.0</version>
  <node id="read">
    <operator>Read</operator>
    <parameters><file>{src}</file></parameters>
  </node>
  <node id="orbit">
    <operator>Apply-Orbit-File</operator>
    <sources><sourceProduct refid="read"/></sources>
    <parameters>
      <orbitType>Sentinel Precise (Auto Download)</orbitType>
      <continueOnFail>true</continueOnFail>
    </parameters>
  </node>
  <node id="border">
    <operator>Remove-GRD-Border-Noise</operator>
    <sources><sourceProduct refid="orbit"/></sources>
    <parameters>
      <selectedPolarisations>{pol}</selectedPolarisations>
      <borderLimit>500</borderLimit>
      <trimThreshold>0.5</trimThreshold>
    </parameters>
  </node>
  <node id="noise">
    <operator>ThermalNoiseRemoval</operator>
    <sources><sourceProduct refid="border"/></sources>
    <parameters>
      <selectedPolarisations>{pol}</selectedPolarisations>
      <removeThermalNoise>true</removeThermalNoise>
    </parameters>
  </node>
  <node id="calib">
    <operator>Calibration</operator>
    <sources><sourceProduct refid="noise"/></sources>
    <parameters>
      <outputSigmaBand>true</outputSigmaBand>
      <selectedPolarisations>{pol}</selectedPolarisations>
    </parameters>
  </node>
  <node id="multilook">
    <operator>Multilook</operator>
    <sources><sourceProduct refid="calib"/></sources>
    <parameters>
      <nRgLooks>{looks}</nRgLooks>
      <nAzLooks>{looks}</nAzLooks>
      <outputIntensity>true</outputIntensity>
    </parameters>
  </node>
  <node id="speckle">
    <operator>Speckle-Filter</operator>
    <sources><sourceProduct refid="multilook"/></sources>
    <parameters>
      <filter>Refined Lee</filter>
      <filterSizeX>5</filterSizeX>
      <filterSizeY>5</filterSizeY>
    </parameters>
  </node>
  <node id="terrain">
    <operator>Terrain-Correction</operator>
    <sources><sourceProduct refid="speckle"/></sources>
    <parameters>
      <demName>SRTM 3Sec</demName>
      <imgResamplingMethod>BILINEAR_INTERPOLATION</imgResamplingMethod>
      <pixelSpacingInMeter>{spacing}</pixelSpacingInMeter>
      <mapProjection>WGS84(DD)</mapProjection>
      <nodataValueAtSea>false</nodataValueAtSea>
    </parameters>
  </node>
  <node id="landsea">
    <operator>Land-Sea-Mask</operator>
    <sources><sourceProduct refid="terrain"/></sources>
    <parameters>
      <landMask>true</landMask>
      <useSRTM>true</useSRTM>
      <shorelineExtension>10</shorelineExtension>
    </parameters>
  </node>
  <node id="write">
    <operator>Write</operator>
    <sources><sourceProduct refid="landsea"/></sources>
    <parameters><file>{dst}</file><formatName>GeoTIFF</formatName></parameters>
  </node>
</graph>
"""


@dataclass
class Scene:
    sigma0: np.ndarray
    sea_mask: np.ndarray
    land_mask: np.ndarray
    bright_mask: np.ndarray
    acquired: object
    pixel_spacing_m: float
    polarisation: str
    backend: str
    land_mask_source: str
    frame: object = None
    wind_speed: float | None = None
    wind_dir_deg: float | None = None
    truth: dict = field(default_factory=dict)
    labels: object = None

    @property
    def sigma0_db(self):
        out = np.full(self.sigma0.shape, np.nan)
        pos = self.sigma0 > 0
        out[pos] = 10.0 * np.log10(self.sigma0[pos])
        return out

    @property
    def sea_sigma0_mean(self):
        clean = self.sea_mask & ~self.bright_mask
        return float(np.mean(self.sigma0[clean]))

    @property
    def clutter_mask(self):
        return self.sea_mask & ~self.bright_mask

    @property
    def wind_in_window(self):
        from varuna.config import WIND_MAX, WIND_MIN
        if self.wind_speed is None:
            return None
        return WIND_MIN <= self.wind_speed <= WIND_MAX


def snap_available(gpt=SNAP_GPT):
    return shutil.which(gpt) is not None


def _calibrate(dn, cal_constant):
    return (dn.astype(np.float64) / max(cal_constant, 1e-9)) ** 2


def _refined_lee(img, size=5, looks=LOOKS):
    cu = 1.0 / np.sqrt(looks)
    mean = ndimage.uniform_filter(img, size)
    sq = ndimage.uniform_filter(img * img, size)
    var = np.clip(sq - mean * mean, 0.0, None)
    ci = np.sqrt(var) / np.maximum(mean, 1e-12)
    w = np.clip(1.0 - (cu * cu) / np.maximum(ci * ci, 1e-12), 0.0, 1.0)
    return mean + w * (img - mean)


def _otsu(values, bins=128):
    hist, edges = np.histogram(values, bins=bins)
    hist = hist.astype(np.float64)
    total = hist.sum()
    if total <= 0:
        return None, 0.0
    centres = 0.5 * (edges[:-1] + edges[1:])
    w0 = np.cumsum(hist) / total
    w1 = 1.0 - w0
    m0 = np.cumsum(hist * centres) / np.maximum(np.cumsum(hist), 1e-9)
    total_mean = (hist * centres).sum() / total
    m1 = (total_mean - m0 * w0) / np.maximum(w1, 1e-9)
    between = w0 * w1 * (m0 - m1) ** 2
    k = int(np.nanargmax(between))
    return float(centres[k]), float(m1[k] - m0[k])


def _detect_land(sigma0, min_px=1500, min_separation_db=4.0, min_fraction=0.02):
    db = 10.0 * np.log10(np.maximum(sigma0, 1e-9))
    smooth = ndimage.uniform_filter(db, 31)
    thresh, separation = _otsu(smooth.ravel())
    if thresh is None or separation < min_separation_db:
        return np.zeros(sigma0.shape, dtype=bool)
    cand = smooth > thresh
    frac = cand.mean()
    if frac < min_fraction or frac > 0.60:
        return np.zeros(sigma0.shape, dtype=bool)
    cand = ndimage.binary_closing(cand, np.ones((11, 11)))
    cand = ndimage.binary_opening(cand, np.ones((9, 9)))
    lab, n = ndimage.label(cand)
    keep = np.zeros_like(cand)
    for i in range(1, n + 1):
        blob = lab == i
        if blob.sum() >= min_px:
            keep |= blob
    if not keep.any():
        return keep
    return ndimage.binary_dilation(keep, np.ones((9, 9)))


def _detect_bright(sigma0, sea, factor=6.0):
    if not sea.any():
        return np.zeros(sigma0.shape, dtype=bool)
    level = float(np.median(sigma0[sea]))
    return (sigma0 > factor * level) & sea


def _run_snap(product: Product, gpt=SNAP_GPT):
    tmp = Path(tempfile.mkdtemp(prefix="varuna-snap-"))
    graph = tmp / "graph.xml"
    dst = tmp / "preprocessed.tif"
    graph.write_text(GRAPH.format(src=str(product.path), dst=str(dst),
                                  pol=product.polarisation, looks=SNAP_LOOKS,
                                  spacing=SNAP_SPACING_M))
    subprocess.run([gpt, str(graph)], check=True, capture_output=True, timeout=3600)
    import tifffile
    return tifffile.imread(str(dst)).astype(np.float64)


def preprocess(product: Product, force_internal=False) -> Scene:
    backend = "internal"
    land_source = "otsu-bimodal sigma0 (fallback for SNAP Land-Sea-Mask)"
    if not force_internal and snap_available():
        try:
            sigma0 = _run_snap(product)
            backend = "snap-gpt"
            land_source = "srtm-land-sea-mask"
        except Exception:
            sigma0 = _refined_lee(_calibrate(product.dn, product.calibration_constant))
    else:
        sigma0 = _refined_lee(_calibrate(product.dn, product.calibration_constant))

    if backend == "snap-gpt":
        land = ~np.isfinite(sigma0) | (sigma0 <= 0)
        sigma0 = np.nan_to_num(sigma0, nan=0.0)
    else:
        land = _detect_land(sigma0)

    sea = ~land
    bright = _detect_bright(sigma0, sea)
    from varuna import frame as frame_mod
    from varuna.config import ORIGIN_LAT, ORIGIN_LON
    grid = frame_mod.flat(product.pixel_spacing_m, LOOKS, ORIGIN_LON, ORIGIN_LAT)
    return Scene(sigma0=sigma0, sea_mask=sea, land_mask=land, bright_mask=bright,
                 frame=grid,
                 acquired=product.acquired, pixel_spacing_m=product.pixel_spacing_m,
                 polarisation=product.polarisation, backend=backend,
                 land_mask_source=land_source,
                 wind_speed=product.wind_speed, wind_dir_deg=product.wind_dir_deg,
                 truth=product.truth, labels=product.labels)
