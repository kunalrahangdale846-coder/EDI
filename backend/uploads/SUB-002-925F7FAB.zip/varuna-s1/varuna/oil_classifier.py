import json
import pickle
from dataclasses import dataclass

import numpy as np
from sklearn.isotonic import IsotonicRegression
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
from sklearn.model_selection import GroupShuffleSplit

from varuna.config import ARTIFACTS
from varuna.patch_metrics import NAMES

MODEL_PATH = ARTIFACTS / "oil_classifier.pkl"
REPORT_PATH = ARTIFACTS / "oil_classifier_report.json"

try:
    from xgboost import XGBClassifier
    HAVE_XGB = True
except Exception:
    from sklearn.ensemble import GradientBoostingClassifier
    HAVE_XGB = False


@dataclass
class OilClassifier:
    model: object
    calibrator: object
    backend: str
    feature_names: list
    report: dict
    provenance: str = "simulated"

    @property
    def trained_on_real_imagery(self):
        return getattr(self, "provenance", "simulated") == "real"

    def predict_proba(self, X):
        X = np.atleast_2d(np.asarray(X, dtype=np.float64))
        if X.shape[0] == 0:
            return np.zeros(0)
        raw = self.model.predict_proba(X)[:, 1]
        out = self.calibrator.predict(raw) if self.calibrator is not None else raw
        return np.clip(out, 0.005, 0.995)

    def importances(self):
        imp = getattr(self.model, "feature_importances_", None)
        if imp is None:
            return {}
        return {n: float(v) for n, v in zip(self.feature_names, imp)}

    def save(self, path=MODEL_PATH):
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as fh:
            pickle.dump(self, fh)
        REPORT_PATH.write_text(json.dumps(self.report, indent=2))
        return path


def load(path=MODEL_PATH):
    with open(path, "rb") as fh:
        return pickle.load(fh)


def _new_model():
    if HAVE_XGB:
        return XGBClassifier(n_estimators=300, max_depth=3, learning_rate=0.06,
                             subsample=0.85, colsample_bytree=0.9,
                             reg_lambda=1.5, min_child_weight=2,
                             eval_metric="logloss", n_jobs=2, random_state=0)
    return GradientBoostingClassifier(n_estimators=300, max_depth=3,
                                      learning_rate=0.06, random_state=0)


def train(X, y, groups, calib_fraction=0.3, seed=0, provenance="simulated"):
    X = np.asarray(X, dtype=np.float64)
    y = np.asarray(y, dtype=int)
    groups = np.asarray(groups)

    splitter = GroupShuffleSplit(n_splits=1, test_size=calib_fraction, random_state=seed)
    fit_idx, cal_idx = next(splitter.split(X, y, groups))

    model = _new_model()
    model.fit(X[fit_idx], y[fit_idx])

    raw_cal = model.predict_proba(X[cal_idx])[:, 1]
    calibrator = None
    if len(np.unique(y[cal_idx])) > 1:
        calibrator = IsotonicRegression(out_of_bounds="clip")
        calibrator.fit(raw_cal, y[cal_idx])

    probs = calibrator.predict(raw_cal) if calibrator is not None else raw_cal
    report = {
        "backend": "xgboost" if HAVE_XGB else "sklearn-gbdt",
        "n_train": int(len(fit_idx)), "n_calibration": int(len(cal_idx)),
        "n_scenes": int(len(np.unique(groups))),
        "positive_rate": float(y.mean()),
        "holdout_roc_auc": float(roc_auc_score(y[cal_idx], probs)) if len(np.unique(y[cal_idx])) > 1 else None,
        "holdout_pr_auc": float(average_precision_score(y[cal_idx], probs)) if len(np.unique(y[cal_idx])) > 1 else None,
        "holdout_brier": float(brier_score_loss(y[cal_idx], probs)) if len(np.unique(y[cal_idx])) > 1 else None,
        "features": list(NAMES),
        "provenance": provenance,
    }
    clf = OilClassifier(model=model, calibrator=calibrator,
                        backend=report["backend"], feature_names=list(NAMES),
                        report=report, provenance=provenance)
    clf.report["feature_importance"] = clf.importances()
    return clf
