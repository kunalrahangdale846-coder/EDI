import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from varuna import (ais, cfar, darkspots, drift_engine, environment, frame,
                    intersect, patch_metrics, s1_real, snap_preprocess)
from varuna.config import ARTIFACTS, ATTRIB_RADIUS_KM, DRIFT_MAX_H, OIL_PROB_MIN, PARTICLES

COARSE_MULTILOOK = 15
FINE_MULTILOOK = 3


@dataclass
class RealResult:
    coarse: object
    fine: object
    scene: object
    fine_scene: object
    regions: list
    features: np.ndarray
    oil_probability: np.ndarray
    detections: list
    located: list
    correlated: list
    dark: list
    tracks: list
    coverage: object
    attributions: list
    env: object
    warnings: list = field(default_factory=list)
    stages: list = field(default_factory=list)

    def to_dict(self):
        c = self.coarse
        out = {
            "product": str(c.source),
            "acquired_utc": c.acquired.isoformat(),
            "polarisation": c.polarisation,
            "slick_grid": {"pixel_spacing_m": c.pixel_spacing_m,
                           "multilook": c.multilook,
                           "shape": list(c.shape),
                           "estimated_enl": _r(c.enl)},
            "vessel_grid": {"pixel_spacing_m": self.fine.pixel_spacing_m,
                            "multilook": self.fine.multilook,
                            "shape": list(self.fine.shape),
                            "estimated_enl": _r(self.fine.enl)},
            "thermal_noise_removed": c.denoised,
            "bounds_lon_lat": [round(v, 5) for v in c.bounds()],
            "land_fraction": round(float(self.scene.land_mask.mean()), 4),
            "environment": self.env.describe(),
            "drift_enabled": self.env.usable_for_drift,
            "dark_regions": len(self.regions),
            "cfar_detections": len(self.detections),
            "ais_tracks": len(self.tracks),
            "ais_correlated": len(self.correlated),
            "dark_contacts": len(self.dark),
            "ais_coverage_known": bool(self.coverage.known),
            "ais_coverage_source": self.coverage.source,
            "stages": self.stages,
            "warnings": self.warnings,
            "regions": [],
            "attributions": [],
        }
        for r, f, p in zip(self.regions, self.features, self.oil_probability):
            lon, lat = self.scene.frame.lonlat_of_px(*r.centroid_rc)
            out["regions"].append({
                "index": r.index,
                "area_km2": round(float(r.area_km2), 2),
                "centroid": {"lon": round(float(lon), 5), "lat": round(float(lat), 5)},
                "metrics": {n: round(float(v), 4)
                            for n, v in zip(patch_metrics.NAMES, f)},
                "oil_probability": round(float(p), 4),
            })
        for a in self.attributions:
            out["attributions"].append({
                "region": a.region_index,
                "oil_probability": round(a.oil_probability, 4),
                "centroid": {"lon": round(a.centroid_lonlat[0], 5),
                             "lat": round(a.centroid_lonlat[1], 5)},
                "drift_backend": a.drift_backend,
                "coverage_note": a.coverage_note,
                "suspects": [
                    {"rank": i + 1, "kind": s.kind, "label": s.label, "mmsi": s.mmsi,
                     "score": round(s.score, 4),
                     "release_hours_before": round(s.release_hours_before, 2),
                     "evidence": s.evidence}
                    for i, s in enumerate(a.suspects)],
            })
        return out


def _r(v):
    return None if v is None or not np.isfinite(v) else round(float(v), 1)


def _to_scene(real, speckle=True, land_mask=None, assume_all_sea=False):
    valid = getattr(real, "valid", None)
    sigma0 = np.nan_to_num(real.sigma0, nan=0.0, posinf=0.0, neginf=0.0)
    looks = real.enl if np.isfinite(real.enl) else 4.0
    if speckle:
        sigma0 = snap_preprocess._refined_lee(sigma0, size=5, looks=max(looks, 1.0))
    if assume_all_sea:
        land = np.zeros(sigma0.shape, dtype=bool)
        source = "operator asserted open water"
    elif land_mask is not None:
        land = np.asarray(land_mask, dtype=bool)
        source = "operator-supplied land mask"
    else:
        land = snap_preprocess._detect_land(sigma0)
        source = "otsu-bimodal sigma0 (no SRTM)"
    sea = ~land
    if valid is not None:
        sea = sea & valid
        if not valid.all():
            source = f"{source} + no-data exclusion"
    bright = snap_preprocess._detect_bright(sigma0, sea)
    grid = frame.geocoded(real.lon, real.lat, real.pixel_spacing_m, looks)
    return snap_preprocess.Scene(
        sigma0=sigma0, sea_mask=sea, land_mask=land, bright_mask=bright,
        acquired=real.acquired, pixel_spacing_m=real.pixel_spacing_m,
        polarisation=real.polarisation, backend="python-l1-reader",
        land_mask_source=source,
        truth={}, labels=None, frame=grid)


def run(safe_path, classifier=None, coarse_multilook=COARSE_MULTILOOK,
        fine_multilook=FINE_MULTILOOK, aoi=None, denoise=True, env=None,
        ais_csv=None, shore_distance_km=None, particles=PARTICLES,
        oil_threshold=OIL_PROB_MIN, force_internal_drift=False,
        allow_synthetic_model=False, pfa=cfar.PFA, seed=0,
        land_mask=None, assume_all_sea=False):
    warnings, stages = [], []
    env = env if env is not None else environment.unknown()

    coarse = s1_real.read_grd(safe_path, multilook=coarse_multilook, aoi=aoi,
                              denoise=denoise)
    stages.append(f"slick grid: {coarse.shape[0]}x{coarse.shape[1]} px @ "
                  f"{coarse.pixel_spacing_m:.0f} m (multilook {coarse_multilook}x), "
                  f"ENL {coarse.enl:.0f}")
    fine = s1_real.read_grd(safe_path, multilook=fine_multilook, aoi=aoi,
                            denoise=denoise)
    stages.append(f"vessel grid: {fine.shape[0]}x{fine.shape[1]} px @ "
                  f"{fine.pixel_spacing_m:.0f} m (multilook {fine_multilook}x), "
                  f"ENL {fine.enl:.0f}")
    if not coarse.denoised:
        warnings.append("no thermal noise LUT applied; dark-region contrast near "
                        "the swath edges may be unreliable")

    scene = _to_scene(coarse, land_mask=land_mask, assume_all_sea=assume_all_sea)
    fine_scene = _to_scene(fine, assume_all_sea=assume_all_sea)
    stages.append(f"land mask: {scene.land_mask_source} "
                  f"({scene.land_mask.mean()*100:.1f}% of the scene)")
    stages.append(f"environment: {env.describe()}")

    regions = darkspots.detect(scene)
    features = patch_metrics.extract_all(scene, regions)
    stages.append(f"branch A: {len(regions)} dark regions above the contrast gate")

    probs = np.zeros(len(regions))
    if classifier is not None and len(regions):
        synthetic = not getattr(classifier, "trained_on_real_imagery", False)
        if synthetic and not allow_synthetic_model:
            warnings.append(
                "classifier was trained on SIMULATED slicks; its probabilities are "
                "not valid on real imagery, so they are withheld. Retrain on a "
                "labelled real corpus, or pass allow_synthetic_model=True to see "
                "them anyway.")
            stages.append("branch A: classifier withheld (simulated provenance)")
        else:
            probs = classifier.predict_proba(features)
            if synthetic:
                warnings.append("probabilities come from a SIMULATED-provenance "
                                "classifier and are not validated on real imagery")
            stages.append(f"branch A: {classifier.backend} classifier "
                          f"({getattr(classifier, 'provenance', 'simulated')} provenance)")

    detections = cfar.detect(fine_scene, pfa=pfa)
    stages.append(f"branch B: CA-CFAR at {fine.pixel_spacing_m:.0f} m "
                  f"(Pfa={pfa:.0e}, looks={fine_scene.frame.looks:.0f}) "
                  f"found {len(detections)} targets")

    located = intersect.locate(detections, fine_scene.frame, scene.frame)

    coverage = ais.coverage_from_scene(scene, shore_distance_km)
    tracks = ais.load_csv(ais_csv, scene.acquired, scene.frame) if ais_csv else []
    if not tracks:
        warnings.append("no AIS history supplied; attribution cannot name a vessel")
    stages.append(f"AIS: {len(tracks)} tracks, coverage {coverage.source}")

    correlated, dark = intersect.correlate_vessels(located, tracks)
    stages.append(f"branch B: {len(correlated)} targets correlate with AIS, "
                  f"{len(dark)} do not")

    attributions = []
    if not env.usable_for_drift:
        warnings.append("wind and current were not supplied, so reverse advection "
                        "would be a diffusion-only no-op; attribution is disabled")
    elif tracks or dark:
        u, v, ws, wd = env.drift_inputs()
        hours = drift_engine.candidate_hours()
        for r, p in zip(regions, probs):
            if p < oil_threshold:
                continue
            bc = drift_engine.backcast(scene, r, u, v, ws, wd, hours=DRIFT_MAX_H,
                                       n=particles, force_internal=force_internal_drift,
                                       seed=seed + r.index, frame=scene.frame)
            attributions.append(intersect.attribute(
                r, float(p), bc, tracks, dark, hours, coverage, scene.frame,
                ATTRIB_RADIUS_KM))
        if attributions:
            stages.append(f"drift: {attributions[0].drift_backend} reverse advection, "
                          f"{particles} particles")

    return RealResult(coarse=coarse, fine=fine, scene=scene, fine_scene=fine_scene,
                      regions=regions, features=features, oil_probability=probs,
                      detections=detections, located=located, correlated=correlated,
                      dark=dark, tracks=tracks, coverage=coverage,
                      attributions=attributions, env=env,
                      warnings=warnings, stages=stages + coarse.notes)


def save(result, path=None):
    path = Path(path or ARTIFACTS / "varuna_real_run.json")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result.to_dict(), indent=2))
    return path


class RunPipeline:
    def __init__(self, config=None, classifier=None, **defaults):
        from pathlib import Path as _Path
        if config is not None and not _Path(config).exists():
            raise FileNotFoundError(f"config not found: {config}")
        self.config = config
        self.classifier = classifier
        self.defaults = defaults

    def run(self, scene_id=None, product=None, **kwargs):
        target = product or scene_id
        if target is None:
            raise ValueError("pass a .SAFE path as scene_id= or product=")
        options = dict(self.defaults)
        options.update(kwargs)
        options.setdefault("classifier", self.classifier)
        return run(target, **options)
