import numpy as np
from scipy import ndimage


NAMES = ["damping_ratio", "shape_complexity", "elongation",
         "edge_contrast", "internal_cv", "area_km2"]


def _axes(mask):
    r, c = np.nonzero(mask)
    if r.size < 3:
        return 1.0, 1.0
    rr = r - r.mean()
    cc = c - c.mean()
    cov = np.cov(np.vstack([cc, rr]))
    vals = np.linalg.eigvalsh(cov)
    vals = np.clip(vals, 1e-9, None)
    return float(np.sqrt(vals[1])), float(np.sqrt(vals[0]))


def axis_angle(mask):
    r, c = np.nonzero(mask)
    if r.size < 3:
        return None
    cov = np.cov(np.vstack([c - c.mean(), r - r.mean()]))
    vals, vecs = np.linalg.eigh(cov)
    major = vecs[:, int(np.argmax(vals))]
    return float(np.degrees(np.arctan2(major[0], major[1])))


def _perimeter(mask):
    er = ndimage.binary_erosion(mask, np.ones((3, 3)))
    return float((mask & ~er).sum())


def extract(scene, region):
    sigma0 = scene.sigma0
    clean = scene.clutter_mask
    core = region.mask & clean
    ring = region.ring & clean
    if core.sum() < 5 or ring.sum() < 20:
        core, ring = region.mask, region.ring
    inside = sigma0[core]
    outside = sigma0[ring]

    inside_mean = float(inside.mean())
    outside_mean = float(outside.mean())
    outside_std = float(outside.std()) + 1e-12

    damping_ratio = inside_mean / max(outside_mean, 1e-12)

    spacing = scene.frame.pixel_spacing_m
    perim = _perimeter(region.mask) * spacing
    area_m2 = region.area_px * spacing ** 2
    complexity = perim ** 2 / (4.0 * np.pi * max(area_m2, 1e-9))

    major, minor = _axes(region.mask)
    elongation = major / max(minor, 1e-9)

    grad = np.hypot(*np.gradient(sigma0))
    edge = region.mask & ~ndimage.binary_erosion(region.mask, np.ones((3, 3))) & clean
    edge_contrast = float(grad[edge].mean()) / outside_std if edge.sum() else 0.0

    internal_cv = float(inside.std()) / max(inside_mean, 1e-12)

    return np.array([damping_ratio, complexity, elongation,
                     edge_contrast, internal_cv, region.area_km2], dtype=np.float64)


def extract_all(scene, regions):
    if not regions:
        return np.zeros((0, len(NAMES)))
    return np.vstack([extract(scene, r) for r in regions])
