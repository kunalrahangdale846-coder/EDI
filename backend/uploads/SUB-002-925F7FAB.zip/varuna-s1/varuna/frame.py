from dataclasses import dataclass

import numpy as np

DEG_PER_KM_LAT = 1.0 / 111.32


def _poly_terms(degree):
    return [(i, j) for i in range(degree + 1) for j in range(degree + 1 - i)]


def _fit(a, b, value, degree=2):
    terms = _poly_terms(degree)
    sa = float(np.ptp(a)) or 1.0
    sb = float(np.ptp(b)) or 1.0
    oa, ob = float(a.min()), float(b.min())
    A = np.column_stack([(((a - oa) / sa) ** i) * (((b - ob) / sb) ** j)
                         for i, j in terms])
    coef, *_ = np.linalg.lstsq(A, value, rcond=None)
    return (coef, (oa, ob), (sa, sb), terms)


def _apply(model, a, b):
    coef, (oa, ob), (sa, sb), terms = model
    aa = (np.asarray(a, dtype=np.float64) - oa) / sa
    bb = (np.asarray(b, dtype=np.float64) - ob) / sb
    out = np.zeros(np.broadcast(aa, bb).shape, dtype=np.float64)
    for c, (i, j) in zip(coef, terms):
        out = out + c * (aa ** i) * (bb ** j)
    return out


@dataclass
class Frame:
    pixel_spacing_m: float
    looks: float
    origin_lon: float
    origin_lat: float

    @property
    def px_km(self):
        return self.pixel_spacing_m / 1000.0

    @property
    def px_km2(self):
        return (self.pixel_spacing_m / 1000.0) ** 2

    def km_of_lonlat(self, lon, lat):
        y = (np.asarray(lat, dtype=np.float64) - self.origin_lat) / DEG_PER_KM_LAT
        x = ((np.asarray(lon, dtype=np.float64) - self.origin_lon)
             * np.cos(np.deg2rad(self.origin_lat)) / DEG_PER_KM_LAT)
        return x, y

    def lonlat_of_km(self, x_km, y_km):
        lat = self.origin_lat + np.asarray(y_km, dtype=np.float64) * DEG_PER_KM_LAT
        lon = (self.origin_lon + np.asarray(x_km, dtype=np.float64)
               * DEG_PER_KM_LAT / np.cos(np.deg2rad(self.origin_lat)))
        return lon, lat

    def lonlat_of_px(self, row, col):
        raise NotImplementedError

    def px_of_lonlat(self, lon, lat):
        raise NotImplementedError

    def km_of_px(self, row, col):
        return self.km_of_lonlat(*self.lonlat_of_px(row, col))

    def px_of_km(self, x_km, y_km):
        return self.px_of_lonlat(*self.lonlat_of_km(x_km, y_km))

    def with_looks(self, looks):
        import copy
        out = copy.copy(self)
        out.looks = float(looks)
        return out


@dataclass
class FlatFrame(Frame):
    def lonlat_of_px(self, row, col):
        x = np.asarray(col, dtype=np.float64) * self.px_km
        y = np.asarray(row, dtype=np.float64) * self.px_km
        return self.lonlat_of_km(x, y)

    def px_of_lonlat(self, lon, lat):
        x, y = self.km_of_lonlat(lon, lat)
        return y / self.px_km, x / self.px_km


@dataclass
class GeocodedFrame(Frame):
    lon: np.ndarray = None
    lat: np.ndarray = None
    _fwd_lon: tuple = None
    _fwd_lat: tuple = None
    _inv_row: tuple = None
    _inv_col: tuple = None

    def lonlat_of_px(self, row, col):
        return (_apply(self._fwd_lon, row, col), _apply(self._fwd_lat, row, col))

    def px_of_lonlat(self, lon, lat):
        return (_apply(self._inv_row, lon, lat), _apply(self._inv_col, lon, lat))


def flat(pixel_spacing_m, looks, origin_lon, origin_lat):
    return FlatFrame(pixel_spacing_m=float(pixel_spacing_m), looks=float(looks),
                     origin_lon=float(origin_lon), origin_lat=float(origin_lat))


def geocoded(lon, lat, pixel_spacing_m, looks, sample=24):
    lon = np.asarray(lon, dtype=np.float64)
    lat = np.asarray(lat, dtype=np.float64)
    h, w = lon.shape
    rr = np.linspace(0, h - 1, min(sample, h)).astype(int)
    cc = np.linspace(0, w - 1, min(sample, w)).astype(int)
    R, C = np.meshgrid(rr, cc, indexing="ij")
    lo = lon[R, C].ravel()
    la = lat[R, C].ravel()
    Rf = R.ravel().astype(np.float64)
    Cf = C.ravel().astype(np.float64)
    return GeocodedFrame(
        pixel_spacing_m=float(pixel_spacing_m), looks=float(looks),
        origin_lon=float(np.median(lon)), origin_lat=float(np.median(lat)),
        lon=lon, lat=lat,
        _fwd_lon=_fit(Rf, Cf, lo), _fwd_lat=_fit(Rf, Cf, la),
        _inv_row=_fit(lo, la, Rf), _inv_col=_fit(lo, la, Cf))
