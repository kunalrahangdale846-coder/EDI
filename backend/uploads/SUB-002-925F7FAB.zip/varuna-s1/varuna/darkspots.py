from dataclasses import dataclass

import numpy as np
from scipy import ndimage


from varuna.config import (DARK_BACKGROUND_PX, DARK_K, DARK_MAX_AREA_KM2,
                           DARK_MIN_AREA_KM2, DARK_REGION_DAMPING_MAX,
                           DARK_SEED_FRACTION)

MIN_AREA_KM2 = DARK_MIN_AREA_KM2
MAX_AREA_KM2 = DARK_MAX_AREA_KM2
BACKGROUND_PX = DARK_BACKGROUND_PX
SEED_FRACTION = DARK_SEED_FRACTION
REGION_DAMPING_MAX = DARK_REGION_DAMPING_MAX


@dataclass
class Region:
    index: int
    mask: np.ndarray
    ring: np.ndarray
    area_px: int
    area_km2: float
    centroid_rc: tuple
    bbox: tuple


def _adaptive_threshold(sigma0, clutter, k=DARK_K, background_px=BACKGROUND_PX):
    filled = np.where(clutter, sigma0, np.nan)
    med = np.nanmedian(filled)
    filled = np.where(np.isfinite(filled), filled, med)
    background = ndimage.uniform_filter(filled, background_px)
    return (sigma0 < k * background) & clutter


def detect(scene, k=DARK_K, min_area_km2=MIN_AREA_KM2, max_area_km2=MAX_AREA_KM2,
           seed_fraction=SEED_FRACTION, region_damping_max=REGION_DAMPING_MAX,
           background_px=BACKGROUND_PX):
    px_km2 = scene.frame.px_km2
    clutter = scene.clutter_mask
    raw = _adaptive_threshold(scene.sigma0, clutter, k, background_px)
    seed = ndimage.binary_opening(raw, np.ones((3, 3)))
    grown = ndimage.binary_closing(seed, np.ones((5, 5)))
    grown = ndimage.binary_fill_holes(grown)

    lab, n = ndimage.label(grown)
    regions = []
    for i in range(1, n + 1):
        mask = lab == i
        area_px = int(mask.sum())
        area = area_px * px_km2
        if area < min_area_km2 or area > max_area_km2:
            continue
        if seed[mask].mean() < seed_fraction:
            continue
        sl = ndimage.find_objects(mask.astype(np.uint8))[0]
        if not scene.sea_mask[mask].all():
            continue
        dil = ndimage.binary_dilation(mask, np.ones((15, 15)))
        ring = dil & ~ndimage.binary_dilation(mask, np.ones((7, 7))) & clutter
        if ring.sum() < 200:
            continue
        core = mask & clutter
        if core.sum() < 20:
            continue
        if scene.sigma0[core].mean() > region_damping_max * scene.sigma0[ring].mean():
            continue
        r, c = ndimage.center_of_mass(mask)
        regions.append(Region(index=len(regions), mask=mask, ring=ring,
                              area_px=area_px, area_km2=area,
                              centroid_rc=(float(r), float(c)),
                              bbox=(sl[0].start, sl[0].stop, sl[1].start, sl[1].stop)))
    return regions
