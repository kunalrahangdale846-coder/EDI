import csv
from dataclasses import dataclass, field
from datetime import timedelta

import numpy as np
from scipy import ndimage

from varuna.config import AIS_COVERAGE_NM

NM_KM = 1.852
HISTORY_H = 12.0
PING_MIN = 3.0


@dataclass
class Track:
    mmsi: int
    name: str
    ship_type: str
    flag: str
    length_m: float
    times_h: np.ndarray
    x_km: np.ndarray
    y_km: np.ndarray
    sog_kn: float
    cog_deg: float
    gaps: list = field(default_factory=list)

    def position_at(self, hours_before):
        if self.times_h.size == 0:
            return None
        if hours_before < self.times_h.min() - 0.25 or hours_before > self.times_h.max() + 0.25:
            return None
        order = np.argsort(self.times_h)
        t = self.times_h[order]
        return (float(np.interp(hours_before, t, self.x_km[order])),
                float(np.interp(hours_before, t, self.y_km[order])))

    def covered_at(self, hours_before):
        for lo, hi in self.gaps:
            if lo <= hours_before <= hi:
                return False
        return True


@dataclass
class Coverage:
    known: bool
    shore_x_km: float | None
    shore_y_km: float | None
    radius_km: float
    source: str

    def inside(self, x_km, y_km):
        if not self.known:
            return None
        d = np.hypot(np.asarray(x_km) - self.shore_x_km, np.asarray(y_km) - self.shore_y_km)
        out = d <= self.radius_km
        return bool(out) if out.ndim == 0 else out


def coverage_from_scene(scene, shore_distance_km=None):
    radius = AIS_COVERAGE_NM * NM_KM
    if scene.land_mask.any():
        r, c = ndimage.center_of_mass(scene.land_mask)
        x, y = scene.frame.km_of_px(float(r), float(c))
        return Coverage(known=True, shore_x_km=float(x), shore_y_km=float(y),
                        radius_km=radius, source="land-mask-in-scene")
    if shore_distance_km is not None:
        h, w = scene.sigma0.shape
        mid_x, mid_y = scene.frame.km_of_px(h / 2.0, w / 2.0)
        return Coverage(known=True, shore_x_km=float(mid_x) - float(shore_distance_km),
                        shore_y_km=float(mid_y), radius_km=radius,
                        source="operator-supplied shore distance")
    return Coverage(known=False, shore_x_km=None, shore_y_km=None,
                    radius_km=radius, source="unknown: no coast in scene")


def _gaps_for(rng, covered_fraction):
    if covered_fraction > 0.95 or rng.random() > 0.35:
        return []
    lo = float(rng.uniform(0.5, HISTORY_H - 2.0))
    return [(lo, lo + float(rng.uniform(0.5, 2.5)))]


def tracks_from_truth(truth, coverage, seed=0):
    rng = np.random.default_rng(seed)
    times = np.arange(0.0, HISTORY_H + 1e-9, PING_MIN / 60.0)
    out = []
    for v in truth.get("vessels", []):
        if not v["broadcasting"]:
            continue
        rad = np.deg2rad(v["course_deg"])
        speed_kmh = v["speed_ms"] * 3.6
        x = v["x_km"] - np.sin(rad) * speed_kmh * times
        y = v["y_km"] - np.cos(rad) * speed_kmh * times
        x = x + rng.normal(0, 0.02, x.shape)
        y = y + rng.normal(0, 0.02, y.shape)
        keep = np.ones(times.shape, dtype=bool)
        if coverage.known:
            keep = coverage.inside(x, y)
        if not keep.any():
            continue
        frac = float(keep.mean())
        out.append(Track(mmsi=v["mmsi"], name=v["name"], ship_type=v["ship_type"],
                         flag=v["flag"], length_m=v["length_m"],
                         times_h=times[keep], x_km=x[keep], y_km=y[keep],
                         sog_kn=v["speed_ms"] / 0.514444, cog_deg=v["course_deg"],
                         gaps=_gaps_for(rng, frac)))
    return out


def load_csv(path, acquired, frame):
    rows = {}
    with open(path, newline="") as fh:
        for rec in csv.DictReader(fh):
            mmsi = int(rec["mmsi"])
            stamp = rec["timestamp"]
            from datetime import datetime
            t = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
            hours = (acquired - t).total_seconds() / 3600.0
            x, y = frame.km_of_lonlat(float(rec["lon"]), float(rec["lat"]))
            rows.setdefault(mmsi, {"meta": rec, "t": [], "x": [], "y": []})
            rows[mmsi]["t"].append(hours)
            rows[mmsi]["x"].append(float(x))
            rows[mmsi]["y"].append(float(y))
    out = []
    for mmsi, r in rows.items():
        meta = r["meta"]
        out.append(Track(mmsi=mmsi, name=meta.get("name", str(mmsi)),
                         ship_type=meta.get("ship_type", "Unknown"),
                         flag=meta.get("flag", "---"),
                         length_m=float(meta.get("length_m", 0) or 0),
                         times_h=np.array(r["t"]), x_km=np.array(r["x"]),
                         y_km=np.array(r["y"]),
                         sog_kn=float(meta.get("sog", 0) or 0),
                         cog_deg=float(meta.get("cog", 0) or 0)))
    return out


def write_csv(path, tracks, acquired, frame):
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["mmsi", "name", "ship_type", "flag", "length_m",
                    "timestamp", "lon", "lat", "sog", "cog"])
        for t in tracks:
            lon, lat = frame.lonlat_of_km(t.x_km, t.y_km)
            for h, lo, la in zip(t.times_h, np.atleast_1d(lon), np.atleast_1d(lat)):
                stamp = (acquired - timedelta(hours=float(h))).isoformat()
                w.writerow([t.mmsi, t.name, t.ship_type, t.flag,
                            f"{t.length_m:.0f}", stamp, f"{lo:.6f}", f"{la:.6f}",
                            f"{t.sog_kn:.1f}", f"{t.cog_deg:.1f}"])
    return path
