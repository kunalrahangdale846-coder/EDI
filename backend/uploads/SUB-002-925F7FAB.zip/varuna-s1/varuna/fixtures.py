from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import tifffile

CAL_LINES = 12
CAL_PIXELS = 21
GEO_LINES = 10
GEO_PIXELS = 21


def _cal_constant(line, pixel, n_lines, n_samples):
    return 280.0 + 60.0 * (pixel / max(n_samples - 1, 1)) + 5.0 * (line / max(n_lines - 1, 1))


def _noise_power(line, pixel, n_lines, n_samples):
    return 120.0 + 90.0 * (pixel / max(n_samples - 1, 1))


def _lonlat(line, pixel, lon0, lat0, n_lines, n_samples):
    u = pixel / max(n_samples - 1, 1)
    v = line / max(n_lines - 1, 1)
    lon = lon0 + 2.30 * u + 0.06 * v + 0.04 * u * v
    lat = lat0 - 1.55 * v + 0.05 * u - 0.03 * u * v
    return lon, lat


def _vector_list(name, item, value_name, n_lines, n_samples, fn):
    lines = np.linspace(0, n_lines - 1, CAL_LINES).astype(int)
    pixels = np.linspace(0, n_samples - 1, CAL_PIXELS).astype(int)
    out = [f'  <{name} count="{len(lines)}">']
    for ln in lines:
        vals = [fn(float(ln), float(px), n_lines, n_samples) for px in pixels]
        out.append(f"    <{item}>")
        out.append(f"      <azimuthTime>2026-03-14T05:42:11.000000</azimuthTime>")
        out.append(f"      <line>{ln}</line>")
        out.append(f'      <pixel count="{len(pixels)}">'
                   + " ".join(str(int(p)) for p in pixels) + "</pixel>")
        out.append(f'      <{value_name} count="{len(vals)}">'
                   + " ".join(f"{v:.6e}" for v in vals) + f"</{value_name}>")
        out.append(f"    </{item}>")
    out.append(f"  </{name}>")
    return "\n".join(out)


def write_realistic_safe(path, sigma0_true, lon0=68.2, lat0=23.4,
                         spacing=10.0, acquired=None, seed=0,
                         decoy_tags=False, border_px=0):
    safe = Path(path)
    (safe / "measurement").mkdir(parents=True, exist_ok=True)
    (safe / "annotation" / "calibration").mkdir(parents=True, exist_ok=True)
    acquired = acquired or datetime(2026, 3, 14, 5, 42, 11, tzinfo=timezone.utc)
    rng = np.random.default_rng(seed)

    n_lines, n_samples = sigma0_true.shape
    rr = np.arange(n_lines, dtype=np.float64)[:, None]
    cc = np.arange(n_samples, dtype=np.float64)[None, :]
    A = _cal_constant(rr, cc, n_lines, n_samples)
    noise = _noise_power(rr, cc, n_lines, n_samples)

    power = sigma0_true * A ** 2 + noise
    dn = np.clip(np.sqrt(np.clip(power, 0, None)), 0, 65535).astype(np.uint16)
    if border_px > 0:
        b = int(border_px)
        dn[:b, :] = 0
        dn[-b:, :] = 0
        dn[:, :b] = 0
        dn[:, -b:] = 0

    stamp = acquired.strftime("%Y%m%dT%H%M%S")
    base = f"s1a-iw-grd-vv-{stamp}-{stamp}-051234-0630a1-001"
    tifffile.imwrite(str(safe / "measurement" / f"{base}.tiff"), dn)

    geo_lines = np.linspace(0, n_lines - 1, GEO_LINES).astype(int)
    geo_pixels = np.linspace(0, n_samples - 1, GEO_PIXELS).astype(int)
    pts = []
    for ln in geo_lines:
        for px in geo_pixels:
            lo, la = _lonlat(float(ln), float(px), lon0, lat0, n_lines, n_samples)
            pts.append(f"""      <geolocationGridPoint>
        <azimuthTime>{acquired.isoformat()}</azimuthTime>
        <line>{ln}</line>
        <pixel>{px}</pixel>
        <latitude>{la:.9f}</latitude>
        <longitude>{lo:.9f}</longitude>
        <height>0.0</height>
        <incidenceAngle>{30.0 + 12.0*px/max(n_samples-1,1):.6f}</incidenceAngle>
      </geolocationGridPoint>""")

    decoy_spacing = "<rangePixelSpacing>2.33</rangePixelSpacing>" if decoy_tags else ""
    decoy_lines = "<numberOfLines>999999</numberOfLines>" if decoy_tags else ""
    ann = f"""<?xml version="1.0" encoding="UTF-8"?>
<product>
  <adsHeader>
    <missionId>S1A</missionId>
    <productType>GRD</productType>
    <polarisation>VV</polarisation>
    <mode>IW</mode>
    <startTime>{acquired.isoformat()}</startTime>
  </adsHeader>
  <generalAnnotation>
    <productInformation>{decoy_spacing}</productInformation>
    <downlinkInformationList><downlinkInformation>{decoy_lines}</downlinkInformation>
    </downlinkInformationList>
  </generalAnnotation>
  <imageAnnotation>
    <imageInformation>
      <productFirstLineUtcTime>{acquired.isoformat()}</productFirstLineUtcTime>
      <rangePixelSpacing>{spacing}</rangePixelSpacing>
      <azimuthPixelSpacing>{spacing}</azimuthPixelSpacing>
      <numberOfSamples>{n_samples}</numberOfSamples>
      <numberOfLines>{n_lines}</numberOfLines>
    </imageInformation>
  </imageAnnotation>
  <geolocationGrid>
    <geolocationGridPointList count="{len(pts)}">
{chr(10).join(pts)}
    </geolocationGridPointList>
  </geolocationGrid>
</product>
"""
    (safe / "annotation" / f"{base}.xml").write_text(ann)

    cal = f"""<?xml version="1.0" encoding="UTF-8"?>
<calibration>
  <adsHeader><polarisation>VV</polarisation></adsHeader>
{_vector_list("calibrationVectorList", "calibrationVector", "sigmaNought",
              n_lines, n_samples, _cal_constant)}
</calibration>
"""
    (safe / "annotation" / "calibration" / f"calibration-{base}.xml").write_text(cal)

    noise_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<noise>
  <adsHeader><polarisation>VV</polarisation></adsHeader>
{_vector_list("noiseRangeVectorList", "noiseRangeVector", "noiseRangeLut",
              n_lines, n_samples, _noise_power)}
</noise>
"""
    (safe / "annotation" / "calibration" / f"noise-{base}.xml").write_text(noise_xml)

    (safe / "manifest.safe").write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<xfdu:XFDU xmlns:xfdu="urn:ccsds:schema:xfdu:1">\n'
        '  <informationPackageMap><contentUnit textInfo="Sentinel-1 IW Level-1 GRD Product"/>'
        '</informationPackageMap>\n</xfdu:XFDU>\n')
    return safe


def synthetic_ocean(n_lines=1600, n_samples=2400, seed=0, looks=4.0):
    rng = np.random.default_rng(seed)
    base = np.full((n_lines, n_samples), 0.035)
    from scipy import ndimage
    swell = ndimage.gaussian_filter(rng.normal(0, 1, (n_lines, n_samples)), 60)
    base = base * (1.0 + 0.12 * swell / max(np.abs(swell).max(), 1e-9))

    yy, xx = np.mgrid[0:n_lines, 0:n_samples]
    cy, cx = n_lines * 0.45, n_samples * 0.55
    ang = np.deg2rad(28.0)
    rx = (xx - cx) * np.cos(ang) + (yy - cy) * np.sin(ang)
    ry = -(xx - cx) * np.sin(ang) + (yy - cy) * np.cos(ang)
    slick = (rx / (n_samples * 0.16)) ** 2 + (ry / (n_lines * 0.022)) ** 2 < 1.0
    soft = ndimage.gaussian_filter(slick.astype(float), 8)
    soft /= max(soft.max(), 1e-9)
    truth = base * (1.0 - 0.72 * soft)

    for _ in range(14):
        r = int(rng.integers(60, n_lines - 60))
        c = int(rng.integers(60, n_samples - 60))
        n = int(rng.integers(10, 30))
        truth[r:r + n, c:c + max(2, n // 4)] = rng.uniform(8.0, 60.0)

    observed = truth * rng.gamma(looks, 1.0 / looks, truth.shape)
    return observed, slick
