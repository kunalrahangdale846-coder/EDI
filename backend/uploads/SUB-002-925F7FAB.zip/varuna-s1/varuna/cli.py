import argparse
import json
import sys
from pathlib import Path

import numpy as np

from varuna import ais, dashboard, evaluate, oil_classifier, pipeline, simulate
from varuna.config import ARTIFACTS, OIL_PROB_MIN, PARTICLES, SEED, WORK


def _train(args):
    seeds = list(range(args.seed, args.seed + args.scenes))
    X, y, groups = evaluate.build_dataset(seeds)
    if X.size == 0:
        print("no dark regions produced; nothing to train on", file=sys.stderr)
        return 1
    clf = oil_classifier.train(X, y, groups, seed=args.seed)
    path = clf.save()
    r = clf.report
    print(f"trained {r['backend']} on {r['n_train']} regions from {r['n_scenes']} scenes")
    print(f"  positive rate      {r['positive_rate']:.3f}")
    print(f"  holdout ROC-AUC    {r['holdout_roc_auc']:.3f}")
    print(f"  holdout PR-AUC     {r['holdout_pr_auc']:.3f}")
    print(f"  holdout Brier      {r['holdout_brier']:.4f}")
    print("  feature importance")
    for k, v in sorted(r["feature_importance"].items(), key=lambda kv: -kv[1]):
        print(f"    {k:<18} {v:.3f}")
    print(f"model -> {path}")
    return 0


def _simulate(args):
    from varuna import safe_reader
    out = Path(args.out) if args.out else WORK / f"scene_{args.seed}.SAFE"
    safe = simulate.write_product(out, args.seed)
    product = safe_reader.read(safe)
    truth = product.truth
    oil = [s for s in truth["slicks"] if s["kind"] == "oil"]
    print(f"wrote {safe}")
    print(f"  acquired {product.acquired.isoformat()}")
    print(f"  wind {truth['wind_speed']:.1f} m/s from {truth['wind_dir_deg']:.0f} deg")
    print(f"  {len(truth['vessels'])} vessels, {len(oil)} oil slicks, "
          f"{len(truth['slicks']) - len(oil)} look-alikes, land={truth['has_land']}")
    for s in oil:
        print(f"    oil slick {s['area_km2']:.1f} km2 released {s['release_age_h']:.1f} h "
              f"earlier by MMSI {s['source_mmsi']} "
              f"({'broadcasting' if s['broadcasting'] else 'SILENT'}, "
              f"{'in scene' if s['source_in_scene'] else 'departed'})")
    if args.ais_csv:
        cov = ais.Coverage(known=True, shore_x_km=0.0, shore_y_km=0.0,
                           radius_km=1e9, source="full export")
        tracks = ais.tracks_from_truth(truth, cov, seed=args.seed)
        from varuna import frame as frame_mod
        from varuna.config import ORIGIN_LAT, ORIGIN_LON
        fr = frame_mod.flat(product.pixel_spacing_m, 4.0, ORIGIN_LON, ORIGIN_LAT)
        ais.write_csv(args.ais_csv, tracks, product.acquired, fr)
        print(f"  AIS history -> {args.ais_csv} ({len(tracks)} broadcasting vessels)")
    return 0


def _run(args):
    clf = oil_classifier.load(Path(args.model)) if args.model else oil_classifier.load()
    res = pipeline.run(args.product, classifier=clf, ais_csv=args.ais_csv,
                       shore_distance_km=args.shore_km, particles=args.particles,
                       force_internal_drift=args.no_opendrift,
                       force_internal_snap=args.no_snap,
                       oil_threshold=args.threshold, seed=args.seed)
    dashboard.print_result(res)
    if args.json:
        p = pipeline.save(res, args.json)
        print(f"\nmachine-readable output -> {p}")
    return 0


def _evaluate(args):
    clf = oil_classifier.load(Path(args.model)) if args.model else oil_classifier.load()
    seeds = list(range(args.seed, args.seed + args.scenes))
    report = evaluate.evaluate(clf, seeds, particles=args.particles,
                               force_internal_drift=not args.opendrift)
    path = evaluate.save(report)
    c, f, d, a = (report["classifier"], report["cfar"],
                  report["dark_vessel"], report["attribution"])
    print(f"evaluated {report['n_scenes']} held-out scenes")
    print("")
    print("oil vs look-alike")
    print(f"  regions            {c['n_regions']}   positive rate {c['positive_rate']:.3f}")
    print(f"  ROC-AUC            {c['roc_auc']:.3f}")
    print(f"  PR-AUC             {c['pr_auc']:.3f}")
    print(f"  Brier              {c['brier']:.4f}")
    print(f"  precision / recall {c['precision']:.3f} / {c['recall']:.3f}")
    print("")
    print("CFAR vessel detection")
    print(f"  recall             {f['recall']:.3f}  over "
          f"{f['true_vessels_in_analysable_sea']} vessels in analysable sea")
    print(f"  excluded by mask   {f['vessels_excluded_by_land_mask']}  "
          f"(inside the coastal exclusion strip)")
    print(f"  false alarms       {f['false_alarms_per_scene']:.2f} per scene")
    print("")
    print("dark vessel calls")
    print(f"  uncorrelated       {d['uncorrelated_matched_to_truth']}")
    print(f"  correctly silent   {d['correctly_silent']}")
    print(f"  false dark rate    {d['false_dark_rate']:.3f}")
    print("")
    print("source attribution")
    print(f"  slicks scored      {a['confirmed_slicks_scored']}")
    print(f"  top-1 accuracy     {a['top1_accuracy']:.3f}  (all confirmed slicks)")
    print(f"  top-1 accuracy     {a['top1_accuracy_findable_sources']:.3f}  "
          f"(the {a['source_findable']} slicks whose source was findable at all)")
    print(f"  source unfindable  {a['source_not_findable']}  "
          f"(silent vessel already outside the scene, or outside AIS coverage)")
    print(f"  recall any rank    {a['recall_at_any_rank']:.3f}")
    if a["mean_rank_of_true_source"]:
        print(f"  mean true rank     {a['mean_rank_of_true_source']:.2f}")
    if a["median_release_time_error_h"] is not None:
        print(f"  release time error {a['median_release_time_error_h']:.2f} h (median)")
    print(f"  no suspect         {a['no_suspect_returned']}   "
          f"declined for unknown AIS coverage: {a['declined_for_unknown_coverage']}")
    print(f"\nreport -> {path}")
    return 0


def _demo(args):
    safe = simulate.write_product(WORK / f"demo_{args.seed}.SAFE", args.seed)
    print(f"synthetic Sentinel-1 IW GRD product written to {safe}\n")
    if not oil_classifier.MODEL_PATH.exists():
        print("no trained classifier found, training on 60 scenes first\n")
        ns = argparse.Namespace(seed=9000, scenes=60)
        _train(ns)
        print("")
    args2 = argparse.Namespace(product=str(safe), model=None, ais_csv=None,
                               shore_km=None, particles=args.particles,
                               no_opendrift=False, no_snap=False,
                               threshold=OIL_PROB_MIN, seed=args.seed,
                               json=str(ARTIFACTS / "demo_run.json"))
    return _run(args2)


def _real(args):
    from varuna import environment, figures, real_pipeline
    clf = None
    if not args.no_classifier:
        try:
            clf = oil_classifier.load(Path(args.model)) if args.model else oil_classifier.load()
        except FileNotFoundError:
            print("no trained classifier found; running detection only")

    aoi = None
    if args.aoi:
        vals = [float(v) for v in args.aoi.split(",")]
        if len(vals) != 4:
            print("--aoi needs lon_min,lat_min,lon_max,lat_max", file=sys.stderr)
            return 2
        aoi = tuple(vals)

    env = environment.from_json(args.env) if args.env else environment.unknown()

    res = real_pipeline.run(args.product, classifier=clf, aoi=aoi,
                            coarse_multilook=args.multilook,
                            fine_multilook=args.fine_multilook,
                            denoise=not args.no_denoise, env=env,
                            ais_csv=args.ais_csv, shore_distance_km=args.shore_km,
                            particles=args.particles,
                            force_internal_drift=args.no_opendrift,
                            allow_synthetic_model=args.allow_synthetic_model,
                            assume_all_sea=args.assume_all_sea, seed=args.seed)
    c = res.coarse
    print("=" * 78)
    print("VARUNA  |  real Sentinel-1 product")
    print("=" * 78)
    print(f"product        {c.source}")
    print(f"acquired       {c.acquired.isoformat()}   {c.polarisation}")
    lo, la, hi_lo, hi_la = c.bounds()
    print(f"bounds         {la:.4f}N..{hi_la:.4f}N  {lo:.4f}E..{hi_lo:.4f}E")
    print(f"land fraction  {res.scene.land_mask.mean()*100:.1f}%")
    print("")
    for st in res.stages:
        print(f"  . {st}")
    print("")
    if res.warnings:
        print("WARNINGS")
        for w in res.warnings:
            print(f"  ! {w}")
        print("")
    print(f"dark regions   {len(res.regions)}")
    if res.regions:
        print(f"  {'#':>2} {'area km2':>9} {'lat':>9} {'lon':>9} "
              f"{'damping':>8} {'elong':>7} {'p(oil)':>7}")
        for r, f, p in zip(res.regions, res.features, res.oil_probability):
            lon, lat = res.scene.frame.lonlat_of_px(*r.centroid_rc)
            print(f"  {r.index:>2} {r.area_km2:9.1f} {float(lat):9.4f} "
                  f"{float(lon):9.4f} {f[0]:8.3f} {f[2]:7.2f} {p:7.3f}")
    print(f"CFAR targets   {len(res.detections)}  "
          f"({len(res.correlated)} AIS-correlated, {len(res.dark)} dark)")
    if res.attributions:
        print("")
        for a in res.attributions:
            print(f"  SLICK {a.region_index}  {a.coverage_note}")
            for i, sus in enumerate(a.suspects[:5]):
                ident = f"MMSI {sus.mmsi}" if sus.mmsi else "no identity"
                print(f"    #{i+1} [{sus.kind.upper()}] {sus.label}  {ident}  "
                      f"score {sus.score:.3f}  t-{sus.release_hours_before:.1f}h")
    print("")
    out = real_pipeline.save(res, args.json)
    print(f"json    -> {out}")
    if not args.no_figure:
        if figures.available():
            png = figures.real_overlay(res, args.figure)
            print(f"figure  -> {png}")
        else:
            print("figure  -> skipped (matplotlib not installed; "
                  "pip install matplotlib)")
    return 0


def _label(args):
    from varuna import darkspots, label_import, patch_metrics, real_pipeline, s1_real
    aoi = tuple(float(v) for v in args.aoi.split(",")) if args.aoi else None
    real = s1_real.read_grd(args.product, multilook=args.multilook, aoi=aoi)
    scene = real_pipeline._to_scene(real, assume_all_sea=args.assume_all_sea)
    regions = darkspots.detect(scene)
    if not regions:
        print("no dark regions detected; nothing to label")
        return 1
    feats = patch_metrics.extract_all(scene, regions)
    polys = label_import.load_geojson(args.labels)
    truth = label_import.rasterise(polys, scene.frame, scene.sigma0.shape)
    y = label_import.label_regions(regions, truth, args.min_overlap)
    groups = np.array([Path(args.product).name] * len(regions))
    path, total, positives = label_import.append_dataset(args.dataset, feats, y, groups)
    print(f"{len(polys)} labelled polygons -> {int(truth.sum())} truth pixels")
    print(f"{len(regions)} detected regions: {int(y.sum())} oil, {int((y==0).sum())} look-alike")
    print(f"dataset {path}: {total} rows, {positives} positive")
    return 0


def _train_real(args):
    from varuna import label_import
    X, y, groups = label_import.load_dataset(args.dataset)
    if len(np.unique(y)) < 2:
        print("dataset needs both classes before training", file=sys.stderr)
        return 1
    clf = oil_classifier.train(X, y, groups, seed=0, provenance="real")
    path = clf.save(Path(args.out) if args.out else oil_classifier.MODEL_PATH)
    r = clf.report
    print(f"trained {r['backend']} on {r['n_train']} real regions "
          f"from {r['n_scenes']} scenes")
    for k in ("holdout_roc_auc", "holdout_pr_auc", "holdout_brier"):
        if r.get(k) is not None:
            print(f"  {k:<18} {r[k]:.3f}")
    print(f"provenance: real   model -> {path}")
    return 0


def _serve(args):
    try:
        from varuna import api  # noqa
        import uvicorn  # noqa
    except ImportError:
        print("the web extras are not installed:\n"
              "  .venv/bin/pip install -r requirements-web.txt", file=sys.stderr)
        return 1
    from varuna import api
    from varuna.api import STATIC
    if not (STATIC / "index.html").exists():
        print("dashboard bundle missing; serving the JSON API only "
              "(rebuild with: cd frontend && npm install && node build.mjs)")
    print(f"dashboard  http://{args.host}:{args.port}")
    print(f"api        http://{args.host}:{args.port}/api/state")
    import uvicorn
    uvicorn.run(api.create_app(), host=args.host, port=args.port, log_level="warning")
    return 0


def _doctor(args):
    from varuna import doctor
    text, n_fail = doctor.report(args.product, args.polarisation)
    print(text)
    return 1 if n_fail else 0


def _env_template(args):
    from varuna import environment
    p = environment.write_template(args.out)
    print(f"wrote {p}")
    print("fill in wind and current for the scene centre at acquisition time")
    print("  ERA5 10 m wind : Copernicus Climate Data Store (cds.climate.copernicus.eu)")
    print("  surface current: CMEMS (marine.copernicus.eu) or HYCOM")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="varuna",
                                description="SAR oil-spill source attribution")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("simulate", help="write a synthetic Sentinel-1 .SAFE product")
    s.add_argument("--seed", type=int, default=SEED)
    s.add_argument("--out")
    s.add_argument("--ais-csv")
    s.set_defaults(fn=_simulate)

    s = sub.add_parser("train", help="train the oil / look-alike classifier")
    s.add_argument("--scenes", type=int, default=120)
    s.add_argument("--seed", type=int, default=9000)
    s.set_defaults(fn=_train)

    s = sub.add_parser("run", help="run the full pipeline over one .SAFE product")
    s.add_argument("product")
    s.add_argument("--model")
    s.add_argument("--ais-csv")
    s.add_argument("--shore-km", type=float)
    s.add_argument("--particles", type=int, default=PARTICLES)
    s.add_argument("--threshold", type=float, default=OIL_PROB_MIN)
    s.add_argument("--seed", type=int, default=0)
    s.add_argument("--json")
    s.add_argument("--no-opendrift", action="store_true")
    s.add_argument("--no-snap", action="store_true")
    s.set_defaults(fn=_run)

    s = sub.add_parser("evaluate", help="score the pipeline on held-out scenes")
    s.add_argument("--scenes", type=int, default=40)
    s.add_argument("--seed", type=int, default=50000)
    s.add_argument("--model")
    s.add_argument("--particles", type=int, default=600)
    s.add_argument("--opendrift", action="store_true")
    s.set_defaults(fn=_evaluate)

    s = sub.add_parser("real", help="run detection over a real Sentinel-1 .SAFE product")
    s.add_argument("product")
    s.add_argument("--aoi", help="lon_min,lat_min,lon_max,lat_max")
    s.add_argument("--multilook", type=int, default=15)
    s.add_argument("--model")
    s.add_argument("--json")
    s.add_argument("--figure")
    s.add_argument("--fine-multilook", type=int, default=3)
    s.add_argument("--env", help="JSON file with wind and current")
    s.add_argument("--ais-csv")
    s.add_argument("--shore-km", type=float)
    s.add_argument("--particles", type=int, default=1500)
    s.add_argument("--seed", type=int, default=0)
    s.add_argument("--no-denoise", action="store_true")
    s.add_argument("--no-classifier", action="store_true")
    s.add_argument("--no-figure", action="store_true")
    s.add_argument("--no-opendrift", action="store_true")
    s.add_argument("--allow-synthetic-model", action="store_true")
    s.add_argument("--assume-all-sea", action="store_true")
    s.set_defaults(fn=_real)

    s = sub.add_parser("serve", help="serve the web dashboard and the JSON API")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8501)
    s.set_defaults(fn=_serve)

    s = sub.add_parser("doctor", help="check a real .SAFE product before running")
    s.add_argument("product")
    s.add_argument("--polarisation", default="vv")
    s.set_defaults(fn=_doctor)

    s = sub.add_parser("label", help="label detections in a real scene from a GeoJSON")
    s.add_argument("product")
    s.add_argument("labels", help="GeoJSON of known slick polygons")
    s.add_argument("--dataset", default="artifacts/real_dataset.npz")
    s.add_argument("--aoi")
    s.add_argument("--multilook", type=int, default=15)
    s.add_argument("--min-overlap", type=float, default=0.30)
    s.add_argument("--assume-all-sea", action="store_true")
    s.set_defaults(fn=_label)

    s = sub.add_parser("train-real", help="train the classifier on a labelled real dataset")
    s.add_argument("--dataset", default="artifacts/real_dataset.npz")
    s.add_argument("--out")
    s.set_defaults(fn=_train_real)

    s = sub.add_parser("env-template", help="write a wind/current JSON template")
    s.add_argument("--out", default="environment.json")
    s.set_defaults(fn=_env_template)

    s = sub.add_parser("demo", help="simulate a scene and run the pipeline on it")
    s.add_argument("--seed", type=int, default=SEED)
    s.add_argument("--particles", type=int, default=1200)
    s.set_defaults(fn=_demo)

    args = p.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
