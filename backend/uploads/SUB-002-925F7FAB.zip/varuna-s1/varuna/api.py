import json
import time
from pathlib import Path

from varuna.config import ARTIFACTS

STATIC = Path(__file__).resolve().parent / "static"
STARTED = time.time()


def _load(path, default=None):
    p = Path(path)
    if not p.exists():
        return default
    try:
        return json.loads(p.read_text())
    except Exception:
        return default


def state():
    run = _load(ARTIFACTS / "demo_run.json") or _load(ARTIFACTS / "varuna_real_run.json")
    return {
        "run": run,
        "evaluation": _load(ARTIFACTS / "varuna_evaluation.json"),
        "classifier": _load(ARTIFACTS / "oil_classifier_report.json"),
        "health": health(),
    }


def health():
    from varuna import cfar, drift_engine, oil_classifier, snap_preprocess
    from varuna.config import (AIS_COVERAGE_NM, ATTRIB_RADIUS_KM, DARK_K,
                               DRIFT_MAX_H, DRIFT_MIN_H, PIXEL_M, WIND_MAX, WIND_MIN)
    report = _load(oil_classifier.REPORT_PATH) or {}
    checks = [
        {"name": "oil classifier", "ok": oil_classifier.MODEL_PATH.exists(),
         "detail": (f"{report.get('backend', 'unknown')}, "
                    f"provenance {report.get('provenance', 'simulated')}")
                   if oil_classifier.MODEL_PATH.exists() else "not trained"},
        {"name": "gradient booster", "ok": oil_classifier.HAVE_XGB,
         "detail": "xgboost" if oil_classifier.HAVE_XGB else "sklearn GBDT fallback"},
        {"name": "OpenDrift", "ok": drift_engine.opendrift_available(),
         "detail": "available" if drift_engine.opendrift_available()
                   else "not installed; internal Lagrangian back-caster in use"},
        {"name": "ESA SNAP gpt", "ok": snap_preprocess.snap_available(),
         "detail": "on PATH" if snap_preprocess.snap_available()
                   else "not installed; NumPy L1 reader in use"},
    ]
    return {
        "uptime_s": round(time.time() - STARTED, 1),
        "checks": checks,
        "config": {
            "pixel_spacing_m": PIXEL_M,
            "wind_window_ms": [WIND_MIN, WIND_MAX],
            "dark_contrast_gate": DARK_K,
            "cfar_pfa": cfar.PFA,
            "drift_window_h": [DRIFT_MIN_H, DRIFT_MAX_H],
            "attribution_radius_km": ATTRIB_RADIUS_KM,
            "ais_coverage_nm": AIS_COVERAGE_NM,
        },
    }


def doctor(product):
    from varuna import doctor as doc
    checks, facts = doc.inspect(product)
    return {"product": str(product),
            "checks": [{"level": l, "message": m} for l, m in checks],
            "facts": {k: (list(v) if isinstance(v, tuple) else v)
                      for k, v in facts.items()},
            "blocking": sum(1 for l, _ in checks if l == "fail")}


def create_app():
    from fastapi import FastAPI, HTTPException
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import FileResponse

    app = FastAPI(title="VARUNA-S1", version="1.0",
                  description="Sentinel-1 oil-slick detection and source attribution")
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"],
                       allow_headers=["*"])

    @app.get("/api/state")
    def _state():
        return state()

    @app.get("/api/run")
    def _run():
        s = state()
        if s["run"] is None:
            raise HTTPException(404, "no run artifact; run `varuna run` first")
        return s["run"]

    @app.get("/api/evaluation")
    def _evaluation():
        s = state()
        if s["evaluation"] is None:
            raise HTTPException(404, "no evaluation artifact; run `varuna evaluate`")
        return s["evaluation"]

    @app.get("/api/classifier")
    def _classifier():
        s = state()
        if s["classifier"] is None:
            raise HTTPException(404, "no classifier report; run `varuna train`")
        return s["classifier"]

    @app.get("/api/health")
    def _health():
        return health()

    @app.get("/api/doctor")
    def _doctor(product: str):
        if not Path(product).exists():
            raise HTTPException(404, f"{product} not found")
        return doctor(product)

    @app.post("/api/run")
    def _execute(product: str, particles: int = 1500):
        from varuna import oil_classifier, pipeline
        if not Path(product).exists():
            raise HTTPException(404, f"{product} not found")
        try:
            clf = oil_classifier.load()
        except FileNotFoundError:
            raise HTTPException(409, "no trained classifier; run `varuna train` first")
        res = pipeline.run(product, classifier=clf, particles=particles)
        pipeline.save(res, ARTIFACTS / "demo_run.json")
        return res.to_dict()

    @app.get("/")
    def _index():
        index = STATIC / "index.html"
        if not index.exists():
            raise HTTPException(404, "dashboard not built; see frontend/README.md")
        return FileResponse(index)

    if STATIC.exists():
        from fastapi.staticfiles import StaticFiles
        app.mount("/", StaticFiles(directory=str(STATIC), html=True), name="static")

    return app
