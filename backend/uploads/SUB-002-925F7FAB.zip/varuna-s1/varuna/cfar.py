from dataclasses import dataclass

import numpy as np
from scipy import ndimage

from varuna.config import CFAR_PFA, LOOKS

GUARD = 7
TRAIN = 21
PFA = CFAR_PFA
MIN_PX = 1
MAX_PX = 400


@dataclass
class VesselDetection:
    index: int
    centroid_rc: tuple
    area_px: int
    length_m: float
    peak_sigma0: float
    snr_db: float


def _ring_mean(img, guard=GUARD, train=TRAIN):
    outer = ndimage.uniform_filter(img, train) * (train ** 2)
    inner = ndimage.uniform_filter(img, guard) * (guard ** 2)
    n = train ** 2 - guard ** 2
    return (outer - inner) / n


def threshold_factor(pfa=PFA, looks=LOOKS):
    return looks * (pfa ** (-1.0 / looks) - 1.0)


def detect(scene, pfa=PFA, guard=GUARD, train=TRAIN, looks=None):
    sigma0 = np.where(scene.sea_mask, scene.sigma0, 0.0)
    clutter = _ring_mean(sigma0, guard, train)
    clutter = np.maximum(clutter, 1e-12)
    looks = float(looks if looks is not None else scene.frame.looks)
    alpha = threshold_factor(pfa, looks)
    hits = (sigma0 > alpha * clutter) & scene.sea_mask

    hits = ndimage.binary_closing(hits, np.ones((3, 3)))
    lab, n = ndimage.label(hits, structure=np.ones((3, 3)))
    out = []
    for i in range(1, n + 1):
        mask = lab == i
        area = int(mask.sum())
        if area < MIN_PX or area > MAX_PX:
            continue
        r, c = ndimage.center_of_mass(mask)
        rr, cc = np.nonzero(mask)
        length = float(max(np.ptp(rr), np.ptp(cc)) + 1) * scene.frame.pixel_spacing_m
        peak = float(sigma0[mask].max())
        bg = float(clutter[mask].mean())
        out.append(VesselDetection(index=len(out), centroid_rc=(float(r), float(c)),
                                   area_px=area, length_m=length, peak_sigma0=peak,
                                   snr_db=10.0 * np.log10(peak / max(bg, 1e-12))))
    return out
