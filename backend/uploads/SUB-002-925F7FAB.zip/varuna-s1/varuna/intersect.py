from dataclasses import dataclass, field

import numpy as np

from varuna.config import AIS_MATCH_KM, ATTRIB_RADIUS_KM, MIN_PROB

DARK_MIN_KN = 2.0
DARK_MAX_KN = 22.0
DARK_PENALTY = 0.50
DARK_SPEED_MEAN_KN = 12.0
DARK_SPEED_LOG_SD = 0.45
DARK_BEARING_POWER = 2.0
KN_KMH = 1.852


def _speed_prior(kn):
    kn = np.clip(kn, 1e-6, None)
    z = (np.log(kn) - np.log(DARK_SPEED_MEAN_KN)) / DARK_SPEED_LOG_SD
    return np.exp(-0.5 * z * z)


def _bearing_weight(dx, dy, axis_deg):
    if axis_deg is None:
        return np.ones_like(dx)
    ax = np.sin(np.deg2rad(axis_deg))
    ay = np.cos(np.deg2rad(axis_deg))
    norm = np.hypot(dx, dy)
    cos = np.abs((dx * ax + dy * ay) / np.maximum(norm, 1e-9))
    return cos ** DARK_BEARING_POWER


@dataclass
class Suspect:
    kind: str
    label: str
    mmsi: int | None
    ship_type: str
    flag: str
    score: float
    release_hours_before: float
    cloud_fraction: float
    distance_km: float
    evidence: list = field(default_factory=list)
    required_speed_kn: float | None = None
    ais_gap: bool = False
    x_km: float | None = None
    y_km: float | None = None


@dataclass
class Attribution:
    region_index: int
    oil_probability: float
    area_km2: float
    centroid_lonlat: tuple
    drift_backend: str
    suspects: list
    coverage_known: bool
    coverage_note: str
    best_hour: float | None
    backcast: object = None


def locate(detections, source_frame, ref_frame=None):
    ref = ref_frame if ref_frame is not None else source_frame
    out = []
    for det in detections:
        lon, lat = source_frame.lonlat_of_px(det.centroid_rc[0], det.centroid_rc[1])
        x, y = ref.km_of_lonlat(lon, lat)
        out.append(dict(detection=det, lon=float(lon), lat=float(lat),
                        x_km=float(x), y_km=float(y),
                        spacing_m=source_frame.pixel_spacing_m))
    return out


def correlate_vessels(records, tracks, match_km=AIS_MATCH_KM):
    correlated, dark = [], []
    for rec in records:
        best, bd = None, 1e9
        for t in tracks:
            p = t.position_at(0.0)
            if p is None:
                continue
            d = float(np.hypot(p[0] - rec["x_km"], p[1] - rec["y_km"]))
            if d < bd:
                bd, best = d, t
        rec = dict(rec, track=best, distance_km=bd)
        (correlated if best is not None and bd <= match_km else dark).append(rec)
    return correlated, dark


def _cloud_at(backcast, hour):
    i = int(np.argmin(np.abs(backcast.hours - hour)))
    return backcast.frame.km_of_lonlat(backcast.lon[i], backcast.lat[i])


def score_tracks(backcast, tracks, hours, radius_km=ATTRIB_RADIUS_KM):
    out = []
    for t in tracks:
        best = None
        for h in hours:
            p = t.position_at(h)
            if p is None:
                continue
            cx, cy = _cloud_at(backcast, h)
            d = np.hypot(cx - p[0], cy - p[1])
            frac = float((d <= radius_km).mean())
            if frac <= 0:
                continue
            cand = (frac, h, float(np.median(d)), t.covered_at(h))
            if best is None or cand[0] > best[0]:
                best = cand
        if best is None:
            continue
        frac, h, dist, covered = best
        ev = [f"AIS track passes the back-cast release cloud {h:.1f} h before acquisition",
              f"{frac*100:.0f}% of drift particles within {radius_km:.0f} km of the reported position",
              f"median particle-to-vessel distance {dist:.1f} km"]
        if not covered:
            ev.append("AIS reporting gap spans the release window")
        out.append(Suspect(kind="ais", label=t.name, mmsi=t.mmsi,
                           ship_type=t.ship_type, flag=t.flag,
                           score=frac, release_hours_before=h,
                           cloud_fraction=frac, distance_km=dist,
                           evidence=ev, ais_gap=not covered))
    return out


def score_dark(backcast, dark_records, hours, axis_deg=None,
               radius_km=ATTRIB_RADIUS_KM):
    out = []
    for i, rec in enumerate(dark_records):
        best = None
        for h in hours:
            cx, cy = _cloud_at(backcast, h)
            dx = rec["x_km"] - cx
            dy = rec["y_km"] - cy
            d = np.hypot(dx, dy)
            required = d / max(h, 1e-6) / KN_KMH
            gate = (required >= DARK_MIN_KN) & (required <= DARK_MAX_KN)
            w = gate * _speed_prior(required) * _bearing_weight(dx, dy, axis_deg)
            frac = float(w.mean())
            if frac <= 1e-4:
                continue
            sel = gate if gate.any() else np.ones_like(gate, dtype=bool)
            cand = (frac, h, float(np.median(d[sel])), float(np.median(required[sel])),
                    float(_bearing_weight(dx, dy, axis_deg).mean()))
            if best is None or cand[0] > best[0]:
                best = cand
        if best is None:
            continue
        frac, h, dist, req, bear = best
        det = rec["detection"]
        ev = [f"CFAR target with no AIS correlation within {AIS_MATCH_KM:.1f} km",
              f"kinematically reachable from the back-cast cloud at {h:.1f} h "
              f"before acquisition",
              f"implied transit speed {req:.1f} kn over {dist:.1f} km",
              f"bearing agreement with the slick axis {bear:.2f}",
              f"radar extent {det.length_m:.0f} m "
              f"(+/- one {rec.get('spacing_m', 0):.0f} m pixel), "
              f"peak SNR {det.snr_db:.1f} dB"]
        out.append(Suspect(kind="dark", label=f"Dark contact D{i+1}", mmsi=None,
                           ship_type="unidentified", flag="---",
                           score=DARK_PENALTY * frac, release_hours_before=h,
                           cloud_fraction=frac, distance_km=dist,
                           evidence=ev, required_speed_kn=req,
                           x_km=rec["x_km"], y_km=rec["y_km"]))
    return out


def attribute(region, oil_probability, backcast, tracks, dark_records, hours,
              coverage, frame, radius_km=ATTRIB_RADIUS_KM):
    suspects = score_tracks(backcast, tracks, hours, radius_km)
    cx, cy = frame.km_of_px(region.centroid_rc[0], region.centroid_rc[1])
    cx, cy = float(cx), float(cy)
    inside = coverage.inside(cx, cy) if coverage.known else None

    if inside is True:
        from varuna.patch_metrics import axis_angle
        suspects += score_dark(backcast, dark_records, hours,
                               axis_angle(region.mask), radius_km)
        note = (f"slick lies inside the {coverage.radius_km/1.852:.0f} nm assured "
                f"AIS envelope ({coverage.source}); absence of AIS is evidential")
    elif inside is False:
        note = (f"slick lies outside the {coverage.radius_km/1.852:.0f} nm assured "
                f"AIS envelope; absence of AIS is not evidence of a dark vessel")
    else:
        note = ("AIS coverage at this position could not be established "
                f"({coverage.source}); absence of AIS is not evidence of a dark vessel")

    suspects = [s for s in suspects if s.score >= MIN_PROB]
    for s in suspects:
        s.score = float(s.score * oil_probability)
    suspects.sort(key=lambda s: s.score, reverse=True)

    lon, lat = frame.lonlat_of_km(cx, cy)
    return Attribution(region_index=region.index,
                       oil_probability=float(oil_probability),
                       area_km2=float(region.area_km2),
                       centroid_lonlat=(float(lon), float(lat)),
                       drift_backend=backcast.backend,
                       suspects=suspects,
                       coverage_known=bool(coverage.known),
                       coverage_note=note,
                       best_hour=suspects[0].release_hours_before if suspects else None,
                       backcast=backcast)
