import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import tifffile

BLOCK_TARGET_ROWS = 2048
VALID_FRACTION = 0.9


@dataclass
class RealScene:
    sigma0: np.ndarray
    valid: np.ndarray
    lon: np.ndarray
    lat: np.ndarray
    acquired: datetime
    polarisation: str
    pixel_spacing_m: float
    multilook: int
    enl: float
    source: Path
    denoised: bool
    offset_rc: tuple = (0, 0)
    notes: list = field(default_factory=list)

    @property
    def shape(self):
        return self.sigma0.shape

    def bounds(self):
        return (float(np.nanmin(self.lon)), float(np.nanmin(self.lat)),
                float(np.nanmax(self.lon)), float(np.nanmax(self.lat)))

    def rowcol_of(self, lon, lat):
        d = (self.lon - lon) ** 2 + (self.lat - lat) ** 2
        idx = int(np.nanargmin(d))
        return np.unravel_index(idx, self.lon.shape)


def _strip(tag):
    return tag.split("}")[-1]


def _first(root, name):
    for el in root.iter():
        if _strip(el.tag) == name:
            return el
    return None


def _text(root, name, default=None):
    el = _first(root, name)
    return el.text.strip() if el is not None and el.text else default


def _scoped(root, container, name, default=None):
    holder = _first(root, container)
    if holder is None:
        return default
    return _text(holder, name, default)


def _floats(el, name):
    child = None
    for c in el:
        if _strip(c.tag) == name:
            child = c
            break
    if child is None or not child.text:
        return np.zeros(0)
    return np.fromstring(child.text.strip(), sep=" ")


def _measurement(safe: Path, pol: str):
    hits = sorted((safe / "measurement").glob(f"*-{pol.lower()}-*.tif*"))
    if not hits:
        hits = sorted((safe / "measurement").glob("*.tif*"))
    if not hits:
        raise FileNotFoundError(f"no measurement raster in {safe/'measurement'}")
    return hits[0]


def _companion(safe: Path, measurement: Path, subdir=None, prefix=""):
    base = safe / "annotation"
    if subdir:
        base = base / subdir
    if not base.exists():
        return None
    stem = measurement.stem
    hits = sorted(c for c in base.glob("*.xml") if c.name.startswith(prefix))
    for cand in hits:
        if stem in cand.stem:
            return cand
    return hits[0] if hits else None


def _vector_grid(root, list_name, item_name, value_name):
    lines, pixels, values = [], [], []
    container = _first(root, list_name)
    if container is None:
        return None
    for item in container:
        if _strip(item.tag) != item_name:
            continue
        line = _text(item, "line")
        if line is None:
            continue
        px = _floats(item, "pixel")
        val = _floats(item, value_name)
        if px.size == 0 or val.size != px.size:
            continue
        lines.append(float(line))
        pixels.append(px)
        values.append(val)
    if not lines:
        return None
    return np.array(lines), pixels, values


def _interp_lut(grid, rows, cols):
    lines, pixels, values = grid
    order = np.argsort(lines)
    lines = lines[order]
    pixels = [pixels[i] for i in order]
    values = [values[i] for i in order]

    per_line = np.empty((len(lines), cols.size), dtype=np.float32)
    for i, (px, val) in enumerate(zip(pixels, values)):
        per_line[i] = np.interp(cols, px, val).astype(np.float32)

    out = np.empty((rows.size, cols.size), dtype=np.float32)
    for j in range(cols.size):
        out[:, j] = np.interp(rows, lines, per_line[:, j]).astype(np.float32)
    return out


def _geolocation(root):
    lines, pix, lats, lons = [], [], [], []
    container = _first(root, "geolocationGridPointList")
    if container is None:
        return None
    for pt in container:
        if _strip(pt.tag) != "geolocationGridPoint":
            continue
        try:
            lines.append(float(_text(pt, "line")))
            pix.append(float(_text(pt, "pixel")))
            lats.append(float(_text(pt, "latitude")))
            lons.append(float(_text(pt, "longitude")))
        except (TypeError, ValueError):
            continue
    if len(lines) < 6:
        return None
    return (np.array(lines), np.array(pix), np.array(lons), np.array(lats))


def _fit_bivariate(line, pixel, value, degree=2):
    terms = [(i, j) for i in range(degree + 1) for j in range(degree + 1 - i)]
    scale = (float(np.ptp(line)) or 1.0, float(np.ptp(pixel)) or 1.0)
    origin = (float(line.min()), float(pixel.min()))
    ln = (line - origin[0]) / scale[0]
    px = (pixel - origin[1]) / scale[1]
    A = np.column_stack([(ln ** i) * (px ** j) for i, j in terms])
    coef, *_ = np.linalg.lstsq(A, value, rcond=None)
    return (coef, origin, scale), terms


def _eval_bivariate(model, terms, line, pixel):
    coef, origin, scale = model
    ln = (np.asarray(line, dtype=np.float64) - origin[0]) / scale[0]
    px = (np.asarray(pixel, dtype=np.float64) - origin[1]) / scale[1]
    out = np.zeros(np.broadcast(ln, px).shape, dtype=np.float64)
    for c, (i, j) in zip(coef, terms):
        out = out + c * (ln ** i) * (px ** j)
    return out


def _block_mean(arr, k):
    h = (arr.shape[0] // k) * k
    w = (arr.shape[1] // k) * k
    view = arr[:h, :w].reshape(h // k, k, w // k, k)
    return view.mean(axis=(1, 3))


def estimate_enl(sigma0, window=None, bins=60):
    h, w = sigma0.shape
    if window is None:
        window = int(max(8, min(32, h // 8, w // 8)))
    if h <= window or w <= window:
        return float("nan")
    step = max(2, window // 2)
    vals = []
    for r in range(0, h - window, step):
        for c in range(0, w - window, step):
            patch = sigma0[r:r + window, c:c + window]
            patch = patch[np.isfinite(patch) & (patch > 0)]
            if patch.size < window * window * 0.6:
                continue
            m, v = patch.mean(), patch.var()
            if v <= 0:
                continue
            vals.append(m * m / v)
    if len(vals) < 8:
        return float("nan")
    vals = np.array(vals)
    vals = vals[vals < np.percentile(vals, 99)]
    if vals.size < 8:
        return float("nan")
    logv = np.log(vals)
    hist, edges = np.histogram(logv, bins=min(bins, max(8, vals.size // 4)))
    k = int(np.argmax(hist))
    return float(np.exp(0.5 * (edges[k] + edges[k + 1])))


def read_grd(safe_path, polarisation="vv", multilook=15, aoi=None,
             denoise=True, max_pixels=None):
    safe = Path(safe_path)
    if (safe / "manifest.safe").exists() is False and safe.suffix.lower() != ".safe":
        raise ValueError(f"{safe} is not a Sentinel-1 .SAFE product")

    measurement = _measurement(safe, polarisation)
    ann_path = _companion(safe, measurement)
    if ann_path is None:
        raise FileNotFoundError("no product annotation XML found")
    ann = ET.parse(ann_path).getroot()

    pol = (_scoped(ann, "adsHeader", "polarisation")
           or _text(ann, "polarisation") or polarisation).upper()
    n_lines = int(float(_scoped(ann, "imageInformation", "numberOfLines") or 0))
    n_samples = int(float(_scoped(ann, "imageInformation", "numberOfSamples") or 0))
    spacing = float(_scoped(ann, "imageInformation", "rangePixelSpacing") or 0.0)
    if spacing <= 0:
        spacing = float(_text(ann, "rangePixelSpacing") or 10.0)
        notes_spacing = "rangePixelSpacing read outside imageInformation"
    else:
        notes_spacing = None
    stamp = _scoped(ann, "imageInformation", "productFirstLineUtcTime")
    if stamp:
        acquired = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        if acquired.tzinfo is None:
            acquired = acquired.replace(tzinfo=timezone.utc)
    else:
        m = re.search(r"(\d{8}T\d{6})", safe.name)
        acquired = (datetime.strptime(m.group(1), "%Y%m%dT%H%M%S")
                    .replace(tzinfo=timezone.utc) if m else datetime.now(timezone.utc))

    notes = []
    if notes_spacing:
        notes.append(notes_spacing)
    with tifffile.TiffFile(str(measurement)) as tif:
        page = tif.pages[0]
        full_h, full_w = int(page.shape[0]), int(page.shape[1])
        try:
            dn_full = tifffile.memmap(str(measurement), mode="r")
            notes.append("measurement raster memory-mapped")
        except Exception:
            dn_full = page.asarray()
            notes.append("measurement raster read into memory")

    if n_lines == 0 or n_samples == 0:
        n_lines, n_samples = full_h, full_w

    r0, r1, c0, c1 = 0, full_h, 0, full_w
    if aoi is not None:
        geo = _geolocation(ann)
        if geo is None:
            raise ValueError("cannot crop to an AOI without a geolocation grid")
        r0, r1, c0, c1 = _aoi_window(geo, aoi, full_h, full_w, multilook)
        notes.append(f"cropped to AOI rows {r0}:{r1} cols {c0}:{c1}")

    cols = np.arange(c0, c1, dtype=np.float64)

    cal_path = _companion(safe, measurement, "calibration", "calibration-")
    if cal_path is None:
        raise FileNotFoundError("no calibration annotation found")
    cal_grid = _vector_grid(ET.parse(cal_path).getroot(), "calibrationVectorList",
                            "calibrationVector", "sigmaNought")
    if cal_grid is None:
        raise ValueError("calibration vector list is empty or malformed")

    noise_grid = None
    if denoise:
        noise_path = _companion(safe, measurement, "calibration", "noise-")
        if noise_path is not None and noise_path.name.startswith("noise-"):
            noise_grid = _vector_grid(ET.parse(noise_path).getroot(),
                                      "noiseRangeVectorList", "noiseRangeVector",
                                      "noiseRangeLut")
    denoised = noise_grid is not None
    notes.append("thermal noise LUT subtracted" if denoised
                 else "no thermal noise LUT applied")

    step = max(multilook, (multilook * max(1, BLOCK_TARGET_ROWS // multilook)))
    blocks, valid_blocks = [], []
    for start in range(r0, r1, step):
        stop = min(start + step, r1)
        if multilook > 1:
            stop = start + ((stop - start) // multilook) * multilook
            if stop <= start:
                continue
        rows = np.arange(start, stop, dtype=np.float64)
        raw = np.asarray(dn_full[start:stop, c0:c1])
        valid = raw > 0
        block = raw.astype(np.float32) ** 2
        del raw
        if noise_grid is not None:
            block -= _interp_lut(noise_grid, rows, cols)
            np.clip(block, 0.0, None, out=block)
        block /= np.maximum(_interp_lut(cal_grid, rows, cols) ** 2,
                            np.float32(1e-12))
        block[~valid] = np.nan
        blocks.append(_block_mean(block, multilook) if multilook > 1 else block)
        valid_blocks.append(_block_mean(valid.astype(np.float32), multilook)
                            if multilook > 1 else valid.astype(np.float32))
        del block, valid
    if not blocks:
        raise ValueError("window resolved to fewer rows than one multilook block")
    sigma0 = np.vstack(blocks).astype(np.float32)
    valid = np.vstack(valid_blocks) >= VALID_FRACTION
    del blocks, valid_blocks
    invalid = int((~valid).sum())
    if invalid:
        notes.append(f"{invalid} of {valid.size} cells are no-data "
                     f"({100.0*invalid/valid.size:.1f}%, GRD border or fill)")
    notes.append(f"streamed in {step}-row blocks")
    if multilook > 1:
        notes.append(f"multilooked {multilook}x{multilook} "
                     f"-> {spacing*multilook:.0f} m pixels")

    enl = estimate_enl(np.where(valid, sigma0, np.nan))
    notes.append(f"estimated ENL {enl:.1f}" if np.isfinite(enl)
                 else "ENL could not be estimated")

    geo = _geolocation(ann)
    if geo is None:
        raise ValueError("no geolocation grid in annotation")
    gl, gp, glon, glat = geo
    lon_c, terms = _fit_bivariate(gl, gp, glon)
    lat_c, _ = _fit_bivariate(gl, gp, glat)
    mh, mw = sigma0.shape
    rr = (r0 + (np.arange(mh) + 0.5) * multilook)[:, None]
    cc = (c0 + (np.arange(mw) + 0.5) * multilook)[None, :]
    lon = _eval_bivariate(lon_c, terms, rr, cc)
    lat = _eval_bivariate(lat_c, terms, rr, cc)

    return RealScene(sigma0=sigma0.astype(np.float64), valid=valid, lon=lon, lat=lat,
                     acquired=acquired, polarisation=pol,
                     pixel_spacing_m=spacing * multilook, multilook=multilook,
                     enl=enl, source=safe, denoised=denoised,
                     offset_rc=(r0, c0), notes=notes)


def _aoi_window(geo, aoi, full_h, full_w, multilook, pad=64):
    gl, gp, glon, glat = geo
    lon_min, lat_min, lon_max, lat_max = aoi
    line_c, terms = _fit_bivariate(glon, glat, gl)
    pix_c, _ = _fit_bivariate(glon, glat, gp)
    corners_lon = np.array([lon_min, lon_min, lon_max, lon_max])
    corners_lat = np.array([lat_min, lat_max, lat_min, lat_max])
    lines = _eval_bivariate(line_c, terms, corners_lon, corners_lat)
    pixels = _eval_bivariate(pix_c, terms, corners_lon, corners_lat)
    r0 = int(max(0, np.floor(lines.min()) - pad))
    r1 = int(min(full_h, np.ceil(lines.max()) + pad))
    c0 = int(max(0, np.floor(pixels.min()) - pad))
    c1 = int(min(full_w, np.ceil(pixels.max()) + pad))
    if r1 - r0 < multilook * 8 or c1 - c0 < multilook * 8:
        raise ValueError("AOI resolves to too small a window; check lon/lat order")
    r1 = r0 + ((r1 - r0) // multilook) * multilook
    c1 = c0 + ((c1 - c0) // multilook) * multilook
    return r0, r1, c0, c1
