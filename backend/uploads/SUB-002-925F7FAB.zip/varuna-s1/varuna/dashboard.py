import shutil

from varuna.config import ATTRIB_RADIUS_KM, WIND_MAX, WIND_MIN
from varuna.geo import fmt
from varuna.patch_metrics import NAMES

W = min(shutil.get_terminal_size((100, 30)).columns, 100)


def _rule(ch="-"):
    return ch * W


def _head(text):
    body = f" {text} "
    pad = max(W - len(body) - 4, 0)
    return f"== {body}{'=' * pad}"


def _bar(value, width=22):
    filled = int(round(max(0.0, min(1.0, value)) * width))
    return "#" * filled + "." * (width - filled)


def render(result, show_metrics=True):
    sc = result.scene
    out = []
    out.append(_rule("="))
    out.append("VARUNA  |  SAR oil-spill source attribution  |  SIH 2026 PS 26143")
    out.append(_rule("="))
    out.append(f"Product      : {result.product.path.name}")
    out.append(f"Acquired     : {sc.acquired.isoformat()}  ({sc.polarisation}, "
               f"{sc.pixel_spacing_m:.0f} m)")
    out.append(f"Preprocessing: {sc.backend}   land mask: {sc.land_mask_source}")
    env = result.environment
    gate = ("within" if env.wind_in_window else "OUTSIDE") \
        if env.wind_in_window is not None else "unknown"
    out.append(f"Environment  : {env.describe()}")
    out.append(f"Wind gate    : {gate} the {WIND_MIN:.0f}-{WIND_MAX:.0f} m/s "
               f"detection window")
    out.append("")

    out.append(_head("PIPELINE"))
    for s in result.stages:
        out.append(f"  . {s}")
    out.append("")

    out.append(_head("BRANCH A  dark spots -> patch metrics -> classifier"))
    if not len(result.regions):
        out.append("  no dark regions passed the contrast gate")
    else:
        if show_metrics:
            out.append("  " + f"{'#':>2}  {'area km2':>9}  " +
                       "  ".join(f"{n[:9]:>9}" for n in NAMES[:-1]) + "   p(oil)")
        for r, f, p in zip(result.regions, result.features, result.oil_probability):
            row = (f"  {r.index:>2}  {r.area_km2:9.1f}  " +
                   "  ".join(f"{v:9.3f}" for v in f[:-1]) +
                   f"   {p:5.3f} {_bar(p, 12)}")
            out.append(row)
    out.append("")

    out.append(_head("BRANCH B  CFAR vessel detection"))
    out.append(f"  {len(result.detections)} radar targets   "
               f"{len(result.correlated)} AIS-correlated   "
               f"{len(result.dark)} without AIS correlation")
    out.append(f"  AIS tracks in window: {len(result.tracks)}   "
               f"coverage: {result.coverage.source}")
    for i, rec in enumerate(result.dark[:8]):
        d = rec["detection"]
        lon, lat = rec["lon"], rec["lat"]
        out.append(f"    D{i+1}  {fmt(lon, lat)}  radar extent {d.length_m:>4.0f} m  "
                   f"SNR {d.snr_db:5.1f} dB")
    out.append("")

    out.append(_head("SUSPECT RANKING"))
    if not result.attributions:
        out.append("  no region exceeded the oil-probability threshold; nothing to attribute")
    for a in result.attributions:
        out.append(_rule())
        lon, lat = a.centroid_lonlat
        out.append(f"  SLICK {a.region_index}   {fmt(lon, lat)}   "
                   f"{a.area_km2:.1f} km2   p(oil)={a.oil_probability:.3f}")
        out.append(f"  drift engine: {a.drift_backend}   "
                   f"association radius: {ATTRIB_RADIUS_KM:.0f} km")
        out.append(f"  AIS coverage: {a.coverage_note}")
        if not a.suspects:
            out.append("    no vessel is consistent with the back-cast release window")
            continue
        for i, s in enumerate(a.suspects):
            tag = "AIS" if s.kind == "ais" else "DARK"
            ident = f"MMSI {s.mmsi}" if s.mmsi else "no identity"
            out.append("")
            out.append(f"    #{i+1}  [{tag}] {s.label}   {ident}")
            out.append(f"        {s.ship_type}, flag {s.flag}   "
                       f"score {s.score:.3f}  {_bar(s.score)}")
            out.append(f"        release estimated {s.release_hours_before:.1f} h "
                       f"before acquisition")
            for e in s.evidence:
                out.append(f"        - {e}")
        out.append("")
        out.append("    OUTPUT: probable cause to intercept and sample. Bunker "
                   "fingerprinting of the")
        out.append("            ranked vessel against the slick remains the "
                   "evidentiary step.")
    out.append(_rule("="))
    return "\n".join(out)


def print_result(result, show_metrics=True):
    print(render(result, show_metrics))


def launch_dashboard(results=None, port=8501, host="127.0.0.1", open_browser=False):
    from varuna import api, pipeline
    from varuna.config import ARTIFACTS

    if results is not None:
        payload = results.to_dict() if hasattr(results, "to_dict") else results
        ARTIFACTS.mkdir(parents=True, exist_ok=True)
        import json
        (ARTIFACTS / "demo_run.json").write_text(json.dumps(payload, indent=2))

    app = api.create_app()
    if open_browser:
        import threading
        import webbrowser
        threading.Timer(1.0, lambda: webbrowser.open(f"http://{host}:{port}")).start()

    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="warning")
