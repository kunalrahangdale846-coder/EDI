import json
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import tifffile


@dataclass
class Product:
    path: Path
    polarisation: str
    acquired: datetime
    pixel_spacing_m: float
    dn: np.ndarray
    calibration_constant: float
    synthetic: bool = False
    truth: dict = field(default_factory=dict)
    wind_speed: float | None = None
    wind_dir_deg: float | None = None
    labels: np.ndarray | None = None


def _text(root, tag, default=None):
    for el in root.iter():
        if el.tag.split("}")[-1] == tag and el.text:
            return el.text.strip()
    return default


def _find_measurement(safe: Path, polarisation="vv"):
    hits = sorted((safe / "measurement").glob(f"*-{polarisation}-*.tif*"))
    if not hits:
        hits = sorted((safe / "measurement").glob("*.tif*"))
    if not hits:
        raise FileNotFoundError(f"no measurement raster under {safe/'measurement'}")
    return hits[0]


def _find_annotation(safe: Path, measurement: Path):
    stem = measurement.stem
    cand = safe / "annotation" / f"{stem}.xml"
    if cand.exists():
        return cand
    hits = sorted((safe / "annotation").glob("*.xml"))
    return hits[0] if hits else None


def read(safe_path) -> Product:
    safe = Path(safe_path)
    if not safe.exists():
        raise FileNotFoundError(safe)
    if safe.suffix.lower() != ".safe" and not (safe / "manifest.safe").exists():
        raise ValueError(f"{safe} does not look like a Sentinel-1 .SAFE product")

    measurement = _find_measurement(safe)
    dn = tifffile.imread(str(measurement)).astype(np.float64)

    ann = _find_annotation(safe, measurement)
    pol, acquired, spacing = "VV", None, 10.0
    if ann is not None:
        root = ET.parse(ann).getroot()
        pol = (_text(root, "polarisation") or "VV").upper()
        stamp = _text(root, "productFirstLineUtcTime")
        if stamp:
            txt = stamp.replace("Z", "+00:00")
            acquired = datetime.fromisoformat(txt)
            if acquired.tzinfo is None:
                acquired = acquired.replace(tzinfo=timezone.utc)
        spacing = float(_text(root, "rangePixelSpacing") or spacing)
    if acquired is None:
        m = re.search(r"(\d{8}T\d{6})", safe.name)
        acquired = (datetime.strptime(m.group(1), "%Y%m%dT%H%M%S").replace(tzinfo=timezone.utc)
                    if m else datetime.now(timezone.utc))

    cal = 1.0
    cal_xml = safe / "annotation" / "calibration"
    if cal_xml.exists():
        files = sorted(cal_xml.glob("calibration-*.xml"))
        if files:
            root = ET.parse(files[0]).getroot()
            values = _text(root, "sigmaNought")
            if values:
                cal = float(values.split()[0])

    sidecar = safe / "varuna_truth.json"
    truth = json.loads(sidecar.read_text()) if sidecar.exists() else {}
    label_path = safe / "varuna_labels.npy"
    labels = np.load(label_path) if label_path.exists() else None

    return Product(path=safe, polarisation=pol, acquired=acquired,
                   pixel_spacing_m=spacing, dn=dn, calibration_constant=cal,
                   synthetic=bool(truth), truth=truth,
                   wind_speed=truth.get("wind_speed"),
                   wind_dir_deg=truth.get("wind_dir_deg"), labels=labels)


def write_synthetic(safe_path, dn, acquired, wind_speed, wind_dir_deg,
                    pixel_spacing_m, truth):
    safe = Path(safe_path)
    (safe / "measurement").mkdir(parents=True, exist_ok=True)
    (safe / "annotation" / "calibration").mkdir(parents=True, exist_ok=True)

    stamp = acquired.strftime("%Y%m%dT%H%M%S")
    base = f"s1a-iw-grd-vv-{stamp}-{stamp}-000001-000001-001"
    tifffile.imwrite(str(safe / "measurement" / f"{base}.tiff"),
                     dn.astype(np.uint16))

    ann = f"""<?xml version="1.0" encoding="UTF-8"?>
<product>
  <adsHeader>
    <missionId>S1A</missionId>
    <productType>GRD</productType>
    <polarisation>VV</polarisation>
    <mode>IW</mode>
    <startTime>{acquired.isoformat()}</startTime>
  </adsHeader>
  <imageAnnotation>
    <imageInformation>
      <productFirstLineUtcTime>{acquired.isoformat()}</productFirstLineUtcTime>
      <rangePixelSpacing>{pixel_spacing_m}</rangePixelSpacing>
      <azimuthPixelSpacing>{pixel_spacing_m}</azimuthPixelSpacing>
      <numberOfSamples>{dn.shape[1]}</numberOfSamples>
      <numberOfLines>{dn.shape[0]}</numberOfLines>
    </imageInformation>
  </imageAnnotation>
</product>
"""
    (safe / "annotation" / f"{base}.xml").write_text(ann)

    cal = f"""<?xml version="1.0" encoding="UTF-8"?>
<calibration>
  <calibrationVectorList count="1">
    <calibrationVector>
      <sigmaNought count="1">{truth.get('calibration_constant', 1.0)}</sigmaNought>
    </calibrationVector>
  </calibrationVectorList>
</calibration>
"""
    (safe / "annotation" / "calibration" / f"calibration-{base}.xml").write_text(cal)

    manifest = f"""<?xml version="1.0" encoding="UTF-8"?>
<xfdu:XFDU xmlns:xfdu="urn:ccsds:schema:xfdu:1">
  <informationPackageMap>
    <contentUnit textInfo="Sentinel-1 IW Level-1 GRD Product" unitType="SAFE Archive Information Package"/>
  </informationPackageMap>
  <metadataSection>
    <metadataObject ID="acquisitionPeriod">
      <startTime>{acquired.isoformat()}</startTime>
    </metadataObject>
  </metadataSection>
</xfdu:XFDU>
"""
    (safe / "manifest.safe").write_text(manifest)

    payload = dict(truth)
    payload.update({"wind_speed": wind_speed, "wind_dir_deg": wind_dir_deg,
                    "generated_by": "varuna.simulate", "note": "synthetic product, not ESA data"})
    (safe / "varuna_truth.json").write_text(json.dumps(payload, indent=2))
    return safe
