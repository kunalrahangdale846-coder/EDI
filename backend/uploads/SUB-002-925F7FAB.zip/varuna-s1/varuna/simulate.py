from datetime import datetime, timedelta, timezone

import numpy as np
from scipy import ndimage

from varuna.config import (DIFFUSIVITY, DRIFT_MAX_H, DRIFT_MIN_H, GRID, LOOKS,
                           PIXEL_M, SCENE_KM, WIND_DRIFT_FACTOR)
from varuna.safe_reader import write_synthetic

CAL_CONSTANT = 2000.0
KN_TO_MS = 0.514444

SHIP_TYPES = ["Crude Oil Tanker", "Product Tanker", "Bulk Carrier",
              "Container Ship", "Chemical Tanker", "General Cargo"]
FLAGS = ["PAN", "LBR", "MLT", "IND", "SGP", "MHL", "CYP"]


def _speckle(rng, shape, looks=LOOKS):
    return rng.gamma(shape=looks, scale=1.0 / looks, size=shape)


def _wind_field(rng, wind_speed):
    coarse = rng.normal(0.0, 1.0, size=(8, 8))
    coarse = ndimage.zoom(coarse, GRID / 8.0, order=3)[:GRID, :GRID]
    coarse = ndimage.gaussian_filter(coarse, 12)
    coarse /= max(np.abs(coarse).max(), 1e-9)
    return wind_speed * (1.0 + 0.10 * coarse)


def _ocean_sigma0(wind_map):
    return 0.020 * np.power(np.clip(wind_map, 0.5, None) / 7.0, 1.6)


def _paint_land(rng, sigma0):
    corner = rng.integers(0, 4)
    yy, xx = np.mgrid[0:GRID, 0:GRID]
    frac = rng.uniform(0.14, 0.24)
    edge = GRID * frac
    wobble = ndimage.gaussian_filter(rng.normal(0, 1, GRID), 22)
    wobble = edge * 0.45 * wobble / max(np.abs(wobble).max(), 1e-9)
    if corner == 0:
        land = xx < (edge + wobble[yy])
    elif corner == 1:
        land = xx > (GRID - edge - wobble[yy])
    elif corner == 2:
        land = yy < (edge + wobble[xx])
    else:
        land = yy > (GRID - edge - wobble[xx])
    texture = ndimage.gaussian_filter(rng.lognormal(0, 0.8, (GRID, GRID)), 2)
    sigma0 = np.where(land, 0.16 * texture / max(texture.mean(), 1e-9), sigma0)
    return sigma0, land


def _vessel_state(rng):
    speed = rng.uniform(7.0, 16.0) * KN_TO_MS
    course = rng.uniform(0.0, 360.0)
    x = rng.uniform(0.06, 0.94) * SCENE_KM
    y = rng.uniform(0.06, 0.94) * SCENE_KM
    return dict(x_km=x, y_km=y, speed_ms=speed, course_deg=course,
                length_m=float(rng.uniform(90, 330)),
                ship_type=str(rng.choice(SHIP_TYPES)),
                flag=str(rng.choice(FLAGS)),
                mmsi=int(rng.integers(200000000, 799999999)),
                broadcasting=bool(rng.random() > 0.28))


def _position_at(v, dt_h):
    rad = np.deg2rad(v["course_deg"])
    dx = np.sin(rad) * v["speed_ms"] * dt_h * 3600.0 / 1000.0
    dy = np.cos(rad) * v["speed_ms"] * dt_h * 3600.0 / 1000.0
    return v["x_km"] + dx, v["y_km"] + dy


def _drift_forward(rng, x, y, ages_h, u_km_h, v_km_h, steps_per_h=4):
    x = np.array(x, dtype=float)
    y = np.array(y, dtype=float)
    ages = np.asarray(ages_h, dtype=float)
    total = float(ages.max())
    steps = max(int(total * steps_per_h), 1)
    dt = total / steps
    sigma = np.sqrt(2.0 * DIFFUSIVITY * dt * 3600.0) / 1000.0
    elapsed = 0.0
    for _ in range(steps):
        live = ages > elapsed
        if not live.any():
            break
        x[live] += u_km_h * dt + rng.normal(0, sigma, int(live.sum()))
        y[live] += v_km_h * dt + rng.normal(0, sigma, int(live.sum()))
        elapsed += dt
    return x, y


def _render_slick(sigma0, mask, damping, softness, rng):
    soft = ndimage.gaussian_filter(mask.astype(float), softness)
    soft /= max(soft.max(), 1e-9)
    soft = np.clip(soft, 0.0, 1.0)
    noise = 1.0 + 0.06 * ndimage.gaussian_filter(rng.normal(0, 1, sigma0.shape), 4)
    factor = 1.0 - (1.0 - damping) * soft * noise
    return sigma0 * np.clip(factor, 0.05, 1.0)


def _lookalike_mask(rng, kind):
    yy, xx = np.mgrid[0:GRID, 0:GRID]
    cx = rng.uniform(0.18, 0.82) * GRID
    cy = rng.uniform(0.18, 0.82) * GRID
    ang = rng.uniform(0, np.pi)
    rx = (xx - cx) * np.cos(ang) + (yy - cy) * np.sin(ang)
    ry = -(xx - cx) * np.sin(ang) + (yy - cy) * np.cos(ang)
    if kind == "low_wind":
        a = rng.uniform(24, 52)
        b = a / rng.uniform(1.0, 4.5)
        warp = ndimage.gaussian_filter(rng.normal(0, 1, (GRID, GRID)), 14)
        warp /= max(np.abs(warp).max(), 1e-9)
        return ((rx / a) ** 2 + (ry / b) ** 2) ** 0.5 + 0.45 * warp < 1.0
    a = rng.uniform(30, 62)
    b = a / rng.uniform(2.0, 6.0)
    base = (rx / a) ** 2 + (ry / b) ** 2 < 1.0
    fray = ndimage.gaussian_filter(rng.normal(0, 1, (GRID, GRID)), 3.0)
    fray /= max(np.abs(fray).max(), 1e-9)
    return base & (fray > -0.22)


def _age_slick(rng, mask):
    frag = ndimage.gaussian_filter(rng.normal(0, 1, mask.shape), 4.0)
    frag /= max(np.abs(frag).max(), 1e-9)
    aged = mask & (frag > -0.10)
    aged = ndimage.binary_opening(aged, np.ones((3, 3)))
    return aged if aged.sum() > 0.35 * mask.sum() else mask


def build_scene(seed, acquired=None, wind_speed=None, force_land=None):
    rng = np.random.default_rng(seed)
    acquired = acquired or datetime(2026, 3, 14, 5, 42, 11, tzinfo=timezone.utc)
    wind_speed = wind_speed if wind_speed is not None else float(rng.uniform(3.5, 9.5))
    wind_dir = float(rng.uniform(0, 360))

    wind_map = _wind_field(rng, wind_speed)
    sigma0 = _ocean_sigma0(wind_map)

    has_land = rng.random() < 0.5 if force_land is None else force_land
    land = np.zeros((GRID, GRID), dtype=bool)
    if has_land:
        sigma0, land = _paint_land(rng, sigma0)

    wind_rad = np.deg2rad(wind_dir)
    wu = np.sin(wind_rad) * wind_speed
    wv = np.cos(wind_rad) * wind_speed
    cur_dir = np.deg2rad(rng.uniform(0, 360))
    cur_speed = rng.uniform(0.10, 0.45)
    cu = np.sin(cur_dir) * cur_speed
    cv = np.cos(cur_dir) * cur_speed
    u_km_h = (cu + WIND_DRIFT_FACTOR * wu) * 3.6
    v_km_h = (cv + WIND_DRIFT_FACTOR * wv) * 3.6

    n_vessels = int(rng.integers(9, 18))
    vessels = []
    for _ in range(n_vessels):
        v = _vessel_state(rng)
        if land[int(np.clip(v["y_km"] * 1000 / PIXEL_M, 0, GRID - 1)),
                int(np.clip(v["x_km"] * 1000 / PIXEL_M, 0, GRID - 1))]:
            continue
        vessels.append(v)
    for i, v in enumerate(vessels):
        v["id"] = i
        v["name"] = f"MV VARUNA-{i:02d}"

    n_spills = int(rng.integers(1, 3))
    labels = np.zeros((GRID, GRID), dtype=np.int8)
    slicks = []
    for sid in range(n_spills):
        v = _vessel_state(rng)
        v["speed_ms"] = float(rng.uniform(4.0, 11.0)) * KN_TO_MS
        v["id"] = len(vessels)
        v["name"] = f"MV VARUNA-{v['id']:02d}"
        v["row"] = None
        v["col"] = None
        speed_kmh = v["speed_ms"] * 3.6

        age_h = float(DRIFT_MIN_H + (DRIFT_MAX_H - DRIFT_MIN_H) * rng.random() ** 2)
        rx = float(rng.uniform(0.22, 0.78) * SCENE_KM)
        ry = float(rng.uniform(0.22, 0.78) * SCENE_KM)
        rad = np.deg2rad(v["course_deg"])
        v["x_km"] = rx + np.sin(rad) * speed_kmh * age_h
        v["y_km"] = ry + np.cos(rad) * speed_kmh * age_h
        margin = 0.03 * SCENE_KM
        in_scene = bool(margin < v["x_km"] < SCENE_KM - margin
                        and margin < v["y_km"] < SCENE_KM - margin)
        vessels.append(v)

        release_h = float(min(2.0, 14.0 / max(speed_kmh, 1e-6), age_h * 0.6))
        ex = rx + np.sin(rad) * speed_kmh * release_h
        ey = ry + np.cos(rad) * speed_kmh * release_h
        n_par = 1600
        t = rng.random(n_par)
        px = rx + (ex - rx) * t
        py = ry + (ey - ry) * t
        ages = age_h - release_h * t
        fx, fy = _drift_forward(rng, px, py, ages, u_km_h, v_km_h)
        inside = float(((fx > 0) & (fx < SCENE_KM) & (fy > 0) & (fy < SCENE_KM)).mean())
        if inside < 0.75:
            continue
        col = np.clip(fx * 1000.0 / PIXEL_M, 0, GRID - 1).astype(int)
        row = np.clip(fy * 1000.0 / PIXEL_M, 0, GRID - 1).astype(int)
        dens = np.zeros((GRID, GRID))
        np.add.at(dens, (row, col), 1.0)
        dens = ndimage.gaussian_filter(dens, 2.2)
        if dens.max() <= 0:
            continue
        mask = dens > 0.18 * dens.max()
        mask = ndimage.binary_closing(mask, np.ones((5, 5)))
        mask = ndimage.binary_fill_holes(mask) & ~land
        aged = bool(rng.random() < 0.35)
        if aged:
            mask = _age_slick(rng, mask)
        if mask.sum() < 60:
            continue
        damping = float(rng.uniform(0.16, 0.50))
        softness = float(rng.uniform(2.4, 4.6) if aged else rng.uniform(1.3, 3.4))
        sigma0 = _render_slick(sigma0, mask, damping, softness, rng)
        labels[mask] = 1
        r, c = ndimage.center_of_mass(mask)
        slicks.append(dict(id=sid, kind="oil", source_vessel=v["id"],
                           source_mmsi=v["mmsi"], broadcasting=v["broadcasting"],
                           source_in_scene=in_scene, aged=aged,
                           softness=softness,
                           release_x_km=rx, release_y_km=ry,
                           release_age_h=age_h, damping=damping,
                           centroid_row=float(r), centroid_col=float(c),
                           area_km2=float(mask.sum()) * (PIXEL_M / 1000.0) ** 2))

    n_fakes = int(rng.integers(1, 4))
    for fid in range(n_fakes):
        kind = "low_wind" if rng.random() < 0.5 else "biogenic"
        mask = _lookalike_mask(rng, kind) & ~land
        if mask.sum() < 150:
            continue
        damping = float(rng.uniform(0.22, 0.58))
        sigma0 = _render_slick(sigma0, mask, damping, rng.uniform(1.6, 4.2), rng)
        labels[mask & (labels == 0)] = 2
        r, c = ndimage.center_of_mass(mask)
        slicks.append(dict(id=1000 + fid, kind=kind, source_vessel=None,
                           source_mmsi=None, broadcasting=None,
                           release_x_km=None, release_y_km=None,
                           release_age_h=None, damping=damping,
                           centroid_row=float(r), centroid_col=float(c),
                           area_km2=float(mask.sum()) * (PIXEL_M / 1000.0) ** 2))

    for v in vessels:
        if not (0 <= v["x_km"] <= SCENE_KM and 0 <= v["y_km"] <= SCENE_KM):
            v["row"] = None
            v["col"] = None
            continue
        col = int(np.clip(v["x_km"] * 1000.0 / PIXEL_M, 2, GRID - 3))
        row = int(np.clip(v["y_km"] * 1000.0 / PIXEL_M, 2, GRID - 3))
        if land[row, col]:
            v["row"] = None
            v["col"] = None
            continue
        npx = max(1, int(round(v["length_m"] / PIXEL_M)))
        rad = np.deg2rad(v["course_deg"])
        for s in range(-npx, npx + 1):
            rr = int(np.clip(row + s * np.cos(rad) * 0.5, 0, GRID - 1))
            cc = int(np.clip(col + s * np.sin(rad) * 0.5, 0, GRID - 1))
            sigma0[rr, cc] = max(sigma0[rr, cc], float(rng.uniform(3.0, 40.0)))
        v["row"] = row
        v["col"] = col

    observed = sigma0 * _speckle(rng, sigma0.shape)
    dn = np.clip(CAL_CONSTANT * np.sqrt(np.clip(observed, 0.0, None)), 0, 65535)

    truth = dict(seed=int(seed), wind_speed=wind_speed, wind_dir_deg=wind_dir,
                 current_u_ms=float(cu), current_v_ms=float(cv),
                 drift_u_km_h=float(u_km_h), drift_v_km_h=float(v_km_h),
                 has_land=bool(has_land), calibration_constant=CAL_CONSTANT,
                 pixel_spacing_m=PIXEL_M, grid=GRID,
                 vessels=[{k: v[k] for k in ("id", "mmsi", "name", "ship_type", "flag",
                                             "x_km", "y_km", "speed_ms", "course_deg",
                                             "length_m", "broadcasting", "row", "col")}
                          for v in vessels],
                 slicks=slicks)
    return dn, acquired, wind_speed, wind_dir, truth, labels


def write_product(safe_path, seed, acquired=None, **kw):
    dn, acquired, ws, wd, truth, labels = build_scene(seed, acquired=acquired, **kw)
    safe = write_synthetic(safe_path, dn, acquired, ws, wd, PIXEL_M, truth)
    np.save(safe / "varuna_labels.npy", labels)
    return safe


def default_safe_name(acquired, seed):
    stamp = acquired.strftime("%Y%m%dT%H%M%S")
    end = (acquired + timedelta(seconds=25)).strftime("%Y%m%dT%H%M%S")
    return f"S1A_IW_GRDH_1SDV_{stamp}_{end}_0{seed % 10000:04d}_VARUNA_SYNTH.SAFE"



