import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from varuna.config import WIND_MAX, WIND_MIN


@dataclass
class Environment:
    wind_speed: float | None
    wind_dir_deg: float | None
    current_u_ms: float | None
    current_v_ms: float | None
    source: str

    @property
    def wind_known(self):
        return self.wind_speed is not None and self.wind_dir_deg is not None

    @property
    def current_known(self):
        return self.current_u_ms is not None and self.current_v_ms is not None

    @property
    def usable_for_drift(self):
        return self.wind_known and self.current_known

    @property
    def wind_in_window(self):
        if self.wind_speed is None:
            return None
        return WIND_MIN <= self.wind_speed <= WIND_MAX

    def drift_inputs(self):
        return (float(self.current_u_ms or 0.0), float(self.current_v_ms or 0.0),
                float(self.wind_speed or 0.0), float(self.wind_dir_deg or 0.0))

    def describe(self):
        w = (f"{self.wind_speed:.1f} m/s from {self.wind_dir_deg:.0f} deg"
             if self.wind_known else "unknown")
        if self.current_known:
            speed = float(np.hypot(self.current_u_ms, self.current_v_ms))
            c = f"{speed:.2f} m/s"
        else:
            c = "unknown"
        return f"wind {w}, surface current {c} [{self.source}]"


def unknown():
    return Environment(None, None, None, None, "not supplied")


def constant(wind_speed=None, wind_dir_deg=None, current_u_ms=None,
             current_v_ms=None, source="operator-supplied"):
    return Environment(wind_speed, wind_dir_deg, current_u_ms, current_v_ms, source)


def from_truth(truth):
    if not truth:
        return unknown()
    return Environment(truth.get("wind_speed"), truth.get("wind_dir_deg"),
                       truth.get("current_u_ms"), truth.get("current_v_ms"),
                       "simulation truth")


def from_json(path):
    data = json.loads(Path(path).read_text())
    if "current_u_ms" not in data and "current_speed_ms" in data:
        d = np.deg2rad(float(data.get("current_dir_deg", 0.0)))
        data["current_u_ms"] = float(data["current_speed_ms"]) * float(np.sin(d))
        data["current_v_ms"] = float(data["current_speed_ms"]) * float(np.cos(d))
    return Environment(
        data.get("wind_speed_ms", data.get("wind_speed")),
        data.get("wind_dir_deg"),
        data.get("current_u_ms"), data.get("current_v_ms"),
        data.get("source", f"file {Path(path).name}"))


TEMPLATE = {
    "source": "ERA5 10 m wind + CMEMS surface current, scene centre, acquisition time",
    "wind_speed_ms": 6.4,
    "wind_dir_deg": 210.0,
    "current_speed_ms": 0.28,
    "current_dir_deg": 145.0,
}


def write_template(path):
    Path(path).write_text(json.dumps(TEMPLATE, indent=2))
    return Path(path)
