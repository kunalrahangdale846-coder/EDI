import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pytest

from varuna import (ais, cfar, darkspots, drift_engine, fixtures, frame,
                    intersect, oil_classifier, patch_metrics, pipeline,
                    s1_real, safe_reader, simulate, snap_preprocess)
from varuna.config import GRID, PIXEL_M, SCENE_KM


@pytest.fixture(scope="module")
def product(tmp_path_factory):
    d = tmp_path_factory.mktemp("safe")
    return simulate.write_product(d / "S1A_TEST.SAFE", 26161)


@pytest.fixture(scope="module")
def scene(product):
    return snap_preprocess.preprocess(safe_reader.read(product))


def test_flat_frame_roundtrip():
    f = frame.flat(150.0, 4.0, 68.5, 22.3)
    lon, lat = f.lonlat_of_px(120.0, 340.0)
    r, c = f.px_of_lonlat(lon, lat)
    assert float(r) == pytest.approx(120.0, abs=1e-6)
    assert float(c) == pytest.approx(340.0, abs=1e-6)
    x, y = f.km_of_px(0.0, 10.0)
    assert float(x) == pytest.approx(1.5)
    assert float(y) == pytest.approx(0.0)


def test_geocoded_frame_matches_grid_and_inverts():
    obs, _ = fixtures.synthetic_ocean(800, 1200, seed=3)
    import tempfile
    d = Path(tempfile.mkdtemp())
    safe = fixtures.write_realistic_safe(d / "g.SAFE", obs, spacing=10.0)
    sc = s1_real.read_grd(safe, multilook=10)
    f = frame.geocoded(sc.lon, sc.lat, sc.pixel_spacing_m, sc.enl)
    rows = np.array([0.0, 20.0, float(sc.shape[0] - 1)])
    cols = np.array([0.0, 40.0, float(sc.shape[1] - 1)])
    lo, la = f.lonlat_of_px(rows, cols)
    assert np.abs(lo - sc.lon[rows.astype(int), cols.astype(int)]).max() < 1e-9
    rr, cc = f.px_of_lonlat(lo, la)
    assert np.abs(rr - rows).max() < 0.05
    assert np.abs(cc - cols).max() < 0.05


def test_safe_roundtrip(product):
    p = safe_reader.read(product)
    assert p.polarisation == "VV"
    assert p.dn.shape == (GRID, GRID)
    assert p.pixel_spacing_m == PIXEL_M
    assert p.acquired.tzinfo is not None
    assert p.labels is not None and p.labels.shape == (GRID, GRID)
    assert (product / "manifest.safe").exists()
    assert list((product / "measurement").glob("*.tiff"))


def test_safe_reader_rejects_non_safe(tmp_path):
    d = tmp_path / "not_a_product"
    d.mkdir()
    with pytest.raises(ValueError):
        safe_reader.read(d)


def test_calibration_recovers_sigma0():
    sigma0 = np.full((32, 32), 0.037)
    dn = 2000.0 * np.sqrt(sigma0)
    back = snap_preprocess._calibrate(dn, 2000.0)
    assert np.allclose(back, sigma0, rtol=1e-9)


def test_refined_lee_reduces_variance():
    rng = np.random.default_rng(0)
    truth = np.full((128, 128), 0.03)
    obs = truth * rng.gamma(4.0, 1 / 4.0, truth.shape)
    filt = snap_preprocess._refined_lee(obs, size=5, looks=4)
    assert filt.var() < obs.var()
    assert abs(filt.mean() - truth.mean()) < 0.1 * truth.mean()


def test_land_mask_absent_when_no_land(tmp_path):
    safe = simulate.write_product(tmp_path / "noland.SAFE", 3, force_land=False)
    sc = snap_preprocess.preprocess(safe_reader.read(safe))
    assert sc.land_mask.sum() == 0
    assert sc.sea_mask.all()


def test_land_mask_present_when_land(tmp_path):
    safe = simulate.write_product(tmp_path / "land.SAFE", 3, force_land=True)
    sc = snap_preprocess.preprocess(safe_reader.read(safe))
    assert sc.land_mask.sum() > 5000


def test_cfar_threshold_factor_matches_analytic():
    for pfa in (1e-6, 1e-8):
        for looks in (2.0, 4.0):
            assert cfar.threshold_factor(pfa, looks) == pytest.approx(
                looks * (pfa ** (-1.0 / looks) - 1.0))


def test_cfar_detects_point_targets(scene):
    dets = cfar.detect(scene)
    truth = [v for v in scene.truth["vessels"]
             if v["row"] is not None and scene.sea_mask[v["row"], v["col"]]]
    assert len(dets) > 0
    hit = 0
    for v in truth:
        for d in dets:
            if np.hypot(d.centroid_rc[0] - v["row"], d.centroid_rc[1] - v["col"]) <= 4:
                hit += 1
                break
    assert hit / len(truth) > 0.6


def test_darkspots_finds_slicks_and_ignores_flat_sea(scene):
    regions = darkspots.detect(scene)
    assert regions
    assert all(r.area_km2 >= darkspots.MIN_AREA_KM2 for r in regions)

    still = snap_preprocess.Scene(
        sigma0=np.full((GRID, GRID), 0.03),
        sea_mask=np.ones((GRID, GRID), bool),
        land_mask=np.zeros((GRID, GRID), bool),
        bright_mask=np.zeros((GRID, GRID), bool),
        acquired=scene.acquired, pixel_spacing_m=PIXEL_M, polarisation="VV",
        backend="test", land_mask_source="none",
        frame=frame.flat(PIXEL_M, 4.0, 68.5, 22.3))
    assert darkspots.detect(still) == []


def test_patch_metrics_shape_discrimination():
    yy, xx = np.mgrid[0:GRID, 0:GRID]
    disc = (xx - 256) ** 2 + (yy - 256) ** 2 < 40 ** 2
    ellipse = ((xx - 256) / 80.0) ** 2 + ((yy - 256) / 20.0) ** 2 < 1.0
    assert patch_metrics._axes(disc)[0] / patch_metrics._axes(disc)[1] < 1.1
    assert patch_metrics._axes(ellipse)[0] / patch_metrics._axes(ellipse)[1] > 3.0


def test_patch_metrics_recovers_damping():
    from scipy import ndimage
    yy, xx = np.mgrid[0:GRID, 0:GRID]
    mask = (xx - 256) ** 2 + (yy - 256) ** 2 < 45 ** 2
    sigma0 = np.full((GRID, GRID), 0.04)
    sigma0[mask] *= 0.25
    sc = snap_preprocess.Scene(
        sigma0=sigma0, sea_mask=np.ones((GRID, GRID), bool),
        land_mask=np.zeros((GRID, GRID), bool),
        bright_mask=np.zeros((GRID, GRID), bool),
        acquired=datetime.now(timezone.utc), pixel_spacing_m=PIXEL_M,
        polarisation="VV", backend="test", land_mask_source="none",
        frame=frame.flat(PIXEL_M, 4.0, 68.5, 22.3))
    ring = ndimage.binary_dilation(mask, np.ones((15, 15))) & ~mask
    region = darkspots.Region(index=0, mask=mask, ring=ring,
                              area_px=int(mask.sum()),
                              area_km2=mask.sum() * (PIXEL_M / 1000.0) ** 2,
                              centroid_rc=(256.0, 256.0), bbox=(0, 0, 0, 0))
    f = patch_metrics.extract(sc, region)
    assert f[0] == pytest.approx(0.25, abs=0.02)
    assert f[2] < 1.15
    assert f[5] == pytest.approx(mask.sum() * (PIXEL_M / 1000.0) ** 2)


def test_axis_angle_matches_orientation():
    yy, xx = np.mgrid[0:GRID, 0:GRID]
    horizontal = (np.abs(yy - 256) < 6) & (np.abs(xx - 256) < 90)
    assert abs(abs(patch_metrics.axis_angle(horizontal)) - 90.0) < 5.0


def test_internal_backcast_reverses_constant_drift(scene):
    regions = darkspots.detect(scene)
    bc = drift_engine.backcast(scene, regions[0], 0.30, -0.20, 0.0, 0.0,
                               n=400, force_internal=True, seed=1)
    x, y = bc.as_km()
    hours = bc.hours[-1]
    du = (x[-1].mean() - x[0].mean()) / hours
    dv = (y[-1].mean() - y[0].mean()) / hours
    assert du == pytest.approx(-0.30 * 3.6, abs=0.25)
    assert dv == pytest.approx(0.20 * 3.6, abs=0.25)
    assert bc.backend == "internal-lagrangian"


def test_backcast_includes_wind_drift(scene):
    regions = darkspots.detect(scene)
    bc = drift_engine.backcast(scene, regions[0], 0.0, 0.0, 10.0, 90.0,
                               n=300, force_internal=True, seed=2)
    x, _ = bc.as_km()
    du = (x[-1].mean() - x[0].mean()) / bc.hours[-1]
    assert du == pytest.approx(-0.03 * 10.0 * 3.6, abs=0.25)


@pytest.mark.skipif(not drift_engine.opendrift_available(),
                    reason="opendrift not installed")
def test_opendrift_backend_runs(scene):
    regions = darkspots.detect(scene)
    bc = drift_engine.backcast(scene, regions[0], 0.25, -0.15,
                               scene.wind_speed, scene.wind_dir_deg,
                               n=200, seed=3)
    assert bc.backend == "opendrift"
    assert bc.lon.shape[1] == 200


def test_coverage_unknown_without_coast(tmp_path):
    safe = simulate.write_product(tmp_path / "open.SAFE", 3, force_land=False)
    sc = snap_preprocess.preprocess(safe_reader.read(safe))
    cov = ais.coverage_from_scene(sc)
    assert cov.known is False
    assert cov.inside(10.0, 10.0) is None


def test_coverage_known_with_coast(scene):
    cov = ais.coverage_from_scene(scene)
    assert cov.known is True
    assert isinstance(cov.inside(SCENE_KM / 2, SCENE_KM / 2), bool)


def test_unknown_coverage_suppresses_dark_calls(tmp_path):
    safe = simulate.write_product(tmp_path / "open2.SAFE", 3, force_land=False)
    sc = snap_preprocess.preprocess(safe_reader.read(safe))
    regions = darkspots.detect(sc)
    if not regions:
        pytest.skip("no dark region in this scene")
    cov = ais.coverage_from_scene(sc)
    bc = drift_engine.backcast(sc, regions[0], 0.2, 0.1, sc.wind_speed,
                               sc.wind_dir_deg, n=200, force_internal=True)
    det = cfar.detect(sc)
    tracks = ais.tracks_from_truth(sc.truth, cov)
    _, dark = intersect.correlate_vessels(intersect.locate(det, sc.frame), tracks)
    a = intersect.attribute(regions[0], 0.9, bc, tracks, dark,
                            drift_engine.candidate_hours(), cov, sc.frame)
    assert not any(s.kind == "dark" for s in a.suspects)
    assert "not evidence of a dark vessel" in a.coverage_note


def test_ais_csv_roundtrip(tmp_path, scene):
    cov = ais.coverage_from_scene(scene)
    tracks = ais.tracks_from_truth(scene.truth, cov, seed=0)
    path = tmp_path / "ais.csv"
    ais.write_csv(path, tracks, scene.acquired, scene.frame)
    back = ais.load_csv(path, scene.acquired, scene.frame)
    assert {t.mmsi for t in back} == {t.mmsi for t in tracks}
    a = sorted(tracks, key=lambda t: t.mmsi)[0]
    b = sorted(back, key=lambda t: t.mmsi)[0]
    assert a.position_at(2.0)[0] == pytest.approx(b.position_at(2.0)[0], abs=0.2)


def test_nearby_track_outranks_distant_one(scene):
    regions = darkspots.detect(scene)
    bc = drift_engine.backcast(scene, regions[0], 0.0, 0.0, 0.0, 0.0,
                               n=300, force_internal=True, seed=5)
    x, y = bc.as_km()
    hours = np.array([4.0])
    i = int(np.argmin(np.abs(bc.hours - 4.0)))
    cx, cy = float(x[i].mean()), float(y[i].mean())
    times = np.array([0.0, 4.0, 8.0])

    def track(mmsi, px, py):
        return ais.Track(mmsi=mmsi, name=str(mmsi), ship_type="Tanker", flag="IND",
                         length_m=200.0, times_h=times,
                         x_km=np.full(3, px), y_km=np.full(3, py),
                         sog_kn=10.0, cog_deg=0.0)

    near = track(1, cx, cy)
    far = track(2, cx + 60.0, cy + 60.0)
    scored = intersect.score_tracks(bc, [near, far], hours)
    assert scored
    assert scored[0].mmsi == 1
    assert all(s.mmsi != 2 for s in scored) or scored[0].score > scored[1].score


def test_dark_speed_prior_and_bearing_weight():
    assert intersect._speed_prior(12.0) == pytest.approx(1.0)
    assert intersect._speed_prior(1.5) < 0.05
    along = intersect._bearing_weight(np.array([0.0]), np.array([10.0]), 0.0)
    across = intersect._bearing_weight(np.array([10.0]), np.array([0.0]), 0.0)
    assert along[0] == pytest.approx(1.0, abs=1e-6)
    assert across[0] < 1e-6


def test_classifier_trains_and_calibrates():
    rng = np.random.default_rng(0)
    n = 220
    y = rng.integers(0, 2, n)
    X = np.column_stack([
        np.where(y == 1, rng.normal(0.35, 0.09, n), rng.normal(0.52, 0.11, n)),
        rng.normal(4.0, 1.2, n),
        np.where(y == 1, rng.normal(5.0, 2.0, n), rng.normal(2.4, 0.9, n)),
        rng.normal(0.7, 0.25, n), rng.normal(0.2, 0.08, n), rng.normal(25, 12, n)])
    groups = rng.integers(0, 40, n)
    clf = oil_classifier.train(X, y, groups, seed=0)
    p = clf.predict_proba(X)
    assert p.shape == (n,)
    assert p.min() >= 0.005 and p.max() <= 0.995
    assert clf.report["holdout_roc_auc"] > 0.75
    assert set(clf.importances()) == set(patch_metrics.NAMES)


def test_pipeline_end_to_end(product, tmp_path):
    clf = oil_classifier.load()
    res = pipeline.run(product, classifier=clf, particles=300,
                       force_internal_drift=True, seed=0)
    d = res.to_dict()
    json.dumps(d)
    assert d["dark_regions"] == len(res.regions)
    assert d["preprocessing_backend"] in ("internal", "snap-gpt")
    assert len(d["oil_probabilities"]) == len(res.regions)
    assert d["ais_coverage_known"] is True
    for a in d["attributions"]:
        assert 0.0 <= a["oil_probability"] <= 1.0
        scores = [s["score"] for s in a["suspects"]]
        assert scores == sorted(scores, reverse=True)
    p = pipeline.save(res, tmp_path / "out.json")
    assert json.loads(p.read_text())["product"]


def test_wind_gate_flags_out_of_window(tmp_path):
    safe = simulate.write_product(tmp_path / "calm.SAFE", 5, wind_speed=1.4)
    sc = snap_preprocess.preprocess(safe_reader.read(safe))
    assert sc.wind_in_window is False
    res = pipeline.run(safe, classifier=oil_classifier.load(), particles=200,
                       force_internal_drift=True)
    assert any("WIND GATE" in s for s in res.stages)


def test_evaluation_labels_regions(scene):
    from varuna import evaluate
    regions = darkspots.detect(scene)
    labels = [evaluate.label_region(scene.labels, r) for r in regions]
    assert set(labels) <= {0, 1}
    assert evaluate.label_region(None, regions[0]) == -1


@pytest.fixture(scope="module")
def real_safe(tmp_path_factory):
    obs, slick = fixtures.synthetic_ocean(1600, 2400, seed=1)
    d = tmp_path_factory.mktemp("real")
    return fixtures.write_realistic_safe(d / "S1A_REAL.SAFE", obs, spacing=10.0), obs


def test_real_reader_recovers_calibrated_sigma0(real_safe):
    safe, obs = real_safe
    sc = s1_real.read_grd(safe, multilook=15)
    truth = s1_real._block_mean(obs, 15)
    rel = np.abs(sc.sigma0 - truth) / np.maximum(truth, 1e-9)
    assert np.median(rel) < 0.05
    assert sc.denoised is True
    assert sc.pixel_spacing_m == pytest.approx(150.0)
    assert sc.polarisation == "VV"


def test_real_reader_geolocation_is_exact(real_safe):
    safe, _ = real_safe
    sc = s1_real.read_grd(safe, multilook=15)
    rows = (np.arange(sc.shape[0]) + 0.5) * 15
    cols = (np.arange(sc.shape[1]) + 0.5) * 15
    lon, lat = fixtures._lonlat(rows[0], cols[0], 68.2, 23.4, 1600, 2400)
    assert float(sc.lon[0, 0]) == pytest.approx(lon, abs=1e-6)
    assert float(sc.lat[0, 0]) == pytest.approx(lat, abs=1e-6)


def test_real_reader_aoi_crop(real_safe):
    safe, _ = real_safe
    full = s1_real.read_grd(safe, multilook=15)
    lo, la, hi_lo, hi_la = full.bounds()
    aoi = ((lo + hi_lo) / 2 - 0.2, (la + hi_la) / 2 - 0.15,
           (lo + hi_lo) / 2 + 0.2, (la + hi_la) / 2 + 0.15)
    sub = s1_real.read_grd(safe, multilook=15, aoi=aoi)
    assert sub.shape[0] < full.shape[0] and sub.shape[1] < full.shape[1]
    assert sub.offset_rc != (0, 0)
    slo, sla, shi_lo, shi_la = sub.bounds()
    assert slo <= aoi[0] + 1e-6 and shi_lo >= aoi[2] - 1e-6


def test_enl_estimator_tracks_true_looks():
    rng = np.random.default_rng(0)
    for looks in (4.0, 30.0, 200.0):
        field = np.full((512, 512), 0.03) * rng.gamma(looks, 1.0 / looks, (512, 512))
        est = s1_real.estimate_enl(field)
        assert est == pytest.approx(looks, rel=0.25)


def test_noise_lut_is_subtracted(real_safe):
    safe, _ = real_safe
    with_noise = s1_real.read_grd(safe, multilook=15, denoise=False)
    without = s1_real.read_grd(safe, multilook=15, denoise=True)
    assert with_noise.denoised is False
    assert without.denoised is True
    assert float(np.mean(without.sigma0)) < float(np.mean(with_noise.sigma0))


def test_environment_gates_drift(tmp_path):
    from varuna import environment
    e = environment.unknown()
    assert e.usable_for_drift is False
    assert e.wind_in_window is None
    p = environment.write_template(tmp_path / "env.json")
    loaded = environment.from_json(p)
    assert loaded.usable_for_drift is True
    assert loaded.wind_in_window is True
    assert loaded.current_u_ms is not None
    calm = environment.constant(wind_speed=1.2, wind_dir_deg=10.0,
                                current_u_ms=0.1, current_v_ms=0.0)
    assert calm.wind_in_window is False


def test_real_pipeline_uses_two_resolutions(real_safe):
    from varuna import real_pipeline
    safe, _ = real_safe
    res = real_pipeline.run(safe, classifier=None, coarse_multilook=15,
                            fine_multilook=3)
    assert res.coarse.pixel_spacing_m == pytest.approx(150.0)
    assert res.fine.pixel_spacing_m == pytest.approx(30.0)
    assert res.fine.shape[0] > res.coarse.shape[0]
    assert len(res.detections) > 5
    assert res.regions
    assert all(r["lon"] is not None for r in res.located)
    json.dumps(res.to_dict())


def test_real_pipeline_withholds_simulated_classifier(real_safe):
    from varuna import real_pipeline
    safe, _ = real_safe
    clf = oil_classifier.load()
    res = real_pipeline.run(safe, classifier=clf, fine_multilook=4)
    assert any("withheld" in w or "SIMULATED" in w for w in res.warnings)
    assert float(np.max(res.oil_probability)) == 0.0
    res2 = real_pipeline.run(safe, classifier=clf, fine_multilook=4,
                             allow_synthetic_model=True)
    assert float(np.max(res2.oil_probability)) > 0.0


def test_real_pipeline_disables_drift_without_environment(real_safe):
    from varuna import real_pipeline
    safe, _ = real_safe
    res = real_pipeline.run(safe, classifier=None, fine_multilook=4)
    assert res.attributions == []
    assert any("diffusion-only no-op" in w for w in res.warnings)


def test_classifier_carries_provenance():
    rng = np.random.default_rng(1)
    n = 200
    y = rng.integers(0, 2, n)
    X = np.column_stack([
        np.where(y == 1, rng.normal(0.35, 0.09, n), rng.normal(0.52, 0.11, n)),
        rng.normal(4.0, 1.2, n),
        np.where(y == 1, rng.normal(5.0, 2.0, n), rng.normal(2.4, 0.9, n)),
        rng.normal(0.7, 0.25, n), rng.normal(0.2, 0.08, n), rng.normal(25, 12, n)])
    groups = rng.integers(0, 40, n)
    sim = oil_classifier.train(X, y, groups, seed=0)
    assert sim.trained_on_real_imagery is False
    real = oil_classifier.train(X, y, groups, seed=0, provenance="real")
    assert real.trained_on_real_imagery is True
    assert real.report["provenance"] == "real"


def test_cfar_threshold_follows_scene_looks(real_safe):
    from varuna import real_pipeline
    safe, _ = real_safe
    fine = s1_real.read_grd(safe, multilook=3)
    scene = real_pipeline._to_scene(fine)
    assert scene.frame.looks == pytest.approx(fine.enl)
    alpha_scene = cfar.threshold_factor(cfar.PFA, scene.frame.looks)
    alpha_default = cfar.threshold_factor(cfar.PFA, 4.0)
    assert alpha_scene < alpha_default


def test_geojson_labels_map_onto_detected_regions(real_safe, tmp_path):
    from varuna import darkspots, label_import, real_pipeline
    safe, _ = real_safe
    real = s1_real.read_grd(safe, multilook=15)
    scene = real_pipeline._to_scene(real, assume_all_sea=True)
    regions = darkspots.detect(scene)
    assert regions
    lon, lat = scene.frame.lonlat_of_px(*regions[0].centroid_rc)
    lon, lat = float(lon), float(lat)
    d = 0.2
    gj = {"type": "FeatureCollection", "features": [{
        "type": "Feature", "properties": {"source": "test"},
        "geometry": {"type": "Polygon", "coordinates": [[
            [lon - d, lat - d], [lon + d, lat - d], [lon + d, lat + d],
            [lon - d, lat + d], [lon - d, lat - d]]]}}]}
    p = tmp_path / "labels.geojson"
    p.write_text(json.dumps(gj))
    polys = label_import.load_geojson(p)
    assert len(polys) == 1
    truth = label_import.rasterise(polys, scene.frame, scene.sigma0.shape)
    assert truth.sum() > 0
    y = label_import.label_regions(regions, truth)
    assert y[0] == 1

    far = {"type": "FeatureCollection", "features": [{
        "type": "Feature", "properties": {},
        "geometry": {"type": "Polygon", "coordinates": [[
            [lon + 8, lat + 8], [lon + 9, lat + 8], [lon + 9, lat + 9],
            [lon + 8, lat + 9], [lon + 8, lat + 8]]]}}]}
    p2 = tmp_path / "far.geojson"
    p2.write_text(json.dumps(far))
    truth2 = label_import.rasterise(label_import.load_geojson(p2),
                                    scene.frame, scene.sigma0.shape)
    assert label_import.label_regions(regions, truth2)[0] == 0


def test_dataset_append_roundtrip(tmp_path):
    from varuna import label_import
    p = tmp_path / "ds.npz"
    X1 = np.random.default_rng(0).normal(size=(5, 6))
    label_import.append_dataset(p, X1, np.array([1, 0, 1, 0, 1]), np.array(["a"] * 5))
    X2 = np.random.default_rng(1).normal(size=(3, 6))
    path, total, pos = label_import.append_dataset(p, X2, np.array([0, 0, 1]),
                                                   np.array(["b"] * 3))
    assert total == 8 and pos == 4
    X, y, g = label_import.load_dataset(p)
    assert X.shape == (8, 6) and set(g.tolist()) == {"a", "b"}


def test_land_mask_can_be_overridden(real_safe):
    from varuna import real_pipeline
    safe, _ = real_safe
    real = s1_real.read_grd(safe, multilook=15)
    sea = real_pipeline._to_scene(real, assume_all_sea=True)
    assert sea.land_mask.sum() == 0
    assert "open water" in sea.land_mask_source
    forced = np.zeros(real.sigma0.shape, dtype=bool)
    forced[:8, :] = True
    masked = real_pipeline._to_scene(real, land_mask=forced)
    assert masked.land_mask.sum() == forced.sum()
    assert "operator-supplied" in masked.land_mask_source


def test_annotation_lookups_are_scoped_to_image_information(tmp_path):
    obs, _ = fixtures.synthetic_ocean(600, 900, seed=5)
    safe = fixtures.write_realistic_safe(tmp_path / "decoy.SAFE", obs,
                                         spacing=10.0, decoy_tags=True)
    sc = s1_real.read_grd(safe, multilook=10)
    assert sc.pixel_spacing_m == pytest.approx(100.0)


def test_grd_border_nodata_is_excluded_not_detected_as_slick(tmp_path):
    from varuna import real_pipeline
    obs, _ = fixtures.synthetic_ocean(1600, 2400, seed=1)
    safe = fixtures.write_realistic_safe(tmp_path / "border.SAFE", obs,
                                         spacing=10.0, border_px=120)
    sc = s1_real.read_grd(safe, multilook=15)
    assert sc.valid.mean() < 0.85
    assert any("no-data" in n for n in sc.notes)

    scene = real_pipeline._to_scene(sc, assume_all_sea=True)
    assert "no-data exclusion" in scene.land_mask_source
    assert scene.sea_mask.sum() == int(sc.valid.sum())
    regions = darkspots.detect(scene)
    border_km2 = (1600 * 2400 - (1600 - 240) * (2400 - 240)) * (0.01 ** 2)
    assert all(r.area_km2 < border_km2 / 4 for r in regions)
    assert regions


def test_doctor_passes_a_wellformed_product(real_safe):
    from varuna import doctor
    safe, _ = real_safe
    checks, facts = doctor.inspect(safe)
    assert not [m for lvl, m in checks if lvl == "fail"]
    assert facts["spacing_m"] == pytest.approx(10.0)
    assert facts["shape"] == (1600, 2400)
    text, n_fail = doctor.report(safe)
    assert n_fail == 0
    assert "suggested first run" in text


def test_doctor_reports_blocking_problems(real_safe, tmp_path):
    import shutil
    from varuna import doctor
    safe, _ = real_safe

    no_cal = tmp_path / "nocal.SAFE"
    shutil.copytree(safe, no_cal)
    for f in (no_cal / "annotation" / "calibration").glob("calibration-*.xml"):
        f.unlink()
    _, n_fail = doctor.report(no_cal)
    assert n_fail == 1

    no_geo = tmp_path / "nogeo.SAFE"
    shutil.copytree(safe, no_geo)
    ann = next((no_geo / "annotation").glob("s1a*.xml"))
    t = ann.read_text()
    i = t.index("<geolocationGrid>")
    j = t.index("</geolocationGrid>") + len("</geolocationGrid>")
    ann.write_text(t[:i] + t[j:])
    checks, _ = doctor.inspect(no_geo)
    assert any("geolocationGridPointList" in m for lvl, m in checks if lvl == "fail")

    no_meas = tmp_path / "nomeas.SAFE"
    shutil.copytree(safe, no_meas)
    shutil.rmtree(no_meas / "measurement")
    _, n_fail = doctor.report(no_meas)
    assert n_fail >= 1


def _slick_scene(damping, half_len=45, half_wid=16):
    from scipy import ndimage
    rng = np.random.default_rng(4)
    n = 600
    truth = np.full((n, n), 0.035)
    yy, xx = np.mgrid[0:n, 0:n]
    blob = ((xx - 300) / float(half_len)) ** 2 + ((yy - 300) / float(half_wid)) ** 2 < 1.0
    soft = ndimage.gaussian_filter(blob.astype(float), 3)
    soft /= soft.max()
    truth = truth * (1.0 - (1.0 - damping) * soft)
    obs = truth * rng.gamma(60.0, 1 / 60.0, truth.shape)
    return snap_preprocess.Scene(
        sigma0=obs, sea_mask=np.ones((n, n), bool),
        land_mask=np.zeros((n, n), bool), bright_mask=np.zeros((n, n), bool),
        acquired=datetime.now(timezone.utc), pixel_spacing_m=150.0,
        polarisation="VV", backend="test", land_mask_source="none",
        frame=frame.flat(150.0, 60.0, 68.5, 22.3))


def test_contrast_gates_are_tunable():
    weak = _slick_scene(damping=0.76)
    assert darkspots.detect(weak, k=0.62) == []
    loose = darkspots.detect(weak, k=0.90, region_damping_max=0.95,
                             seed_fraction=0.15, min_area_km2=0.5)
    assert len(loose) >= 1

    strong = _slick_scene(damping=0.30)
    assert len(darkspots.detect(strong, k=0.62)) >= 1


def test_slick_larger_than_the_background_window_needs_a_wider_window():
    from scipy import ndimage
    big = _slick_scene(damping=0.30, half_len=170, half_wid=60)
    clutter = big.clutter_mask
    filled = np.where(clutter, big.sigma0, np.nan)
    filled = np.where(np.isfinite(filled), filled, np.nanmedian(filled))
    narrow = big.sigma0 / ndimage.uniform_filter(filled, 81)
    wide = big.sigma0 / ndimage.uniform_filter(filled, 401)
    assert narrow[300, 300] > 0.85
    assert wide[300, 300] < 0.60
    assert darkspots.detect(big, background_px=81, max_area_km2=1e6) == []
    found = darkspots.detect(big, background_px=401, max_area_km2=1e6)
    assert len(found) >= 1
    assert found[0].area_km2 > 400


def test_detection_gates_read_environment(monkeypatch):
    import importlib
    monkeypatch.setenv("VARUNA_DARK_K", "0.81")
    monkeypatch.setenv("VARUNA_CFAR_PFA", "1e-6")
    import varuna.config
    cfg = importlib.reload(varuna.config)
    assert cfg.DARK_K == pytest.approx(0.81)
    assert cfg.CFAR_PFA == pytest.approx(1e-6)
    monkeypatch.delenv("VARUNA_DARK_K")
    monkeypatch.delenv("VARUNA_CFAR_PFA")
    importlib.reload(varuna.config)
