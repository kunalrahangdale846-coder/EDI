# VARUNA-S1

Prototype for SIH 2026 PS 26143 — attributing a SAR-detected oil slick to the
vessel that released it.

A Sentinel-1 `.SAFE` product goes in. Two branches mine the same scene at two
different resolutions, an OpenDrift reverse advection turns the slick back into
a release cloud, and the intersection of that cloud with AIS history and
uncorrelated radar contacts produces a ranked suspect list in the terminal.

It runs on **synthetic scenes** (self-contained, for development and scoring)
and on **real Copernicus products** (no SNAP install required).

```
  .SAFE product
        |
  L1 reader: calibration LUT, thermal-noise LUT, geolocation grid, multilook
        |                                              s1_real.py
        +---------------------------+
        |                           |
  slick grid ~150 m           vessel grid ~30 m
  dark spots                  CA-CFAR
  darkspots.py                cfar.py
        |                           |
  6 patch metrics                   |
  patch_metrics.py                  |
        |                           |
  XGBoost -> p(oil)                 |
  oil_classifier.py                 |
        |                           |
  OpenDrift reverse engine          |
  drift_engine.py                   |
        |                           |
        +---------------------------+
                    |
        Spatiotemporal intersection      intersect.py
        AIS history + dark contacts      ais.py
                    |
        Suspect ranking                  dashboard.py
```

## Quick start

```bash
./run.sh
```

Creates the virtualenv, installs dependencies, and runs the full demo.
Windows: `run.bat`. Also `./run.sh evaluate`, `./run.sh test`, and:

```bash
./run.sh web        # dashboard + JSON API on http://127.0.0.1:8501
```

The web dashboard is a single-page React app served from `varuna/static/`,
already built — no npm needed. See [frontend/README.md](frontend/README.md).

OpenDrift is optional — without it the drift engine falls back to an equivalent
internal Lagrangian back-caster and says which one ran. To install it:
`./run.sh --full demo`.

## Manual install

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt        # core, ~1 min
.venv/bin/pip install -r requirements-full.txt   # adds OpenDrift
```

## Run on synthetic data

```bash
.venv/bin/python -m varuna.cli demo
```

Writes a synthetic product, trains the classifier if none exists, runs the whole
chain and prints the dashboard. Individual steps: `simulate`, `train`, `run`,
`evaluate`.

## Run on a real Copernicus product

See **[REAL_DATA.md](REAL_DATA.md)** for the full step-by-step guide. Short version:

```bash
# 0. check the product parses before doing any work
.venv/bin/python -m varuna.cli doctor /path/to/S1A_IW_GRDH_....SAFE

# 1. wind and current for the scene centre at acquisition time
.venv/bin/python -m varuna.cli env-template --out environment.json
#    fill in from ERA5 (cds.climate.copernicus.eu) and CMEMS (marine.copernicus.eu)

# 2. detection only
.venv/bin/python -m varuna.cli real /path/to/S1A_IW_GRDH_....SAFE \
    --aoi 68.9,22.3,69.8,22.9

# 3. full attribution
.venv/bin/python -m varuna.cli real /path/to/S1A_....SAFE \
    --aoi 68.9,22.3,69.8,22.9 \
    --env environment.json --ais-csv ais_history.csv --shore-km 35
```

No SNAP required — the L1 reader does calibration, thermal-noise removal,
geolocation and multilooking in NumPy. If ESA SNAP's `gpt` is on `PATH`, the
synthetic path will use a real graph instead (Apply-Orbit-File,
Remove-GRD-Border-Noise, ThermalNoiseRemoval, Calibration, Multilook,
Speckle-Filter, Terrain-Correction, Land-Sea-Mask). That graph has never been
run here; verify its parameters with `gpt -h <Operator>` against your install.

### Flags that matter on real data

| flag | why |
| --- | --- |
| `--aoi lon_min,lat_min,lon_max,lat_max` | crops before reading; optional, a full scene streams fine |
| `--multilook` / `--fine-multilook` | slick grid (default 15 → 150 m) and vessel grid (default 3 → 30 m) |
| `--env FILE` | wind and current. **Without it, attribution is disabled**, not silently zeroed |
| `--ais-csv FILE` | columns `mmsi,name,ship_type,flag,length_m,timestamp,lon,lat,sog,cog` |
| `--shore-km D` | distance to the nearest AIS shore station, so the coverage envelope can be resolved |
| `--assume-all-sea` | open-ocean AOI with no coastline; skips the land detector |
| `--allow-synthetic-model` | show probabilities from the simulated-provenance classifier anyway |

## Retraining on real labels

The shipped classifier is trained on simulated slicks and its probabilities are
**withheld** on real imagery unless you override. To make them mean something,
label real scenes against a known-slick corpus (Cerulean's API publishes slick
polygons keyed to Sentinel-1 scene IDs):

```bash
.venv/bin/python -m varuna.cli label scene.SAFE cerulean_slicks.geojson \
    --dataset artifacts/real_dataset.npz
# repeat over many scenes, then
.venv/bin/python -m varuna.cli train-real --dataset artifacts/real_dataset.npz
```

`train-real` stamps the model `provenance: real`, which is what lifts the
withholding.

## What is real and what is simulated

**Real code, real algorithms.** The Sentinel-1 L1 reader (calibration vector
LUT, thermal-noise LUT, geolocation grid polynomial, block multilook, ENL
estimation), CA-CFAR with its analytic threshold, the six patch metrics, XGBoost
with isotonic calibration, and OpenDrift's `OceanDrift` doing genuine reverse
advection with a negative time step.

**Simulated, in the synthetic path only.** The imagery. `simulate.py` synthesises
Sentinel-1 products: wind-dependent ocean backscatter, Gamma speckle, a textured
coastline, point-target vessels, slicks whose shape comes from forward-drifting a
release streak, and look-alikes drawn from distributions that deliberately
overlap the oil class. AIS history is generated from the same vessel truth.

**Consequence.** The numbers below measure whether the chain is correctly built
and whether the physics inverts. They are not a claim about performance on
Copernicus data.

## Measured on 50 held-out synthetic scenes

| stage | metric | value |
| --- | --- | --- |
| oil vs look-alike | ROC-AUC | 0.876 |
| | PR-AUC | 0.818 |
| | Brier | 0.142 |
| | precision / recall at p=0.5 | 0.733 / 0.778 |
| CFAR vessels | recall (601 vessels in analysable sea) | 0.957 |
| | false alarms per scene | 0.02 |
| dark vessel calls | false dark rate (157 uncorrelated contacts) | 0.000 |
| attribution | top-1 over all 63 confirmed slicks | 0.540 |
| | top-1 over the 49 with a findable source | 0.694 |
| | true source anywhere in the ranked list | 0.714 |
| | mean rank of the true source | 1.29 |
| | median release-time error | 0.47 h |

The gap between 0.540 and 0.694 is the honest part: in 14 of 63 cases the source
was a vessel already silent *and* already outside the SAR footprint at
acquisition. No amount of processing recovers it from one scene, and the system
returns no suspect rather than inventing one.

## Design decisions worth defending

**Two resolutions, not one.** Multilooking to 150 m is what makes slick shape
metrics meaningful and lifts ENL from ~4 to several hundred. It also averages
ships away. So dark-spot detection runs on the coarse grid and CFAR on a ~30 m
grid, and detections are carried between them through geolocation rather than
pixel arithmetic.

**Scene-derived constants, not global ones.** Pixel spacing, number of looks and
the geolocation model live on a frame object attached to each scene. The CFAR
threshold factor is computed from the *measured* ENL of the grid it runs on: at
4 looks α≈396, at 36 looks α≈20. Hardcoding 4 makes the detector ~20× too
conservative on multilooked data and it finds nothing.

**Environment is explicit or absent.** Wind and current are supplied, never
defaulted. If they are missing the reverse advection would be a diffusion-only
no-op, so attribution is switched off and says so, rather than producing a
confident cloud centred on the slick.

**Bounded memory.** The measurement raster is streamed in row blocks: peak
memory is set by block height x scene width, not by scene size. A full IW GRDH
reads in about 0.6 GB; computing calibration and noise LUTs at full resolution
in one shot would need roughly 11 GB.

**Provenance gating.** A classifier trained on simulated slicks refuses to emit
probabilities for real imagery unless explicitly overridden.

**The AIS coverage trap.** Terrestrial AIS reaches roughly 40–60 nm; the EEZ
reaches 200. "No AIS here" can mean "nothing was broadcasting" or "no receiver
could hear it", and those have opposite legal weight. The coverage envelope is
resolved from the coastline in the scene or an operator-supplied shore distance,
and dark-vessel calls are suppressed outside it:

```
AIS coverage: slick lies outside the 50 nm assured AIS envelope; absence of
              AIS is not evidence of a dark vessel
```

In evaluation this costs top-1 accuracy on 3 slicks. That trade is deliberate.

## How a suspect is scored

An AIS suspect scores the fraction of back-cast particles falling within the
association radius of that vessel's reported position, maximised over the
candidate release window, times the slick's oil probability.

A dark contact has position but no velocity from a single scene. Rather than
assume one, it is scored on three constraints: the implied transit speed must lie
in 2–22 kn; that speed is weighted by a lognormal prior centred at 12 kn; and the
bearing from the release cloud to the contact must agree with the slick's own
major axis, since the release streak lies along the ship's track. The result is
multiplied by 0.50 — an unidentified radar contact that is merely *consistent* is
weaker evidence than a named AIS track that is consistent. Top-1 accuracy is flat
for that factor anywhere in 0.35–0.55.

## Output claim

`probable cause to intercept and sample`. Not a conviction. Chemical
fingerprinting of a bunker sample against the slick is the evidentiary step, and
it needs a suspect to sample first — which is the gap this fills.

## Module map

| file | role |
| --- | --- |
| `config.py` | tunable constants, overridable by `VARUNA_*` env vars |
| `frame.py` | pixel / km / lon-lat mapping; flat grid or geolocated polynomial |
| `s1_real.py` | real Sentinel-1 L1 reader (calibration, noise, geolocation, multilook, ENL) |
| `safe_reader.py` | reader for the synthetic products |
| `fixtures.py` | generates `.SAFE` products with real annotation XML structures |
| `snap_preprocess.py` | SNAP `gpt` graph adapter, with a NumPy equivalent |
| `darkspots.py` | Branch A — adaptive dark-region segmentation |
| `patch_metrics.py` | the six per-region metrics |
| `oil_classifier.py` | XGBoost + isotonic calibration, with provenance |
| `cfar.py` | Branch B — CA-CFAR vessel detection |
| `drift_engine.py` | OpenDrift reverse advection, internal fallback |
| `environment.py` | wind and current providers |
| `ais.py` | AIS tracks and the assured-coverage envelope |
| `intersect.py` | spatiotemporal intersection and suspect scoring |
| `label_import.py` | GeoJSON slick labels → training rows |
| `dashboard.py` | terminal output |
| `figures.py` | overlay figures |
| `pipeline.py` / `real_pipeline.py` | synthetic and real orchestration |
| `simulate.py` / `evaluate.py` | scene generator and held-out scoring |
| `doctor.py` | pre-flight check on a real `.SAFE` before running |
| `api.py` | FastAPI app: JSON endpoints + serves the dashboard |
| `static/` | prebuilt dashboard bundle (no CDN, works offline) |
| `frontend/` | dashboard source, embed and build scripts |
| `cli.py` | `simulate` `train` `run` `evaluate` `demo` `real` `doctor` `serve` `label` `train-real` `env-template` |

Tests: `.venv/bin/pip install -r requirements-dev.txt && .venv/bin/python -m pytest tests -q`
(41 tests, ~25 s).

## Known limits

- **Never run against an actual Copernicus product.** The reader is tested
  against fixtures carrying real Sentinel-1 annotation structures (calibration
  vector lists, noise range vectors, geolocation grids), not against a real
  download. Expect to iterate on the first real scene.
- **Wind and current are spatially constant.** Real back-casting needs INCOIS,
  CMEMS or HYCOM fields. OpenDrift already accepts readers, so this is a
  substitution rather than a rewrite — but it is not done.
- **The classifier has never seen real imagery.** Its numbers transfer only after
  `label` + `train-real` over a real labelled corpus.
- **Land masking on real products is an Otsu split**, not SRTM. Use
  `--assume-all-sea` for open-ocean AOIs, or supply a mask. SNAP's
  `Land-Sea-Mask` is the correct source.
- **The dark-spot background window must exceed the slick.** Detection thresholds
  each pixel against a local mean over `VARUNA_DARK_BACKGROUND_PX` (default 81 px
  = 12 km at 150 m). A slick longer than that window depresses its own
  background and its interior becomes invisible — a 51 x 18 km slick is missed
  entirely at the default and found at `401`. Widen it for large spills.
- **Only VV is used.** The VV/VH ratio is a known look-alike discriminator and is
  not exploited.
- **The SNAP graph is untested.** It has never been run against a real `gpt`.
- **AIS for the Indian EEZ is not free.** Detection and dark-vessel scoring can be
  validated against Global Fishing Watch's Sentinel-1 SAR detections; per-vessel
  tracks for the final attribution step need a commercial feed or an ICG/IMAC
  arrangement.
